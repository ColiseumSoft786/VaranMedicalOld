<?php

namespace DataBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DataBundle extends Bundle
{
}

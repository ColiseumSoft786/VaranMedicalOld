<?php

namespace DataBundle\Entity;

/**
 * Appointements
 */
class Appointements
{
    /**
     * @var integer
     */
    private $id;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}

<?php

namespace MediasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MediasBundle extends Bundle
{
}

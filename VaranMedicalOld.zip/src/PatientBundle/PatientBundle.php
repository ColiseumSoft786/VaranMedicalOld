<?php

namespace PatientBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PatientBundle extends Bundle
{
}

<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_77808360820b1844b4be948e8a63be0a0497b98e6080e1a3605c453b4a8fbc60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <body class=\"tg-login\">
    <!--[if lt IE 8]>
    <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <!--************************************
            Preloader Start
    *************************************-->
    <div class=\"preloader-outer\">
        <div class=\"pin\"></div>
        <div class=\"pulse\"></div>
    </div>
    <!--************************************
            Wrapper Start
    *************************************-->
    <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
        <!--************************************
                Header Start
        *************************************-->
        ";
        // line 22
        $this->loadTemplate("default/header.html.twig", "@FOSUser/Security/login.html.twig", 22)->display($context);
        // line 23
        echo "        <!--************************************
                Header End
        *************************************-->
        <!--************************************
                Home Banner Start
        *************************************-->
        <div class=\"tg-pageinnerbanner tg-haslayout tg-parallaximg\" data-appear-top-offset=\"600\" data-parallax=\"scroll\" data-image-src=\"images/banner/img-02.jpg\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12 col-xs-12\">
                        <div class=\"tg-pageheadcontent\">
                            <div class=\"tg-pagetitle\">
                                <h1>Connexion / Créer un compte</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--************************************
                Home Banner End
        *************************************-->
        <!--************************************
                Main Start
        *************************************-->
        <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
            <div class=\"container\">
                <div class=\"row\">
                    <div id=\"tg-twocolumns\" class=\"tg-twocolumns\">
                        <div class=\"col-md-offset-2 col-sm-offset-2 col-md-8 col-sm-8 col-xs-12\">
                            <div id=\"tg-content\" class=\"tg-content\">
                                <div class=\"tg-signinsignup\">
                                    <div class=\"tg-title\" id=\"titleInscription\">
                                        <h2>Inscrivez-vous dès maintenant</h2>
                                    </div>
                                    <div class=\"tg-title\" id=\"titleConnexion\" hidden>
                                        <h2>Se connecter</h2>
                                    </div>

                                    <div class=\"tg-dashboardtabs\">
                                        <div class=\"tab-content tg-dashboardtabcontent\">
                                            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                                <div class=\"tg-searchbulder\">
                                                    <div id=\"tg-subcategories\" class=\"tg-subcategories\">
                                                        <div id=\"doctorscategory\" class=\"tg-tabcontent tg-active\">
                                                            <div id=\"formAddDoctor\">
                                                                ";
        // line 69
        $this->loadTemplate("user/login2.html.twig", "@FOSUser/Security/login.html.twig", 69)->display($context);
        // line 70
        echo "                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <!--************************************
                Footer Start
        *************************************-->
        ";
        // line 90
        $this->loadTemplate("default/footer.html.twig", "@FOSUser/Security/login.html.twig", 90)->display($context);
        // line 91
        echo "        <!--************************************
                Footer End
        *************************************-->
    </div>
    <!--************************************
            Wrapper End
    *************************************-->

    </body>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 91,  143 => 90,  121 => 70,  119 => 69,  71 => 23,  69 => 22,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <body class=\"tg-login\">
    <!--[if lt IE 8]>
    <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <!--************************************
            Preloader Start
    *************************************-->
    <div class=\"preloader-outer\">
        <div class=\"pin\"></div>
        <div class=\"pulse\"></div>
    </div>
    <!--************************************
            Wrapper Start
    *************************************-->
    <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
        <!--************************************
                Header Start
        *************************************-->
        {% include ('default/header.html.twig') %}
        <!--************************************
                Header End
        *************************************-->
        <!--************************************
                Home Banner Start
        *************************************-->
        <div class=\"tg-pageinnerbanner tg-haslayout tg-parallaximg\" data-appear-top-offset=\"600\" data-parallax=\"scroll\" data-image-src=\"images/banner/img-02.jpg\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12 col-xs-12\">
                        <div class=\"tg-pageheadcontent\">
                            <div class=\"tg-pagetitle\">
                                <h1>Connexion / Créer un compte</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--************************************
                Home Banner End
        *************************************-->
        <!--************************************
                Main Start
        *************************************-->
        <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
            <div class=\"container\">
                <div class=\"row\">
                    <div id=\"tg-twocolumns\" class=\"tg-twocolumns\">
                        <div class=\"col-md-offset-2 col-sm-offset-2 col-md-8 col-sm-8 col-xs-12\">
                            <div id=\"tg-content\" class=\"tg-content\">
                                <div class=\"tg-signinsignup\">
                                    <div class=\"tg-title\" id=\"titleInscription\">
                                        <h2>Inscrivez-vous dès maintenant</h2>
                                    </div>
                                    <div class=\"tg-title\" id=\"titleConnexion\" hidden>
                                        <h2>Se connecter</h2>
                                    </div>

                                    <div class=\"tg-dashboardtabs\">
                                        <div class=\"tab-content tg-dashboardtabcontent\">
                                            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                                <div class=\"tg-searchbulder\">
                                                    <div id=\"tg-subcategories\" class=\"tg-subcategories\">
                                                        <div id=\"doctorscategory\" class=\"tg-tabcontent tg-active\">
                                                            <div id=\"formAddDoctor\">
                                                                {% include ('user/login2.html.twig') %}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <!--************************************
                Footer Start
        *************************************-->
        {% include ('default/footer.html.twig') %}
        <!--************************************
                Footer End
        *************************************-->
    </div>
    <!--************************************
            Wrapper End
    *************************************-->

    </body>
{% endblock %}
", "@FOSUser/Security/login.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Security\\login.html.twig");
    }
}

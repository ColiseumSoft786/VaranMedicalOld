<?php

/* user/login_content.html */
class __TwigTemplate_e9b5ff576a0fea99564f5e9308a10e4c2bdf127e25f18a00153b875ecc5854ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login_content.html"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login_content.html"));

        // line 1
        echo "<form  method=\"post\" action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" class=\"tg-formtheme tg-formsigninsignup\" autocomplete=\"off\">
<fieldset>
    ";
        // line 3
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 4
            echo "    <div class=\"row\">
        <div class=\"col-sm-12 col-xs-12\">
            <div class=\"tg-alertmessages\">
                <div class=\"alert alert-danger tg-alertmessage fade in\">
                    <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                    <i class=\"fa fa-bug\"></i>
                    <span><strong>Error Message.</strong> ";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</span>
                </div>
            </div>
        </div>
    </div>
    ";
        }
        // line 16
        echo "    ";
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 17
            echo "    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
    ";
        }
        // line 19
        echo "    <br/><br/>
    <div class=\"row tg-rowmargin\">
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" class=\"form-control\" placeholder=\"Nom d\\'utilisateur\"/>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"  placeholder=\"Mot de passe\"/>
            </div>
        </div>
        <div class=\"tg-kepploginpassword\">
            <div class=\"tg-checkbox\">
                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                <label for=\"keeplogin\">Garder ma session active</label>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <button type=\"submit\" class=\"tg-btn pull-right\" id=\"_submit\" name=\"_submit\">Se connecter</button>
        </div>
    </div>
</fieldset>
</form>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/login_content.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 23,  59 => 19,  53 => 17,  50 => 16,  41 => 10,  33 => 4,  31 => 3,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<form  method=\"post\" action=\"{{ path(\"fos_user_security_check\") }}\" class=\"tg-formtheme tg-formsigninsignup\" autocomplete=\"off\">
<fieldset>
    {% if error %}
    <div class=\"row\">
        <div class=\"col-sm-12 col-xs-12\">
            <div class=\"tg-alertmessages\">
                <div class=\"alert alert-danger tg-alertmessage fade in\">
                    <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                    <i class=\"fa fa-bug\"></i>
                    <span><strong>Error Message.</strong> {{ error.messageKey|trans(error.messageData, 'security') }}</span>
                </div>
            </div>
        </div>
    </div>
    {% endif %}
    {% if csrf_token %}
    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
    {% endif %}
    <br/><br/>
    <div class=\"row tg-rowmargin\">
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" class=\"form-control\" placeholder=\"Nom d\\'utilisateur\"/>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"  placeholder=\"Mot de passe\"/>
            </div>
        </div>
        <div class=\"tg-kepploginpassword\">
            <div class=\"tg-checkbox\">
                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                <label for=\"keeplogin\">Garder ma session active</label>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <button type=\"submit\" class=\"tg-btn pull-right\" id=\"_submit\" name=\"_submit\">Se connecter</button>
        </div>
    </div>
</fieldset>
</form>
", "user/login_content.html", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\login_content.html");
    }
}

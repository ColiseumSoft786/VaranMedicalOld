<?php

/* AppointmentsBundle:Appointments:display.html.twig */
class __TwigTemplate_be2ca52b5e19b7205c4e9e8510c3e60b2f8e55b689d1c20e9ba7e7229f5355a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppointmentsBundle:Appointments:display.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "AppointmentsBundle:Appointments:display.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
        ";
        // line 7
        echo "        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <script>
                        var vtype;
                        var cutcopyid;
                    </script>
                    <div id=\"cutt_copy\" style=\"display: none;z-index: 9999;background-color: rgba(255,255,255,0.91);position: fixed;width: 80%;top: 0;right: 0;height: 650px\">
                        <div style=\"padding: 10px\">
                            <div class=\"pull-right\">
                                <a href=\"javascript:void(0)\" onclick=\"\$('#cutt_copy').fadeOut()\"><span class=\"fa fa-close\"></span></a>
                            </div>
                            <div>
                                <div class=\"col-xs-12\">
                                    <style>
                                        .mybadge:hover{
                                            background-color: #0b3e6f !important;
                                            transition: 1s !important;
                                        }
                                    </style>
                                    <div class=\"col-md-12\">
                                        <h3 id=\"cut_copy_head\">Cut your appointment</h3>
                                    </div>
                                    <div class=\"col-md-offset-4 col-md-4\">
                                        <label for=\"\">Select Location</label>
                                        <select onchange=\"getseance(this.value)\" class=\"form-control\">
                                            <option value=\"0\">- Select Location -</option>
                                            ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["location"] ?? $this->getContext($context, "location")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 44
            echo "                                                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</option>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                                        </select>
                                    </div>
                                    <script>
                                        function getseance(id){
                                            \$.ajax({
                                                url: '";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_seancebylocation");
        echo "?id='+id,
                                                type: 'POST',
                                                success: function(result){
                                                    \$('#cut_copy_data').html(result);
                                                }
                                            });
                                        }

                                    </script>
                                    <div id=\"cut_copy_data\" style=\"max-height: 500px;overflow: auto\" class=\"col-md-offset-1 col-md-10\">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            ";
        // line 73
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 74
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 75
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 78
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 82
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 83
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 87
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 92
        echo "                                        </figure>

                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 95
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 103
        $this->loadTemplate("profilDoctorNav.html.twig", "AppointmentsBundle:Appointments:display.html.twig", 103)->display($context);
        // line 104
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <h2>Appointments</h2>

                                <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"prevdate()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            <span class=\"fa fa-angle-double-left\"></span> Prev
                                        </a>
                                    </div>
                                    <div class=\"col-xs-6\">
                                        <input id=\"ddate\" type=\"date\" onchange=\"getdisplaybydate(this.value)\" value=\"";
        // line 115
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                                    </div>
                                    <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"nextdate()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            Next <span class=\"fa fa-angle-double-right\"></span>
                                        </a>
                                    </div>
                                <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"printDiv()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            Print <span class=\"fa fa-print\"></span>
                                        </a>
                                    </div>
                                <script>
                                    function printDiv()
                                    {
                                        var divToPrint=document.getElementById('divtoprint');
                                        console.log(divToPrint.innerHTML);
                                        var newWin=window.open('','Print-Window');
                                        newWin.document.open();
                                        newWin.document.write('<html><head></head>');
                                        newWin.document.write('<body onload=\"window.print()\">'+divToPrint.innerHTML+'</body></html>');
                                        newWin.document.close();
                                        /*setTimeout(function(){newWin.close();},10);*/

                                    }
                                    function nextdate(){
                                        var d = new Date(\$('#ddate').val());
                                        d.setDate(d.getDate() + 1);
                                        var curr_date = d.getDate();
                                        var curr_month = d.getMonth() + 1; //Months are zero based
                                        if (curr_month < 10){
                                            curr_month = \"0\"+curr_month;
                                        }if (curr_date < 10){
                                            curr_date = \"0\"+curr_date;
                                        }
                                        var curr_year = d.getFullYear();
                                        var date = curr_year + \"-\" + curr_month + \"-\" + curr_date;
                                        \$('#ddate').val(date);
                                        getdisplaybydate(date);

                                    }
                                    function prevdate(){
                                        var d = new Date(\$('#ddate').val());
                                        d.setDate(d.getDate() - 1);
                                        var curr_date = d.getDate();
                                        var curr_month = d.getMonth() + 1; //Months are zero based
                                        if (curr_month < 10){
                                            curr_month = \"0\"+curr_month;
                                        }
                                        if (curr_date < 10){
                                            curr_date = \"0\"+curr_date;
                                        }
                                        var curr_year = d.getFullYear();
                                        var date = curr_year + \"-\" + curr_month + \"-\" + curr_date;
                                        \$('#ddate').val(date);
                                        getdisplaybydate(date);

                                    }

                                    function getdisplaybydate(date){
                                        \$('#bydate').hide();
                                        \$('#loaddate').fadeIn();
                                        \$.ajax({
                                            url: '";
        // line 178
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_displaybydate");
        echo "?date='+date,
                                            type: 'get',
                                            success: function(result){
                                                \$('#bydate').html(result);
                                                \$('#bydate').fadeIn();
                                                \$('#loaddate').hide();
                                            }
                                        })
                                    }
                                    function reminder(app){
                                        \$.ajax({
                                            url: '";
        // line 189
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_appointment_reminder");
        echo "?app='+app,
                                            type: 'get',
                                            success: function(result){
                                                if (result == 'true'){
                                                    alert('Reminder Sent !');
                                                }
                                            }
                                        })
                                    }
                                </script>
                                <div  class=\"col-md-12\" style=\"margin-top: 20px\">
                                    <div id=\"bydate\">
                                        ";
        // line 201
        if ((twig_length_filter($this->env, ($context["appointment"] ?? $this->getContext($context, "appointment"))) != 0)) {
            // line 202
            echo "                                            <div id=\"divtoprint\">
                                                <style>
                                                    @media print {
                                                        .nodisplay{
                                                            display: none;
                                                        }
                                                    }
                                                </style>
                                                <h4>List Of Appointments</h4>
                                                <table>
                                                    ";
            // line 212
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["appointment"] ?? $this->getContext($context, "appointment")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 213
                echo "                                                        ";
                if ((twig_date_format_filter($this->env, "now", "Y-m-d") < twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y-m-d"))) {
                    // line 214
                    echo "                                                            <tr ondblclick=\"\$('#appmodal').modal('show');getappointment(";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\">
                                                                <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                    <label style=\"font-size: 20px;\">";
                    // line 216
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "d M"), "html", null, true);
                    echo "</label><label style=\"font-size: 20px;\">";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y"), "html", null, true);
                    echo "</label> </td>
                                                                <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;background-color: #c1e9fe;\">
                                                                    <label style=\"font-size: 18px\"><b>";
                    // line 218
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurDebut", array()), "H:i"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurFin", array()), "H:i"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
                    echo "</b>
                                                                        <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat";
                    // line 220
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                                                    ";
                    // line 221
                    if (($this->getAttribute($context["item"], "etat", array()) == "confirme")) {
                        // line 222
                        echo "                                                                        <a href=\"javascript:void(0)\"  class=\"badge\" style=\"background: green\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } elseif (($this->getAttribute(                    // line 223
$context["item"], "etat", array()) == "non confirmer")) {
                        // line 224
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: orangered\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } else {
                        // line 226
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                    ";
                    }
                    // line 228
                    echo "
                                                                </span>
                                                                <a href=\"javascript:void(0)\" onclick=\"\$('#remindermodal').modal('show');\$('#reminderapp').val('";
                    // line 230
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "')\" class=\"badge\" style=\"background: black\">Send Reminder</a>

                                                                <a href=\"javascript:void(0)\" onclick=\"showmodelcutcopy('cut',";
                    // line 232
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\" class=\"badge\"><span class=\"fa fa-cut\"></span></a>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',";
                    // line 233
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>

                                                                    </label> <br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>";
                    // line 237
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
                    echo "</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>Patient: ";
                    // line 238
                    echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getpatientbyUser", array("id" => $this->getAttribute($this->getAttribute($context["item"], "patient", array()), "idtable", array()))));
                    echo ", Reason: ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "reason", array()), "reason", array()), "html", null, true);
                    echo "
                                                                    </label>
                                                                    <div>

                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        ";
                } else {
                    // line 246
                    echo "                                                            <tr  ondblclick=\"\$('#appmodal').modal('show');getappointment(";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\">
                                                                <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                    <label style=\"font-size: 20px;\">";
                    // line 248
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "d M"), "html", null, true);
                    echo "</label><label style=\"font-size: 20px;\">";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y"), "html", null, true);
                    echo "</label> </td>
                                                                <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;\">
                                                                    <label style=\"font-size: 18px\"><b>";
                    // line 250
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurDebut", array()), "H:i"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurFin", array()), "H:i"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
                    echo "</b>
                                                                        <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat";
                    // line 252
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                                                    ";
                    // line 253
                    if (($this->getAttribute($context["item"], "etat", array()) == "confirme")) {
                        // line 254
                        echo "                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                        echo ")\" class=\"badge\" style=\"background: green\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } elseif (($this->getAttribute(                    // line 255
$context["item"], "etat", array()) == "non confirmer")) {
                        // line 256
                        echo "                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                        echo ")\" class=\"badge\" style=\"background: orangered\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } else {
                        // line 258
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                    ";
                    }
                    // line 260
                    echo "
                                                                </span>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',";
                    // line 262
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>
                                                                    </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>";
                    // line 265
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
                    echo "</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>Patient: ";
                    // line 266
                    echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getpatientbyUser", array("id" => $this->getAttribute($this->getAttribute($context["item"], "patient", array()), "idtable", array()))));
                    echo ", Reason: ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "reason", array()), "reason", array()), "html", null, true);
                    echo "
                                                                    </label>
                                                                </td>
                                                            </tr>
                                                        ";
                }
                // line 271
                echo "
                                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 273
            echo "
                                                </table>
                                            </div>

                                            <script>




                                                function performaction(newid){
                                                    if(confirm(\"Really want to \"+vtype+\" this appontment to new place ?\")){
                                                        window.location = \"";
            // line 284
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_cutcopy");
            echo "?type=\"+vtype+\"&app=\"+cutcopyid+\"&sea=\"+newid;
                                                    }
                                                }
                                                function showmodelcutcopy(type,id){
                                                    vtype = type;
                                                    cutcopyid = id;
                                                    if(type == \"cut\"){
                                                        \$('#cut_copy_head').html('Cut your appointment');
                                                    }else{
                                                        \$('#cut_copy_head').html('Copy your appointment');

                                                    }
                                                    \$('#cutt_copy').fadeIn();

                                                }
                                                function updatestatus(id){
                                                    \$.ajax({
                                                        url: '";
            // line 301
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_update");
            echo "?id='+id,
                                                        type: 'POST',
                                                        success: function(result){
                                                            if(result === 'confirme'){
                                                                \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: green\">'+result+'</a>')
                                                            }else{
                                                                \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: orangered\">'+result+'</a>')
                                                            }
                                                        }
                                                    })
                                                }
                                            </script>
                                        ";
        } else {
            // line 314
            echo "                                            <p class=\"text-center\">You have no Appointments till now.</p>
                                        ";
        }
        // line 316
        echo "                                    </div>
                                    <div id=\"loaddate\" style=\"display: none;\">
                                        <p class=\"text-center\"><label for=\"\">Loading...</label></p>
                                    </div>

                                </div>






                                ";
        // line 357
        echo "                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </main>

        <!-- Trigger the modal with a button -->

        <!-- Modal -->
        <div id=\"appmodal\" class=\"modal fade\" role=\"dialog\">
            <div class=\"modal-dialog\">

                <!-- Modal content-->
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h4 class=\"modal-title\">Appointment Information</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div id=\"appload\" style=\"display: none\">
                            <p class=\"text-center\">Loading...</p>
                        </div>
                        <div id=\"appbody\">

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div id=\"remindermodal\" class=\"modal fade\" role=\"dialog\">
            <div class=\"modal-dialog\">

                <!-- Modal content-->
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h4 class=\"modal-title\">Reminder Attachment</h4>
                    </div>
                    <div class=\"modal-body\">
                        <form enctype=\"multipart/form-data\" action=\"";
        // line 399
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_appointment_reminder");
        echo "\" method=\"POST\">
                            <label for=\"\">Select Attachment for Email, Leave blank if it there is no</label>
                            <input type=\"file\" name=\"attach\" class=\"form-control\">
                            <input type=\"hidden\" id=\"reminderapp\" name=\"app\" class=\"form-control\">
                            <input type=\"submit\" value=\"Send Reminder\" class=\"btn btn-primary pull-right\" style=\"margin-top: 10px\">
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <script>
            function getappointment(app){
                \$('#appload').show();
                \$('#appbody').hide();
                \$.ajax({
                    url: '";
        // line 415
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_appointment_getappointment");
        echo "?app='+app,
                    type: 'POST',
                    success: function (result) {
                        \$('#appload').hide();
                        \$('#appbody').show();
                        \$('#appbody').html(result);
                    }
                })
            }
        </script>


        ";
        // line 427
        $this->loadTemplate("default/footer.html.twig", "AppointmentsBundle:Appointments:display.html.twig", 427)->display($context);
        // line 428
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AppointmentsBundle:Appointments:display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  641 => 428,  639 => 427,  624 => 415,  605 => 399,  561 => 357,  547 => 316,  543 => 314,  527 => 301,  507 => 284,  494 => 273,  487 => 271,  477 => 266,  473 => 265,  467 => 262,  463 => 260,  457 => 258,  449 => 256,  447 => 255,  440 => 254,  438 => 253,  434 => 252,  425 => 250,  418 => 248,  412 => 246,  399 => 238,  395 => 237,  388 => 233,  384 => 232,  379 => 230,  375 => 228,  369 => 226,  363 => 224,  361 => 223,  356 => 222,  354 => 221,  350 => 220,  341 => 218,  334 => 216,  328 => 214,  325 => 213,  321 => 212,  309 => 202,  307 => 201,  292 => 189,  278 => 178,  212 => 115,  199 => 104,  197 => 103,  191 => 102,  179 => 95,  174 => 92,  166 => 87,  160 => 83,  157 => 82,  151 => 79,  148 => 78,  140 => 75,  137 => 74,  135 => 73,  110 => 51,  103 => 46,  92 => 44,  88 => 43,  54 => 12,  47 => 7,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}

        {#<body class=\"tg-home tg-login\">#}
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <script>
                        var vtype;
                        var cutcopyid;
                    </script>
                    <div id=\"cutt_copy\" style=\"display: none;z-index: 9999;background-color: rgba(255,255,255,0.91);position: fixed;width: 80%;top: 0;right: 0;height: 650px\">
                        <div style=\"padding: 10px\">
                            <div class=\"pull-right\">
                                <a href=\"javascript:void(0)\" onclick=\"\$('#cutt_copy').fadeOut()\"><span class=\"fa fa-close\"></span></a>
                            </div>
                            <div>
                                <div class=\"col-xs-12\">
                                    <style>
                                        .mybadge:hover{
                                            background-color: #0b3e6f !important;
                                            transition: 1s !important;
                                        }
                                    </style>
                                    <div class=\"col-md-12\">
                                        <h3 id=\"cut_copy_head\">Cut your appointment</h3>
                                    </div>
                                    <div class=\"col-md-offset-4 col-md-4\">
                                        <label for=\"\">Select Location</label>
                                        <select onchange=\"getseance(this.value)\" class=\"form-control\">
                                            <option value=\"0\">- Select Location -</option>
                                            {% for item in location %}
                                                <option value=\"{{ item.id }}\">{{ item.name }}</option>
                                            {% endfor %}
                                        </select>
                                    </div>
                                    <script>
                                        function getseance(id){
                                            \$.ajax({
                                                url: '{{ path('calendries_appoitment_seancebylocation') }}?id='+id,
                                                type: 'POST',
                                                success: function(result){
                                                    \$('#cut_copy_data').html(result);
                                                }
                                            });
                                        }

                                    </script>
                                    <div id=\"cut_copy_data\" style=\"max-height: 500px;overflow: auto\" class=\"col-md-offset-1 col-md-10\">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>

                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.idTable }) }}\">{{ 'Profile'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <h2>Appointments</h2>

                                <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"prevdate()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            <span class=\"fa fa-angle-double-left\"></span> Prev
                                        </a>
                                    </div>
                                    <div class=\"col-xs-6\">
                                        <input id=\"ddate\" type=\"date\" onchange=\"getdisplaybydate(this.value)\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                                    </div>
                                    <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"nextdate()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            Next <span class=\"fa fa-angle-double-right\"></span>
                                        </a>
                                    </div>
                                <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"printDiv()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            Print <span class=\"fa fa-print\"></span>
                                        </a>
                                    </div>
                                <script>
                                    function printDiv()
                                    {
                                        var divToPrint=document.getElementById('divtoprint');
                                        console.log(divToPrint.innerHTML);
                                        var newWin=window.open('','Print-Window');
                                        newWin.document.open();
                                        newWin.document.write('<html><head></head>');
                                        newWin.document.write('<body onload=\"window.print()\">'+divToPrint.innerHTML+'</body></html>');
                                        newWin.document.close();
                                        /*setTimeout(function(){newWin.close();},10);*/

                                    }
                                    function nextdate(){
                                        var d = new Date(\$('#ddate').val());
                                        d.setDate(d.getDate() + 1);
                                        var curr_date = d.getDate();
                                        var curr_month = d.getMonth() + 1; //Months are zero based
                                        if (curr_month < 10){
                                            curr_month = \"0\"+curr_month;
                                        }if (curr_date < 10){
                                            curr_date = \"0\"+curr_date;
                                        }
                                        var curr_year = d.getFullYear();
                                        var date = curr_year + \"-\" + curr_month + \"-\" + curr_date;
                                        \$('#ddate').val(date);
                                        getdisplaybydate(date);

                                    }
                                    function prevdate(){
                                        var d = new Date(\$('#ddate').val());
                                        d.setDate(d.getDate() - 1);
                                        var curr_date = d.getDate();
                                        var curr_month = d.getMonth() + 1; //Months are zero based
                                        if (curr_month < 10){
                                            curr_month = \"0\"+curr_month;
                                        }
                                        if (curr_date < 10){
                                            curr_date = \"0\"+curr_date;
                                        }
                                        var curr_year = d.getFullYear();
                                        var date = curr_year + \"-\" + curr_month + \"-\" + curr_date;
                                        \$('#ddate').val(date);
                                        getdisplaybydate(date);

                                    }

                                    function getdisplaybydate(date){
                                        \$('#bydate').hide();
                                        \$('#loaddate').fadeIn();
                                        \$.ajax({
                                            url: '{{ path('appointments_displaybydate') }}?date='+date,
                                            type: 'get',
                                            success: function(result){
                                                \$('#bydate').html(result);
                                                \$('#bydate').fadeIn();
                                                \$('#loaddate').hide();
                                            }
                                        })
                                    }
                                    function reminder(app){
                                        \$.ajax({
                                            url: '{{ path('appointments_appointment_reminder') }}?app='+app,
                                            type: 'get',
                                            success: function(result){
                                                if (result == 'true'){
                                                    alert('Reminder Sent !');
                                                }
                                            }
                                        })
                                    }
                                </script>
                                <div  class=\"col-md-12\" style=\"margin-top: 20px\">
                                    <div id=\"bydate\">
                                        {% if appointment|length != 0 %}
                                            <div id=\"divtoprint\">
                                                <style>
                                                    @media print {
                                                        .nodisplay{
                                                            display: none;
                                                        }
                                                    }
                                                </style>
                                                <h4>List Of Appointments</h4>
                                                <table>
                                                    {% for item in appointment %}
                                                        {% if \"now\"|date(\"Y-m-d\") < item.seance.calendrie.date|date('Y-m-d')  %}
                                                            <tr ondblclick=\"\$('#appmodal').modal('show');getappointment({{ item.id }})\">
                                                                <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                    <label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('d M') }}</label><label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('Y') }}</label> </td>
                                                                <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;background-color: #c1e9fe;\">
                                                                    <label style=\"font-size: 18px\"><b>{{ item.seance.heurDebut|date('H:i') }} - {{ item.seance.heurFin|date('H:i') }}, {{ item.seance.calendrie.location.name }}</b>
                                                                        <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat{{ item.id }}\">
                                                                    {% if item.etat == 'confirme' %}
                                                                        <a href=\"javascript:void(0)\"  class=\"badge\" style=\"background: green\">{{ item.etat }}</a>
                                                                        {% elseif item.etat == 'non confirmer' %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: orangered\">{{ item.etat }}</a>
                                                                        {% else %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">{{ item.etat }}</a>
                                                                    {% endif %}

                                                                </span>
                                                                <a href=\"javascript:void(0)\" onclick=\"\$('#remindermodal').modal('show');\$('#reminderapp').val('{{ item.id }}')\" class=\"badge\" style=\"background: black\">Send Reminder</a>

                                                                <a href=\"javascript:void(0)\" onclick=\"showmodelcutcopy('cut',{{ item.id }})\" class=\"badge\"><span class=\"fa fa-cut\"></span></a>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',{{ item.id }})\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>

                                                                    </label> <br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>{{ item.seance.calendrie.location.adresse }}</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>Patient: {{ render(controller('AppointmentsBundle:Appointments:getpatientbyUser', {'id': item.patient.idtable})) }}, Reason: {{ item.reason.reason }}
                                                                    </label>
                                                                    <div>

                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        {% else %}
                                                            <tr  ondblclick=\"\$('#appmodal').modal('show');getappointment({{ item.id }})\">
                                                                <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                    <label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('d M') }}</label><label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('Y') }}</label> </td>
                                                                <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;\">
                                                                    <label style=\"font-size: 18px\"><b>{{ item.seance.heurDebut|date('H:i') }} - {{ item.seance.heurFin|date('H:i') }}, {{ item.seance.calendrie.location.name }}</b>
                                                                        <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat{{ item.id }}\">
                                                                    {% if item.etat == 'confirme' %}
                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus({{ item.id }})\" class=\"badge\" style=\"background: green\">{{ item.etat }}</a>
                                                                        {% elseif item.etat == 'non confirmer' %}
                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus({{ item.id }})\" class=\"badge\" style=\"background: orangered\">{{ item.etat }}</a>
                                                                        {% else %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">{{ item.etat }}</a>
                                                                    {% endif %}

                                                                </span>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',{{ item.id }})\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>
                                                                    </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>{{ item.seance.calendrie.location.adresse }}</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                    <label>Patient: {{ render(controller('AppointmentsBundle:Appointments:getpatientbyUser', {'id': item.patient.idtable})) }}, Reason: {{ item.reason.reason }}
                                                                    </label>
                                                                </td>
                                                            </tr>
                                                        {% endif %}

                                                    {% endfor %}

                                                </table>
                                            </div>

                                            <script>




                                                function performaction(newid){
                                                    if(confirm(\"Really want to \"+vtype+\" this appontment to new place ?\")){
                                                        window.location = \"{{ path('calendries_appoitment_cutcopy') }}?type=\"+vtype+\"&app=\"+cutcopyid+\"&sea=\"+newid;
                                                    }
                                                }
                                                function showmodelcutcopy(type,id){
                                                    vtype = type;
                                                    cutcopyid = id;
                                                    if(type == \"cut\"){
                                                        \$('#cut_copy_head').html('Cut your appointment');
                                                    }else{
                                                        \$('#cut_copy_head').html('Copy your appointment');

                                                    }
                                                    \$('#cutt_copy').fadeIn();

                                                }
                                                function updatestatus(id){
                                                    \$.ajax({
                                                        url: '{{ path('calendries_appoitment_update') }}?id='+id,
                                                        type: 'POST',
                                                        success: function(result){
                                                            if(result === 'confirme'){
                                                                \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: green\">'+result+'</a>')
                                                            }else{
                                                                \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: orangered\">'+result+'</a>')
                                                            }
                                                        }
                                                    })
                                                }
                                            </script>
                                        {% else %}
                                            <p class=\"text-center\">You have no Appointments till now.</p>
                                        {% endif %}
                                    </div>
                                    <div id=\"loaddate\" style=\"display: none;\">
                                        <p class=\"text-center\"><label for=\"\">Loading...</label></p>
                                    </div>

                                </div>






                                {#<div class=\"\" style=\"\">
                                    <div class=\"row\">
                                        <div class=\"col-md-1\" style=\"border: 1px solid skyblue;border-top:2px solid skyblue; padding:0px 20px 2px 20px; height: 70px;\">
                                            <p style=\"font-size: 19px; padding: 18px; color: #464e52;\">01</p>
                                        </div>
                                        <div class=\"col-md-11\" style=\"margin: 0px; padding: 0px; height: 70px; background-color: #83c1f4;\">
                                            <div class=\"col-md-12\" style=\"background-color: #c1e9fe; height: 64px; margin-left: 20px; width: 98%;\">
                                                <p style=\"margin: 0px; padding: 0; font-size: 16px; font-weight: bold;\">slakdjf</p>
                                                <p style=\"margin: 0px; padding: 0;\">slakdjf</p>
                                                <p style=\"margin: 0px; padding: 0;\">slakdjf</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class=\"row\">

                                        <div class=\"col-md-1\" style=\"border: 1px solid skyblue; padding:0px 20px 2px 20px; height: 65px;\">
                                            <p style=\"font-size: 19px; padding: 18px; color: #464e52;\">05</p>
                                        </div>
                                        <div class=\"col-md-11\" style=\"margin: 0px; padding: 0px; height: 64px;\">
                                            <div class=\"col-md-12\" style=\"eight: 64px; margin-left: 20px; width: 98%;\">
                                                <p></p>
                                                <p></p>
                                                <p></p>
                                            </div>
                                        </div>
                                    </div>

                                </div>#}
                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </main>

        <!-- Trigger the modal with a button -->

        <!-- Modal -->
        <div id=\"appmodal\" class=\"modal fade\" role=\"dialog\">
            <div class=\"modal-dialog\">

                <!-- Modal content-->
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h4 class=\"modal-title\">Appointment Information</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div id=\"appload\" style=\"display: none\">
                            <p class=\"text-center\">Loading...</p>
                        </div>
                        <div id=\"appbody\">

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div id=\"remindermodal\" class=\"modal fade\" role=\"dialog\">
            <div class=\"modal-dialog\">

                <!-- Modal content-->
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                        <h4 class=\"modal-title\">Reminder Attachment</h4>
                    </div>
                    <div class=\"modal-body\">
                        <form enctype=\"multipart/form-data\" action=\"{{ path('appointments_appointment_reminder') }}\" method=\"POST\">
                            <label for=\"\">Select Attachment for Email, Leave blank if it there is no</label>
                            <input type=\"file\" name=\"attach\" class=\"form-control\">
                            <input type=\"hidden\" id=\"reminderapp\" name=\"app\" class=\"form-control\">
                            <input type=\"submit\" value=\"Send Reminder\" class=\"btn btn-primary pull-right\" style=\"margin-top: 10px\">
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <script>
            function getappointment(app){
                \$('#appload').show();
                \$('#appbody').hide();
                \$.ajax({
                    url: '{{ path('appointments_appointment_getappointment') }}?app='+app,
                    type: 'POST',
                    success: function (result) {
                        \$('#appload').hide();
                        \$('#appbody').show();
                        \$('#appbody').html(result);
                    }
                })
            }
        </script>


        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}
", "AppointmentsBundle:Appointments:display.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AppointmentsBundle/Resources/views/Appointments/display.html.twig");
    }
}

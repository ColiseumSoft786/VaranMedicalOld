<?php

/* DoctorsBundle:Patient:details.html.twig */
class __TwigTemplate_4b7176704238a8742cbb103385a07726fdd3018af23f5ee3572f542a0f1e8575 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "DoctorsBundle:Patient:details.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "DoctorsBundle:Patient:details.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
        ";
        // line 7
        echo "        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">

                    <div id=\"cutt_copy\" style=\"display: none;z-index: 9999;background-color: rgba(255,255,255,0.91);position: fixed;width: 80%;top: 0;right: 0;height: 650px\">
                        <div style=\"padding: 10px\">
                            <div class=\"pull-right\">
                                <a href=\"javascript:void(0)\" onclick=\"\$('#cutt_copy').fadeOut()\"><span class=\"fa fa-close\"></span></a>
                            </div>
                            <div>
                                <h2>Edit Your Patient</h2>
                                <div class=\"col-md-offset-2 col-md-8\">
                                    <form action=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("patient_doctor_display_updatepatient");
        echo "\" method=\"post\">
                                        <input type=\"hidden\" name=\"id\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "id", array()), "html", null, true);
        echo "\">
                                        <input type=\"hidden\" name=\"dp\" value=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "id", array()), "html", null, true);
        echo "\">

                                    <div class=\"col-md-6\">
                                        <label for=\"fname\">First Name</label>
                                        <input class=\"form-control\" value=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstname", array()), "html", null, true);
        echo "\" id=\"fname\" name=\"fname\" type=\"text\" placeholder=\"First Name\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"lname\">Last Name</label>
                                        <input class=\"form-control\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastname", array()), "html", null, true);
        echo "\" id=\"lname\" name=\"lname\" type=\"text\" placeholder=\"Last Name\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"dob\">Birthday</label>
                                        <input class=\"form-control\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "birthday", array()), "Y-m-d"), "html", null, true);
        echo "\" id=\"dob\" name=\"dob\" type=\"date\" placeholder=\"Date Of Birth\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"domicil\">Domicile</label>
                                        <input class=\"form-control\" value=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "domicile", array()), "html", null, true);
        echo "\" id=\"domicil\" name=\"domicil\" type=\"text\" placeholder=\"Domicil\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"gsm\">GSM</label>
                                        <input class=\"form-control\" value=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "gsm", array()), "html", null, true);
        echo "\" id=\"gsm\" name=\"gsm\" type=\"text\" placeholder=\"GSM\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"travail\">Travail</label>
                                        <input class=\"form-control\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "travail", array()), "html", null, true);
        echo "\" id=\"travail\" name=\"travail\" type=\"text\" placeholder=\"Travail\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"pnum\">Prefered Number</label>
                                        <select class=\"form-control\" name=\"pnum\" id=\"pnum\">
                                            <option value=\"\">- Select Prefered Number -</option>
                                            <option value=\"gsm\"  ";
        // line 60
        if (($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "preferrednumber", array()) == "gsm")) {
            echo "selected";
        }
        echo " >GSM</option>
                                            <option value=\"travail\" ";
        // line 61
        if (($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "preferrednumber", array()) == "travail")) {
            echo "selected";
        }
        echo ">Travail</option>
                                        </select>
                                    </div>
                                    <div class=\"col-md-12\">
                                        <label for=\"address\">Address</label>
                                        <textarea class=\"form-control\" name=\"address\" id=\"address\">";
        // line 66
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "adresse", array()), "html", null, true);
        echo "</textarea>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"sex\">Sex</label>
                                        <select class=\"form-control\" name=\"sex\" id=\"sex\">
                                            <option value=\"\">- Select Sex -</option>
                                            <option value=\"Male\" ";
        // line 72
        if (($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "sexe", array()) == "Male")) {
            echo "selected";
        }
        echo ">Male</option>
                                            <option value=\"Female\" ";
        // line 73
        if (($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "sexe", array()) == "Female")) {
            echo "selected";
        }
        echo ">Female</option>
                                        </select>
                                    </div>
                                    <div class=\"col-md-12\">
                                        <input type=\"submit\" value=\"Update\" class=\"tg-btn pull-right\">
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            ";
        // line 93
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 94
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 95
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 98
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 99
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 102
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 103
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 107
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 112
        echo "                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 114
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 122
        $this->loadTemplate("profilDoctorNav.html.twig", "DoctorsBundle:Patient:details.html.twig", 122)->display($context);
        // line 123
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <script>
                                    function changename(){
                                        if(confirm('Are you sure to switch the first and lastname ?')){
                                            window.location = \"";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("patient_doctor_display_changename", array("id" => $this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "id", array()))), "html", null, true);
        echo "\";
                                        }

                                    }
                                </script>
                                <div class=\"col-md-9\">
                                    <h3>Patient Name: ";
        // line 135
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstname", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastname", array()), "html", null, true);
        echo " <a href=\"javascript:void(0)\" onclick=\"changename()\" class=\"badge\"><span class=\"fa fa-exchange\"></span></a></h3>
                                    <p><b>Birthday:</b> ";
        // line 136
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "birthday", array()), "d-M-Y"), "html", null, true);
        echo "</p>
                                    <p><b>Sex:</b> ";
        // line 137
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "sexe", array()), "html", null, true);
        echo "</p>
                                    <p><b>Address:</b> ";
        // line 138
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "adresse", array()), "html", null, true);
        echo "</p>
                                    <p><b>Email:</b> ";
        // line 139
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p>
                                    <p><b>Review:</b> ";
        // line 140
        if (($this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "review", array()) == "")) {
            echo " <label class=\"label label-warning\">Review not given</label> ";
        } else {
            echo "<span class=\"badge\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "review", array()), "html", null, true);
            echo "</span>";
        }
        echo " </p>
                                    <p><b>Status:</b> ";
        // line 141
        if (($this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "block", array()) == 1)) {
            echo "<span class=\"badge\" style=\"background-color: orangered\">Blocklisted</span>";
        } else {
            echo "<span class=\"badge\" style=\"background-color: yellowgreen\">Safe</span>";
        }
        echo "</p>
                                </div>
                                <div class=\"col-md-3\">
                                    <a class=\"tg-btn tg-btn-md btn-block\" href=\"";
        // line 144
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("patient_doctor_display_changestatus");
        echo "?id=";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "id", array()), "html", null, true);
        echo "\">";
        if (($this->getAttribute(($context["dp"] ?? $this->getContext($context, "dp")), "block", array()) == 1)) {
            echo "<span>unblock</span>";
        } else {
            echo "<span>block</span>";
        }
        echo "</a>
                                    <a class=\"tg-btn tg-btn-md btn-block\" onclick=\"\$('#cutt_copy').fadeIn()\" href=\"javascript:void(0)\">Edit Patient Record</a>
                                </div>
                                <div class=\"col-md-offset-4 col-md-4\">
                                    <button onclick=\"\$('#toggleapp').fadeIn()\" class=\"tg-btn tg-btn-md\">Show Appointments</button>
                                </div>

                                <div id=\"toggleapp\" style=\"display: none\">
                                    <div class=\"col-xs-10\">

                                    </div>
                                    <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"printDiv()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            Print <span class=\"fa fa-print\"></span>
                                        </a>
                                    </div>
                                    <script>
                                        function printDiv()
                                        {
                                            var divToPrint=document.getElementById('divtoprint');
                                            console.log(divToPrint.innerHTML);
                                            var newWin=window.open('','Print-Window');
                                            newWin.document.open();
                                            newWin.document.write('<html><head></head>');
                                            newWin.document.write('<body onload=\"window.print()\">'+divToPrint.innerHTML+'</body></html>');
                                            newWin.document.close();
                                            /*setTimeout(function(){newWin.close();},10);*/

                                        }
                                    </script>

                                    <div class=\"col-md-12\" style=\"margin-top: 20px\">
                                        <div >
                                            ";
        // line 177
        if ((twig_length_filter($this->env, ($context["appointment"] ?? $this->getContext($context, "appointment"))) != 0)) {
            // line 178
            echo "                                                <div id=\"divtoprint\">
                                                    <style>
                                                        @media print {
                                                            .nodisplay{
                                                                display: none;
                                                            }
                                                        }
                                                    </style>
                                                    <h4>List Of Appointments</h4>
                                                    <table id=\"apptable\">
                                                        ";
            // line 188
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, ($context["appointment"] ?? $this->getContext($context, "appointment"))));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 189
                echo "                                                            ";
                if ((twig_date_format_filter($this->env, "now", "Y-m-d") < twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y-m-d"))) {
                    // line 190
                    echo "                                                                <tr>
                                                                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                        <label style=\"font-size: 20px;\">";
                    // line 192
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "d M"), "html", null, true);
                    echo "</label><label style=\"font-size: 20px;\">";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y"), "html", null, true);
                    echo "</label> </td>
                                                                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;background-color: #c1e9fe;\">
                                                                        <label style=\"font-size: 18px\"><b>";
                    // line 194
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurDebut", array()), "H:i"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurFin", array()), "H:i"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
                    echo "</b>
                                                                            <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat";
                    // line 196
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                                                    ";
                    // line 197
                    if (($this->getAttribute($context["item"], "etat", array()) == "confirme")) {
                        // line 198
                        echo "                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                        echo ")\" class=\"badge\" style=\"background: green\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } elseif (($this->getAttribute(                    // line 199
$context["item"], "etat", array()) == "non confirmer")) {
                        // line 200
                        echo "                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                        echo ")\" class=\"badge\" style=\"background: orangered\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } else {
                        // line 202
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                    ";
                    }
                    // line 204
                    echo "                                                                </span>
                                                                        </span>

                                                                        </label> <br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>";
                    // line 208
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
                    echo "</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>Patient: ";
                    // line 209
                    echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getpatientbyUser", array("id" => $this->getAttribute($this->getAttribute($context["item"], "patient", array()), "idtable", array()))));
                    echo ", Reason: ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "reason", array()), "reason", array()), "html", null, true);
                    echo "
                                                                        </label>
                                                                        <div>

                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            ";
                } else {
                    // line 217
                    echo "                                                                <tr>
                                                                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                        <label style=\"font-size: 20px;\">";
                    // line 219
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "d M"), "html", null, true);
                    echo "</label><label style=\"font-size: 20px;\">";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y"), "html", null, true);
                    echo "</label> </td>
                                                                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;\">
                                                                        <label style=\"font-size: 18px\"><b>";
                    // line 221
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurDebut", array()), "H:i"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurFin", array()), "H:i"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
                    echo "</b>
                                                                            <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat";
                    // line 223
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                                                    ";
                    // line 224
                    if (($this->getAttribute($context["item"], "etat", array()) == "confirme")) {
                        // line 225
                        echo "                                                                        <a href=\"javascript:void(0)\"  class=\"badge\" style=\"background: green\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } elseif (($this->getAttribute(                    // line 226
$context["item"], "etat", array()) == "non confirmer")) {
                        // line 227
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: orangered\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } else {
                        // line 229
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                    ";
                    }
                    // line 231
                    echo "                                                                </span>
                                                            </span>
                                                                        </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>";
                    // line 234
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
                    echo "</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>Patient: ";
                    // line 235
                    echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getpatientbyUser", array("id" => $this->getAttribute($this->getAttribute($context["item"], "patient", array()), "idtable", array()))));
                    echo ", Reason: ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "reason", array()), "reason", array()), "html", null, true);
                    echo "
                                                                        </label>
                                                                    </td>
                                                                </tr>
                                                            ";
                }
                // line 240
                echo "
                                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 242
            echo "
                                                    </table>
                                                </div>

                                                <script>




                                                    function performaction(newid){
                                                        if(confirm(\"Really want to \"+vtype+\" this appontment to new place ?\")){
                                                            window.location = \"";
            // line 253
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_cutcopy");
            echo "?type=\"+vtype+\"&app=\"+cutcopyid+\"&sea=\"+newid;
                                                        }
                                                    }
                                                    function showmodelcutcopy(type,id){
                                                        vtype = type;
                                                        cutcopyid = id;
                                                        if(type == \"cut\"){
                                                            \$('#cut_copy_head').html('Cut your appointment');
                                                        }else{
                                                            \$('#cut_copy_head').html('Copy your appointment');

                                                        }
                                                        \$('#cutt_copy').fadeIn();

                                                    }
                                                    function updatestatus(id){
                                                        \$.ajax({
                                                            url: '";
            // line 270
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_update");
            echo "?id='+id,
                                                            type: 'POST',
                                                            success: function(result){
                                                                if(result === 'confirme'){
                                                                    \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: green\">'+result+'</a>')
                                                                }else{
                                                                    \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: orangered\">'+result+'</a>')
                                                                }
                                                            }
                                                        })
                                                    }
                                                </script>
                                            ";
        } else {
            // line 283
            echo "                                                <p class=\"text-center\">You have no Appointments till now.</p>
                                            ";
        }
        // line 285
        echo "                                        </div>
                                        <div id=\"loaddate\" style=\"display: none;\">
                                            <p class=\"text-center\"><label for=\"\">Loading...</label></p>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </main>




        ";
        // line 305
        $this->loadTemplate("default/footer.html.twig", "DoctorsBundle:Patient:details.html.twig", 305)->display($context);
        // line 306
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "DoctorsBundle:Patient:details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  595 => 306,  593 => 305,  571 => 285,  567 => 283,  551 => 270,  531 => 253,  518 => 242,  511 => 240,  501 => 235,  497 => 234,  492 => 231,  486 => 229,  480 => 227,  478 => 226,  473 => 225,  471 => 224,  467 => 223,  458 => 221,  451 => 219,  447 => 217,  434 => 209,  430 => 208,  424 => 204,  418 => 202,  410 => 200,  408 => 199,  401 => 198,  399 => 197,  395 => 196,  386 => 194,  379 => 192,  375 => 190,  372 => 189,  368 => 188,  356 => 178,  354 => 177,  310 => 144,  300 => 141,  290 => 140,  286 => 139,  282 => 138,  278 => 137,  274 => 136,  268 => 135,  259 => 129,  251 => 123,  249 => 122,  243 => 121,  231 => 114,  227 => 112,  219 => 107,  213 => 103,  210 => 102,  204 => 99,  201 => 98,  193 => 95,  190 => 94,  188 => 93,  163 => 73,  157 => 72,  148 => 66,  138 => 61,  132 => 60,  123 => 54,  116 => 50,  109 => 46,  102 => 42,  95 => 38,  88 => 34,  81 => 30,  77 => 29,  73 => 28,  54 => 12,  47 => 7,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}

        {#<body class=\"tg-home tg-login\">#}
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">

                    <div id=\"cutt_copy\" style=\"display: none;z-index: 9999;background-color: rgba(255,255,255,0.91);position: fixed;width: 80%;top: 0;right: 0;height: 650px\">
                        <div style=\"padding: 10px\">
                            <div class=\"pull-right\">
                                <a href=\"javascript:void(0)\" onclick=\"\$('#cutt_copy').fadeOut()\"><span class=\"fa fa-close\"></span></a>
                            </div>
                            <div>
                                <h2>Edit Your Patient</h2>
                                <div class=\"col-md-offset-2 col-md-8\">
                                    <form action=\"{{ path('patient_doctor_display_updatepatient') }}\" method=\"post\">
                                        <input type=\"hidden\" name=\"id\" value=\"{{ patient.id }}\">
                                        <input type=\"hidden\" name=\"dp\" value=\"{{ dp.id }}\">

                                    <div class=\"col-md-6\">
                                        <label for=\"fname\">First Name</label>
                                        <input class=\"form-control\" value=\"{{ patient.firstname }}\" id=\"fname\" name=\"fname\" type=\"text\" placeholder=\"First Name\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"lname\">Last Name</label>
                                        <input class=\"form-control\" value=\"{{ patient.lastname }}\" id=\"lname\" name=\"lname\" type=\"text\" placeholder=\"Last Name\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"dob\">Birthday</label>
                                        <input class=\"form-control\" value=\"{{ patient.birthday|date('Y-m-d') }}\" id=\"dob\" name=\"dob\" type=\"date\" placeholder=\"Date Of Birth\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"domicil\">Domicile</label>
                                        <input class=\"form-control\" value=\"{{ patient.domicile }}\" id=\"domicil\" name=\"domicil\" type=\"text\" placeholder=\"Domicil\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"gsm\">GSM</label>
                                        <input class=\"form-control\" value=\"{{ patient.gsm }}\" id=\"gsm\" name=\"gsm\" type=\"text\" placeholder=\"GSM\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"travail\">Travail</label>
                                        <input class=\"form-control\" value=\"{{ patient.travail }}\" id=\"travail\" name=\"travail\" type=\"text\" placeholder=\"Travail\">
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"pnum\">Prefered Number</label>
                                        <select class=\"form-control\" name=\"pnum\" id=\"pnum\">
                                            <option value=\"\">- Select Prefered Number -</option>
                                            <option value=\"gsm\"  {% if patient.preferrednumber == 'gsm' %}selected{% endif %} >GSM</option>
                                            <option value=\"travail\" {% if patient.preferrednumber == 'travail' %}selected{% endif %}>Travail</option>
                                        </select>
                                    </div>
                                    <div class=\"col-md-12\">
                                        <label for=\"address\">Address</label>
                                        <textarea class=\"form-control\" name=\"address\" id=\"address\">{{ patient.adresse }}</textarea>
                                    </div>
                                    <div class=\"col-md-6\">
                                        <label for=\"sex\">Sex</label>
                                        <select class=\"form-control\" name=\"sex\" id=\"sex\">
                                            <option value=\"\">- Select Sex -</option>
                                            <option value=\"Male\" {% if patient.sexe == 'Male' %}selected{% endif %}>Male</option>
                                            <option value=\"Female\" {% if patient.sexe == 'Female' %}selected{% endif %}>Female</option>
                                        </select>
                                    </div>
                                    <div class=\"col-md-12\">
                                        <input type=\"submit\" value=\"Update\" class=\"tg-btn pull-right\">
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.idTable }) }}\">{{ 'Profile'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <script>
                                    function changename(){
                                        if(confirm('Are you sure to switch the first and lastname ?')){
                                            window.location = \"{{ path('patient_doctor_display_changename',{id:dp.id}) }}\";
                                        }

                                    }
                                </script>
                                <div class=\"col-md-9\">
                                    <h3>Patient Name: {{ patient.firstname }} {{ patient.lastname }} <a href=\"javascript:void(0)\" onclick=\"changename()\" class=\"badge\"><span class=\"fa fa-exchange\"></span></a></h3>
                                    <p><b>Birthday:</b> {{ patient.birthday|date('d-M-Y') }}</p>
                                    <p><b>Sex:</b> {{ patient.sexe }}</p>
                                    <p><b>Address:</b> {{ patient.adresse }}</p>
                                    <p><b>Email:</b> {{ user.email }}</p>
                                    <p><b>Review:</b> {% if dp.review == \"\" %} <label class=\"label label-warning\">Review not given</label> {% else %}<span class=\"badge\">{{ dp.review }}</span>{% endif %} </p>
                                    <p><b>Status:</b> {% if dp.block == 1 %}<span class=\"badge\" style=\"background-color: orangered\">Blocklisted</span>{% else %}<span class=\"badge\" style=\"background-color: yellowgreen\">Safe</span>{% endif %}</p>
                                </div>
                                <div class=\"col-md-3\">
                                    <a class=\"tg-btn tg-btn-md btn-block\" href=\"{{ path('patient_doctor_display_changestatus') }}?id={{ dp.id }}\">{% if dp.block == 1 %}<span>unblock</span>{% else %}<span>block</span>{% endif %}</a>
                                    <a class=\"tg-btn tg-btn-md btn-block\" onclick=\"\$('#cutt_copy').fadeIn()\" href=\"javascript:void(0)\">Edit Patient Record</a>
                                </div>
                                <div class=\"col-md-offset-4 col-md-4\">
                                    <button onclick=\"\$('#toggleapp').fadeIn()\" class=\"tg-btn tg-btn-md\">Show Appointments</button>
                                </div>

                                <div id=\"toggleapp\" style=\"display: none\">
                                    <div class=\"col-xs-10\">

                                    </div>
                                    <div class=\"col-xs-2\">
                                        <a href=\"javascript:void(0)\" onclick=\"printDiv()\" class=\"tg-btn tg-btn-md\" style=\"\" >
                                            Print <span class=\"fa fa-print\"></span>
                                        </a>
                                    </div>
                                    <script>
                                        function printDiv()
                                        {
                                            var divToPrint=document.getElementById('divtoprint');
                                            console.log(divToPrint.innerHTML);
                                            var newWin=window.open('','Print-Window');
                                            newWin.document.open();
                                            newWin.document.write('<html><head></head>');
                                            newWin.document.write('<body onload=\"window.print()\">'+divToPrint.innerHTML+'</body></html>');
                                            newWin.document.close();
                                            /*setTimeout(function(){newWin.close();},10);*/

                                        }
                                    </script>

                                    <div class=\"col-md-12\" style=\"margin-top: 20px\">
                                        <div >
                                            {% if appointment|length != 0 %}
                                                <div id=\"divtoprint\">
                                                    <style>
                                                        @media print {
                                                            .nodisplay{
                                                                display: none;
                                                            }
                                                        }
                                                    </style>
                                                    <h4>List Of Appointments</h4>
                                                    <table id=\"apptable\">
                                                        {% for item in appointment|reverse %}
                                                            {% if \"now\"|date(\"Y-m-d\") < item.seance.calendrie.date|date('Y-m-d')  %}
                                                                <tr>
                                                                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                        <label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('d M') }}</label><label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('Y') }}</label> </td>
                                                                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;background-color: #c1e9fe;\">
                                                                        <label style=\"font-size: 18px\"><b>{{ item.seance.heurDebut|date('H:i') }} - {{ item.seance.heurFin|date('H:i') }}, {{ item.seance.calendrie.location.name }}</b>
                                                                            <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat{{ item.id }}\">
                                                                    {% if item.etat == 'confirme' %}
                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus({{ item.id }})\" class=\"badge\" style=\"background: green\">{{ item.etat }}</a>
                                                                        {% elseif item.etat == 'non confirmer' %}
                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus({{ item.id }})\" class=\"badge\" style=\"background: orangered\">{{ item.etat }}</a>
                                                                        {% else %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">{{ item.etat }}</a>
                                                                    {% endif %}
                                                                </span>
                                                                        </span>

                                                                        </label> <br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>{{ item.seance.calendrie.location.adresse }}</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>Patient: {{ render(controller('AppointmentsBundle:Appointments:getpatientbyUser', {'id': item.patient.idtable})) }}, Reason: {{ item.reason.reason }}
                                                                        </label>
                                                                        <div>

                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            {% else %}
                                                                <tr>
                                                                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                                                                        <label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('d M') }}</label><label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('Y') }}</label> </td>
                                                                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;\">
                                                                        <label style=\"font-size: 18px\"><b>{{ item.seance.heurDebut|date('H:i') }} - {{ item.seance.heurFin|date('H:i') }}, {{ item.seance.calendrie.location.name }}</b>
                                                                            <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat{{ item.id }}\">
                                                                    {% if item.etat == 'confirme' %}
                                                                        <a href=\"javascript:void(0)\"  class=\"badge\" style=\"background: green\">{{ item.etat }}</a>
                                                                        {% elseif item.etat == 'non confirmer' %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: orangered\">{{ item.etat }}</a>
                                                                        {% else %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">{{ item.etat }}</a>
                                                                    {% endif %}
                                                                </span>
                                                            </span>
                                                                        </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>{{ item.seance.calendrie.location.adresse }}</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                                                                        <label>Patient: {{ render(controller('AppointmentsBundle:Appointments:getpatientbyUser', {'id': item.patient.idtable})) }}, Reason: {{ item.reason.reason }}
                                                                        </label>
                                                                    </td>
                                                                </tr>
                                                            {% endif %}

                                                        {% endfor %}

                                                    </table>
                                                </div>

                                                <script>




                                                    function performaction(newid){
                                                        if(confirm(\"Really want to \"+vtype+\" this appontment to new place ?\")){
                                                            window.location = \"{{ path('calendries_appoitment_cutcopy') }}?type=\"+vtype+\"&app=\"+cutcopyid+\"&sea=\"+newid;
                                                        }
                                                    }
                                                    function showmodelcutcopy(type,id){
                                                        vtype = type;
                                                        cutcopyid = id;
                                                        if(type == \"cut\"){
                                                            \$('#cut_copy_head').html('Cut your appointment');
                                                        }else{
                                                            \$('#cut_copy_head').html('Copy your appointment');

                                                        }
                                                        \$('#cutt_copy').fadeIn();

                                                    }
                                                    function updatestatus(id){
                                                        \$.ajax({
                                                            url: '{{ path('calendries_appoitment_update') }}?id='+id,
                                                            type: 'POST',
                                                            success: function(result){
                                                                if(result === 'confirme'){
                                                                    \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: green\">'+result+'</a>')
                                                                }else{
                                                                    \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: orangered\">'+result+'</a>')
                                                                }
                                                            }
                                                        })
                                                    }
                                                </script>
                                            {% else %}
                                                <p class=\"text-center\">You have no Appointments till now.</p>
                                            {% endif %}
                                        </div>
                                        <div id=\"loaddate\" style=\"display: none;\">
                                            <p class=\"text-center\"><label for=\"\">Loading...</label></p>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </main>




        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}
", "DoctorsBundle:Patient:details.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\DoctorsBundle/Resources/views/Patient/details.html.twig");
    }
}

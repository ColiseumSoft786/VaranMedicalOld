<?php

/* calendries/index.html.twig */
class __TwigTemplate_624fda9a90a79437b4c3dd93c512025fafc88197aaecfd2a2b6a08cf017488cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calendries/index.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "calendries/index.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

        ";
        // line 8
        echo "        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\"> 
                                            ";
        // line 26
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 27
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 31
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 35
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 36
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 45
        echo "                                        </figure>


                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 49
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 57
        $this->loadTemplate("profilDoctorNav.html.twig", "calendries/index.html.twig", 57)->display($context);
        // line 58
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <div class=\"tg-dashboardappointments\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"tg-dashboardboxtitle\">
                                            <h2>Calendrier</h2>
                                        </div>
                                        <div id=\"searchBar\">
                                            <div class=\"col-md-6\">
                                                ";
        // line 68
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Locations:getComboLocationByDoctor", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))));
        echo "
                                            </div>

                                            <div class=\"col-md-3\">
                                                ";
        // line 73
        echo "                                                <button id=\"settings_toggle\" type=\"button\" class=\"tg-btn btn-block\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Calender Entries"), "html", null, true);
        echo "</button>
                                            </div>
                                            <div class=\"col-md-3\">
                                                <button type=\"button\" class=\"tg-btn btn-block\" style=\"background-color: coral\" data-toggle=\"modal\" data-target=\"#add_absence\">";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Create Absence"), "html", null, true);
        echo "</button>
                                            </div>
                                        </div>
                                    </div>
                                    <br><br>
                                    <div id=\"addSeanceFram\"></div>
                                    <div id=\"settings\" style=\"display: none;\">
                                        <form id=\"appform\" action=\"";
        // line 83
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_create_app");
        echo "\" method=\"POST\">
                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-4\">
                                                    <label for=\"\">";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</label>
                                                    <select name=\"loc\" id=\"loc\" class=\"form-control\">
                                                        <option value=\"\">";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</option>
                                                        ";
        // line 89
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["locations"] ?? $this->getContext($context, "locations")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 90
            echo "                                                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</option>
                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "                                                    </select>
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>";
        // line 95
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start Date"), "html", null, true);
        echo "</label>
                                                    <input id=\"from\" name=\"sdate\" type=\"date\" value=\"";
        // line 96
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" min=\"";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("End Date"), "html", null, true);
        echo "</label>
                                                    <input id=\"to\" name=\"edate\" type=\"date\" value=\"";
        // line 100
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" min=\"";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                                                </div>
                                            </div>

                                            ";
        // line 108
        echo "                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-offset-2 col-md-4\">
                                                    <label>";
        // line 110
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start Time"), "html", null, true);
        echo "</label>
                                                    <input id=\"stime\" type=\"text\" name=\"stime\" placeholder=\"Enter Start Time\" class=\"form-control clockpicker\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>";
        // line 114
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("End Time"), "html", null, true);
        echo "</label>
                                                    <input id=\"etime\" class=\"form-control clockpicker\" name=\"etime\" placeholder=\"Enter End Time\" type=\"text\">
                                                </div></div>

                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-6\">
                                                    <label for=\"\">";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Appointment Time"), "html", null, true);
        echo "</label>
                                                    <select id=\"atime\" name=\"atime\" class=\"form-control\">
                                                        <option value=\"\">";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Appointment Time"), "html", null, true);
        echo "</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div>
                                                <div class=\"col-md-6\">
                                                    <label for=\"\">";
        // line 135
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Pause Time"), "html", null, true);
        echo "</label>
                                                    <select id=\"ptime\" name=\"ptime\" class=\"form-control\">
                                                        <option value=\"\">";
        // line 137
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Pause Time"), "html", null, true);
        echo "</option>
                                                        <option value=\"5\">5 min</option>
                                                        <option value=\"10\">10 min</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div></div>


                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-3\">
                                                    <div style=\"margin-top: 25px\">
                                                        <input checked id=\"break\" name=\"break\" type=\"checkbox\"> ";
        // line 156
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("I need break"), "html", null, true);
        echo "
                                                    </div>
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>";
        // line 160
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start of Break"), "html", null, true);
        echo "</label>
                                                    <input id=\"sbtime\" name=\"sbtime\" class=\"form-control clockpicker\" placeholder=\"Enter Start of break\" type=\"text\">
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>";
        // line 164
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("End of Break"), "html", null, true);
        echo "</label>
                                                    <input id=\"ebtime\" name=\"ebtime\" class=\"form-control clockpicker\" type=\"text\" placeholder=\"Enter End of break\">
                                                </div></div>


                                            <script type=\"text/javascript\">
                                                \$('.clockpicker').clockpicker({
                                                    placement: 'top',
                                                    align: 'left',
                                                    donetext: 'Done'
                                                });
                                            </script>
                                            <div class=\"col-md-12\" style=\"margin-top: 10px;margin-bottom: 10px\">
                                                <input type=\"submit\" value=\"Confirm Scheduling\" class=\"btn btn-info btn-block\">
                                            </div>
                                        </form>
                                        <script>
                                            \$('#break').change(function(){
                                                if(!document.getElementById('break').checked) {
                                                    \$('#sbtime').attr(\"disabled\",\"disabled\");
                                                    \$('#ebtime').attr(\"disabled\",\"disabled\");
                                                } else {
                                                    \$('#sbtime').removeAttr('disabled');
                                                    \$('#ebtime').removeAttr('disabled');
                                                }
                                            });
                                            \$('#appform').submit(function(e){
                                                var check = true;
                                                if(\$('#loc').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#from').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#to').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#stime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#etime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#atime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#ptime').val() == \"\"){
                                                    check = false;
                                                }if(document.getElementById('break').checked){
                                                    if(\$('#sbtime').val() == \"\"){
                                                        check = false;
                                                    }else if(\$('#ebtime').val() == \"\"){
                                                        check = false;
                                                    }
                                                }if(check){
                                                    var sdate = new Date(\$('#from').val());
                                                    var edate = new Date(\$('#to').val());
                                                    if(sdate > edate){
                                                        alert(\"Start date should be greater than end date\")
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    var check12 = \"01/01/2017 \"+\$('#stime').val()+\":00\";
                                                    var check34 = \"01/01/2017 \"+\$('#etime').val()+\":00\";
                                                    var stime = Date.parse(check12);
                                                    var etime = Date.parse(check34);
                                                    if(stime > etime){
                                                        alert(\"Start time should be greater than end time\");
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    if(!confirm(\"Are you sure ? If there are appointments already, they will be overwritten.\")) return false;

                                                }else{
                                                    alert('Fill Everything in this form');
                                                    e.preventDefault();
                                                }
                                            });
                                        </script>
                                    </div>
                                    <script>
                                        \$('#settings_toggle').click(function(){
                                           \$('#settings').toggle();
                                        });
                                    </script>
                                    <div id=\"listeCalendrie\">
                                        ";
        // line 244
        if ((null === ($context["calendrie"] ?? $this->getContext($context, "calendrie")))) {
            // line 245
            echo "                                            ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Calendries:getCalendriesByLocation", array("location" => 0)));
            echo "
                                        ";
        } else {
            // line 247
            echo "                                            ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Calendries:getCalendriesByLocation", array("location" => $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "location", array()))));
            echo "
                                        ";
        }
        // line 249
        echo "
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <!--************************************
\t\t\t\tLight Box Start
\t*************************************-->
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"addSeances\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <div id=\"addSeancesZone\">

                    </div>
                </div>
            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"tg-appointmentlightbox\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>";
        // line 278
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Add new job location"), "html", null, true);
        echo "</h2>
                    ";
        // line 279
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Calendries:new"));
        echo "
                </div>

            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"add_absence\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>";
        // line 288
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Create your absence"), "html", null, true);
        echo "</h2>
                    <form id=\"abs\" action=\"";
        // line 289
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_create_absence");
        echo "\" method=\"post\">
                        <div class=\"col-md-12\">
                            <label for=\"\">";
        // line 291
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</label>
                            <select name=\"loc\" id=\"location\" class=\"form-control\">
                                <option value=\"\">";
        // line 293
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</option>
                                ";
        // line 294
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["locations"] ?? $this->getContext($context, "locations")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 295
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 297
        echo "                            </select>

                        </div>

                            ";
        // line 302
        echo "                        <div class=\"col-md-6\">
                            <label for=\"\">";
        // line 303
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Start Date"), "html", null, true);
        echo "</label>
                            <input type=\"date\" name=\"date\" value=\"";
        // line 304
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" min=\"";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">";
        // line 307
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Number of Days"), "html", null, true);
        echo "</label>
                            <input type=\"number\" name=\"day\" class=\"form-control\" value=\"1\" min=\"1\">
                            <input type=\"submit\" value=\"Confirm\" class=\"tg-btn pull-right\" style=\"margin-top: 10px;background-color: coral\">
                        </div>

                    </form>
                    <script>
                        \$('#abs').submit(function(e){
                            var val = \$('#location option:selected').val();
                            if(val == \"\"){
                                e.preventDefault();
                                alert('Select Your Calender Location');
                            }

                        })
                    </script>
                </div>

            </div>
        </div>
        <!--************************************
                    Light Box End
        *************************************-->
        <script>



            \$(document).ready(function () {
                \$(\"#appointmentsbundle_calendries_location\").change(function () {
                    \$('#dateSearch').val('');

                    var locationId = \$('#appointmentsbundle_calendries_location').val();
                    var URL = \"";
        // line 339
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_getCalendriesByLocation", array("location" => "sss"));
        echo "\";
                    URL = URL.replace(/sss/g, locationId);
                    \$.ajax({
                        type: \"GET\",
                        url: URL,
                        cache: false,
                        success: function (response) {
                            \$('#addSeanceFram').hide();
                            \$(\"#listeCalendrie\").html(response);
                            return true;
                        }
                    });
                });

            });
        </script>
        </div>
        <!--************************************
                Wrapper End
        *************************************-->
        ";
        // line 359
        $this->loadTemplate("default/footer.html.twig", "calendries/index.html.twig", 359)->display($context);
        // line 360
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "calendries/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  572 => 360,  570 => 359,  547 => 339,  512 => 307,  504 => 304,  500 => 303,  497 => 302,  491 => 297,  480 => 295,  476 => 294,  472 => 293,  467 => 291,  462 => 289,  458 => 288,  446 => 279,  442 => 278,  411 => 249,  405 => 247,  399 => 245,  397 => 244,  314 => 164,  307 => 160,  300 => 156,  278 => 137,  273 => 135,  256 => 121,  251 => 119,  243 => 114,  236 => 110,  232 => 108,  223 => 100,  219 => 99,  211 => 96,  207 => 95,  202 => 92,  191 => 90,  187 => 89,  183 => 88,  178 => 86,  172 => 83,  162 => 76,  155 => 73,  148 => 68,  136 => 58,  134 => 57,  128 => 56,  116 => 49,  110 => 45,  102 => 40,  96 => 36,  93 => 35,  87 => 32,  84 => 31,  76 => 28,  73 => 27,  71 => 26,  55 => 13,  48 => 8,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}


        {#<body class=\"tg-home tg-login\">#}
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\"> 
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>


                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.id }) }}\">{{ 'Profile'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <div class=\"tg-dashboardappointments\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"tg-dashboardboxtitle\">
                                            <h2>Calendrier</h2>
                                        </div>
                                        <div id=\"searchBar\">
                                            <div class=\"col-md-6\">
                                                {{ render(controller('DoctorsBundle:Locations:getComboLocationByDoctor' , { 'doctor': app.user.idTable})) }}
                                            </div>

                                            <div class=\"col-md-3\">
                                                {#<button type=\"button\" class=\"tg-btn btn-block\" data-toggle=\"modal\" data-target=\"#tg-appointmentlightbox\">{{ 'add new'|trans }}</button>#}
                                                <button id=\"settings_toggle\" type=\"button\" class=\"tg-btn btn-block\">{{'Calender Entries'|trans}}</button>
                                            </div>
                                            <div class=\"col-md-3\">
                                                <button type=\"button\" class=\"tg-btn btn-block\" style=\"background-color: coral\" data-toggle=\"modal\" data-target=\"#add_absence\">{{ 'Create Absence'|trans }}</button>
                                            </div>
                                        </div>
                                    </div>
                                    <br><br>
                                    <div id=\"addSeanceFram\"></div>
                                    <div id=\"settings\" style=\"display: none;\">
                                        <form id=\"appform\" action=\"{{ path('calendries_create_app') }}\" method=\"POST\">
                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-4\">
                                                    <label for=\"\">{{'Select Location'|trans}}</label>
                                                    <select name=\"loc\" id=\"loc\" class=\"form-control\">
                                                        <option value=\"\">{{'Select Location'|trans}}</option>
                                                        {% for item in locations %}
                                                            <option value=\"{{ item.id }}\">{{ item.name }}</option>
                                                        {% endfor %}
                                                    </select>
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>{{'Start Date'|trans}}</label>
                                                    <input id=\"from\" name=\"sdate\" type=\"date\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" min=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>{{'End Date'|trans}}</label>
                                                    <input id=\"to\" name=\"edate\" type=\"date\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" min=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                                                </div>
                                            </div>

                                            {#<script>
                                                \$(\"#from\").datepicker();
                                                \$(\"#to\").datepicker();
                                            </script>#}
                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-offset-2 col-md-4\">
                                                    <label>{{'Start Time'|trans}}</label>
                                                    <input id=\"stime\" type=\"text\" name=\"stime\" placeholder=\"Enter Start Time\" class=\"form-control clockpicker\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>{{'End Time'|trans}}</label>
                                                    <input id=\"etime\" class=\"form-control clockpicker\" name=\"etime\" placeholder=\"Enter End Time\" type=\"text\">
                                                </div></div>

                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-6\">
                                                    <label for=\"\">{{'Select Appointment Time'|trans}}</label>
                                                    <select id=\"atime\" name=\"atime\" class=\"form-control\">
                                                        <option value=\"\">{{'Select Appointment Time'|trans}}</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div>
                                                <div class=\"col-md-6\">
                                                    <label for=\"\">{{'Select Pause Time'|trans}}</label>
                                                    <select id=\"ptime\" name=\"ptime\" class=\"form-control\">
                                                        <option value=\"\">{{'Select Pause Time'|trans}}</option>
                                                        <option value=\"5\">5 min</option>
                                                        <option value=\"10\">10 min</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div></div>


                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-3\">
                                                    <div style=\"margin-top: 25px\">
                                                        <input checked id=\"break\" name=\"break\" type=\"checkbox\"> {{'I need break'|trans}}
                                                    </div>
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>{{ 'Start of Break'|trans }}</label>
                                                    <input id=\"sbtime\" name=\"sbtime\" class=\"form-control clockpicker\" placeholder=\"Enter Start of break\" type=\"text\">
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>{{ 'End of Break'|trans}}</label>
                                                    <input id=\"ebtime\" name=\"ebtime\" class=\"form-control clockpicker\" type=\"text\" placeholder=\"Enter End of break\">
                                                </div></div>


                                            <script type=\"text/javascript\">
                                                \$('.clockpicker').clockpicker({
                                                    placement: 'top',
                                                    align: 'left',
                                                    donetext: 'Done'
                                                });
                                            </script>
                                            <div class=\"col-md-12\" style=\"margin-top: 10px;margin-bottom: 10px\">
                                                <input type=\"submit\" value=\"Confirm Scheduling\" class=\"btn btn-info btn-block\">
                                            </div>
                                        </form>
                                        <script>
                                            \$('#break').change(function(){
                                                if(!document.getElementById('break').checked) {
                                                    \$('#sbtime').attr(\"disabled\",\"disabled\");
                                                    \$('#ebtime').attr(\"disabled\",\"disabled\");
                                                } else {
                                                    \$('#sbtime').removeAttr('disabled');
                                                    \$('#ebtime').removeAttr('disabled');
                                                }
                                            });
                                            \$('#appform').submit(function(e){
                                                var check = true;
                                                if(\$('#loc').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#from').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#to').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#stime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#etime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#atime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#ptime').val() == \"\"){
                                                    check = false;
                                                }if(document.getElementById('break').checked){
                                                    if(\$('#sbtime').val() == \"\"){
                                                        check = false;
                                                    }else if(\$('#ebtime').val() == \"\"){
                                                        check = false;
                                                    }
                                                }if(check){
                                                    var sdate = new Date(\$('#from').val());
                                                    var edate = new Date(\$('#to').val());
                                                    if(sdate > edate){
                                                        alert(\"Start date should be greater than end date\")
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    var check12 = \"01/01/2017 \"+\$('#stime').val()+\":00\";
                                                    var check34 = \"01/01/2017 \"+\$('#etime').val()+\":00\";
                                                    var stime = Date.parse(check12);
                                                    var etime = Date.parse(check34);
                                                    if(stime > etime){
                                                        alert(\"Start time should be greater than end time\");
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    if(!confirm(\"Are you sure ? If there are appointments already, they will be overwritten.\")) return false;

                                                }else{
                                                    alert('Fill Everything in this form');
                                                    e.preventDefault();
                                                }
                                            });
                                        </script>
                                    </div>
                                    <script>
                                        \$('#settings_toggle').click(function(){
                                           \$('#settings').toggle();
                                        });
                                    </script>
                                    <div id=\"listeCalendrie\">
                                        {% if calendrie is null %}
                                            {{ render(controller('AppointmentsBundle:Calendries:getCalendriesByLocation', {'location': 0})) }}
                                        {% else %}
                                            {{ render(controller('AppointmentsBundle:Calendries:getCalendriesByLocation', {'location': calendrie.location})) }}
                                        {% endif %}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <!--************************************
\t\t\t\tLight Box Start
\t*************************************-->
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"addSeances\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <div id=\"addSeancesZone\">

                    </div>
                </div>
            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"tg-appointmentlightbox\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>{{ 'Add new job location'|trans }}</h2>
                    {{ render(controller('AppointmentsBundle:Calendries:new')) }}
                </div>

            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"add_absence\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>{{ 'Create your absence'|trans }}</h2>
                    <form id=\"abs\" action=\"{{ path('calendries_create_absence') }}\" method=\"post\">
                        <div class=\"col-md-12\">
                            <label for=\"\">{{'Select Location'|trans}}</label>
                            <select name=\"loc\" id=\"location\" class=\"form-control\">
                                <option value=\"\">{{'Select Location'|trans}}</option>
                                {% for item in locations %}
                                    <option value=\"{{ item.id }}\">{{ item.name }}</option>
                                {% endfor %}
                            </select>

                        </div>

                            {#{{ render(controller('DoctorsBundle:Locations:getComboLocationByDoctor' , { 'doctor': app.user.idTable})) }}#}
                        <div class=\"col-md-6\">
                            <label for=\"\">{{'Select Start Date'|trans}}</label>
                            <input type=\"date\" name=\"date\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" min=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">{{'Select Number of Days'|trans}}</label>
                            <input type=\"number\" name=\"day\" class=\"form-control\" value=\"1\" min=\"1\">
                            <input type=\"submit\" value=\"Confirm\" class=\"tg-btn pull-right\" style=\"margin-top: 10px;background-color: coral\">
                        </div>

                    </form>
                    <script>
                        \$('#abs').submit(function(e){
                            var val = \$('#location option:selected').val();
                            if(val == \"\"){
                                e.preventDefault();
                                alert('Select Your Calender Location');
                            }

                        })
                    </script>
                </div>

            </div>
        </div>
        <!--************************************
                    Light Box End
        *************************************-->
        <script>



            \$(document).ready(function () {
                \$(\"#appointmentsbundle_calendries_location\").change(function () {
                    \$('#dateSearch').val('');

                    var locationId = \$('#appointmentsbundle_calendries_location').val();
                    var URL = \"{{ path('calendries_getCalendriesByLocation', {'location' : 'sss'}) }}\";
                    URL = URL.replace(/sss/g, locationId);
                    \$.ajax({
                        type: \"GET\",
                        url: URL,
                        cache: false,
                        success: function (response) {
                            \$('#addSeanceFram').hide();
                            \$(\"#listeCalendrie\").html(response);
                            return true;
                        }
                    });
                });

            });
        </script>
        </div>
        <!--************************************
                Wrapper End
        *************************************-->
        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}", "calendries/index.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\calendries\\index.html.twig");
    }
}

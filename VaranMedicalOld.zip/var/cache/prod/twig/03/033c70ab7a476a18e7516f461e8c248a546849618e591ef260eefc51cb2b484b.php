<?php

/* doctors/profilEditCertifications.html.twig */
class __TwigTemplate_db4da35f6a8fea2a0aa7a24277f9bf32f054d2d472f1b92e436f40a1b30f6f25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0bcd869caf974e448a3cd5d6e5e9c5c68ee6d1cff43e912468622347601d0407 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0bcd869caf974e448a3cd5d6e5e9c5c68ee6d1cff43e912468622347601d0407->enter($__internal_0bcd869caf974e448a3cd5d6e5e9c5c68ee6d1cff43e912468622347601d0407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "doctors/profilEditCertifications.html.twig"));

        // line 1
        echo "<ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["certifications"] ?? $this->getContext($context, "certifications")));
        foreach ($context['_seq'] as $context["_key"] => $context["certification"]) {
            // line 3
            echo "        <li> <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["certification"], "title", array()), "html", null, true);
            echo " <button class=\"editCertification\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["certification"], "id", array()), "html", null, true);
            echo "\" style=\"background-color: transparent\"><i class=\"fa fa-pencil\"></i></button>  <button class=\"deleteCertification\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["certification"], "id", array()), "html", null, true);
            echo "\" style=\"background-color: transparent\"><i class=\"fa fa-close\"></i></button></span>  <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["certification"], "occasion", array()), "html", null, true);
            echo "</span> <span>";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["certification"], "date", array()), "d-M-Y "), "html", null, true);
            echo "</span> </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['certification'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ul>


<script>
        \$(document).ready(function () {
                \$(\".editCertification\").click(function () {

                        var URL = \"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("certifications_edit", array("id" => "sss"));
        echo "\";
                        var idCertification = \$(this).attr('value');
                        URL = URL.replace(/sss/g, idCertification);
                        console.log('URL = '+URL);
                        \$.ajax({
                                type: \"POST\",
                                url: URL,
                                cache: false,
                                success: function (response) {
                                        \$('#editCertification').html(response);
                                        \$('#newCertification').hide();
                                        \$('#certificationList').hide();
                                }
                        });
                        return true;
                });

                \$(\".deleteCertification\").click(function () {
                        if (!confirm('Vous voulez supprimer cet enregistrement')) return false;
                        var URL = \"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("certifications_delete", array("certification" => "sss"));
        echo "\";
                        var idCertification = \$(this).attr('value');
                        console.log(idCertification)
                        URL = URL.replace(/sss/g, idCertification);
                        console.log('URL = '+URL);
                        \$.ajax({
                                type: \"POST\",
                                url: URL,
                                cache: false,
                                success: function (response) {
                                        \$('#certificationList').html(response);
                                        \$('#successCertification').hide();
                                }
                        });
                        return true;
                });
        });
</script>";
        
        $__internal_0bcd869caf974e448a3cd5d6e5e9c5c68ee6d1cff43e912468622347601d0407->leave($__internal_0bcd869caf974e448a3cd5d6e5e9c5c68ee6d1cff43e912468622347601d0407_prof);

    }

    public function getTemplateName()
    {
        return "doctors/profilEditCertifications.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 31,  55 => 12,  46 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
    {% for certification in certifications %}
        <li> <span>{{ certification.title }} <button class=\"editCertification\" value=\"{{ certification.id }}\" style=\"background-color: transparent\"><i class=\"fa fa-pencil\"></i></button>  <button class=\"deleteCertification\" value=\"{{ certification.id }}\" style=\"background-color: transparent\"><i class=\"fa fa-close\"></i></button></span>  <span>{{ certification.occasion }}</span> <span>{{ certification.date|date('d-M-Y ') }}</span> </li>
    {% endfor %}
</ul>


<script>
        \$(document).ready(function () {
                \$(\".editCertification\").click(function () {

                        var URL = \"{{ path('certifications_edit',{ 'id': 'sss' }) }}\";
                        var idCertification = \$(this).attr('value');
                        URL = URL.replace(/sss/g, idCertification);
                        console.log('URL = '+URL);
                        \$.ajax({
                                type: \"POST\",
                                url: URL,
                                cache: false,
                                success: function (response) {
                                        \$('#editCertification').html(response);
                                        \$('#newCertification').hide();
                                        \$('#certificationList').hide();
                                }
                        });
                        return true;
                });

                \$(\".deleteCertification\").click(function () {
                        if (!confirm('Vous voulez supprimer cet enregistrement')) return false;
                        var URL = \"{{ path('certifications_delete',{ 'certification': 'sss' }) }}\";
                        var idCertification = \$(this).attr('value');
                        console.log(idCertification)
                        URL = URL.replace(/sss/g, idCertification);
                        console.log('URL = '+URL);
                        \$.ajax({
                                type: \"POST\",
                                url: URL,
                                cache: false,
                                success: function (response) {
                                        \$('#certificationList').html(response);
                                        \$('#successCertification').hide();
                                }
                        });
                        return true;
                });
        });
</script>", "doctors/profilEditCertifications.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\doctors\\profilEditCertifications.html.twig");
    }
}

<?php

/* base.html.twig */
class __TwigTemplate_3689fcbeefb6bd24e4d34591e5fec592bcf780532d83a780ea813f5b6141a55c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_097bdfc8a5326375a7e3f19a476504231f778df6c867c46ed6c2794ed603aea6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_097bdfc8a5326375a7e3f19a476504231f778df6c867c46ed6c2794ed603aea6->enter($__internal_097bdfc8a5326375a7e3f19a476504231f778df6c867c46ed6c2794ed603aea6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/favicon.ico"), "html", null, true);
        echo "\" />
</head>
<body>
";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 13
        echo "</body>
";
        // line 14
        $this->displayBlock('javascripts', $context, $blocks);
        // line 15
        echo "</html>
";
        
        $__internal_097bdfc8a5326375a7e3f19a476504231f778df6c867c46ed6c2794ed603aea6->leave($__internal_097bdfc8a5326375a7e3f19a476504231f778df6c867c46ed6c2794ed603aea6_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_0c1e2b0221dfbaff1c95f7ae7617f8c36961f5e7ff09db085a4774f916aacf7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c1e2b0221dfbaff1c95f7ae7617f8c36961f5e7ff09db085a4774f916aacf7a->enter($__internal_0c1e2b0221dfbaff1c95f7ae7617f8c36961f5e7ff09db085a4774f916aacf7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_0c1e2b0221dfbaff1c95f7ae7617f8c36961f5e7ff09db085a4774f916aacf7a->leave($__internal_0c1e2b0221dfbaff1c95f7ae7617f8c36961f5e7ff09db085a4774f916aacf7a_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5abbc98cc2522be0a1c2209a6be634b88e967c74f67a35510ee97e0482ac77ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5abbc98cc2522be0a1c2209a6be634b88e967c74f67a35510ee97e0482ac77ea->enter($__internal_5abbc98cc2522be0a1c2209a6be634b88e967c74f67a35510ee97e0482ac77ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $this->loadTemplate("default/stylesheet.html.twig", "base.html.twig", 6)->display($context);
        
        $__internal_5abbc98cc2522be0a1c2209a6be634b88e967c74f67a35510ee97e0482ac77ea->leave($__internal_5abbc98cc2522be0a1c2209a6be634b88e967c74f67a35510ee97e0482ac77ea_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_91a6ddc462c432a0d2dec1870d7e1cc0f4b8a3ea74acef05813bbaee6d4ee831 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91a6ddc462c432a0d2dec1870d7e1cc0f4b8a3ea74acef05813bbaee6d4ee831->enter($__internal_91a6ddc462c432a0d2dec1870d7e1cc0f4b8a3ea74acef05813bbaee6d4ee831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
";
        
        $__internal_91a6ddc462c432a0d2dec1870d7e1cc0f4b8a3ea74acef05813bbaee6d4ee831->leave($__internal_91a6ddc462c432a0d2dec1870d7e1cc0f4b8a3ea74acef05813bbaee6d4ee831_prof);

    }

    // line 14
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9847876bf4d9b7e978fb9644f6ae9da2f4969984d79a2161e38fb6100ac08369 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9847876bf4d9b7e978fb9644f6ae9da2f4969984d79a2161e38fb6100ac08369->enter($__internal_9847876bf4d9b7e978fb9644f6ae9da2f4969984d79a2161e38fb6100ac08369_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $this->loadTemplate("default/javascripts.html.twig", "base.html.twig", 14)->display($context);
        
        $__internal_9847876bf4d9b7e978fb9644f6ae9da2f4969984d79a2161e38fb6100ac08369->leave($__internal_9847876bf4d9b7e978fb9644f6ae9da2f4969984d79a2161e38fb6100ac08369_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 14,  90 => 11,  84 => 10,  72 => 6,  60 => 5,  52 => 15,  50 => 14,  47 => 13,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}{% include ('default/stylesheet.html.twig') %}{% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('assets/images/favicon.ico') }}\" />
</head>
<body>
{% block body %}

{% endblock %}
</body>
{% block javascripts %}{% include ('default/javascripts.html.twig') %}{% endblock %}
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\base.html.twig");
    }
}

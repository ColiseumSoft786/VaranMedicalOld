<?php

/* AppointmentsBundle:Appointments:seancebylocation.html.twig */
class __TwigTemplate_60e0ee6b74485864288fd94cf8a1d71a1a9e34aa597b82bd98da9649ba8fefe3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppointmentsBundle:Appointments:seancebylocation.html.twig"));

        // line 1
        if ((twig_length_filter($this->env, ($context["cal"] ?? $this->getContext($context, "cal"))) == 0)) {
            // line 2
            echo "    <p class=\"text-center\">No dates found</p>
    ";
        } else {
            // line 4
            echo "        Available Dates: <br>
        ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cal"] ?? $this->getContext($context, "cal")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 6
                echo "            <div class=\"badge\" style=\"padding: 7px;background-color: #0b58a2;border-radius: 0\">Date: ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "date", array()), "d-m-Y"), "html", null, true);
                echo "</div>
            <div style=\"padding: 5px 30px\">
                ";
                // line 8
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getseansesbycal", array("id" => $this->getAttribute($context["item"], "id", array()))));
                echo "
            </div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AppointmentsBundle:Appointments:seancebylocation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 8,  35 => 6,  31 => 5,  28 => 4,  24 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if cal|length == 0 %}
    <p class=\"text-center\">No dates found</p>
    {% else %}
        Available Dates: <br>
        {% for item in cal %}
            <div class=\"badge\" style=\"padding: 7px;background-color: #0b58a2;border-radius: 0\">Date: {{ item.date|date('d-m-Y') }}</div>
            <div style=\"padding: 5px 30px\">
                {{ render(controller('AppointmentsBundle:Appointments:getseansesbycal' , { 'id': item.id})) }}
            </div>
        {% endfor %}
{% endif %}
", "AppointmentsBundle:Appointments:seancebylocation.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AppointmentsBundle/Resources/views/Appointments/seancebylocation.html.twig");
    }
}

<?php

/* DataBundle:Emails:statuschange.html.twig */
class __TwigTemplate_8e7f2fd0330189b3226b40b5d09317d15d6e4dc07595e63637b7e8dd230ea93d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "DataBundle:Emails:statuschange.html.twig"));

        // line 1
        echo "Hello, ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstname", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastname", array()), "html", null, true);
        echo "
<br>
We hope you are fine, your appointment status has been changed by ";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstname", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastname", array()), "html", null, true);
        echo ".
<br>
Status: ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "etat", array()), "html", null, true);
        echo "
<br>
Appointment Location: <br>
Name: ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
        echo "<br>
Address: ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
        echo "<br>
Ville: ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "calendrie", array()), "location", array()), "ville", array()), "html", null, true);
        echo "<br>
Zip Code: ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "calendrie", array()), "location", array()), "codezip", array()), "html", null, true);
        echo "<br>
-------------- <br>
Appointment Time: ";
        // line 13
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "calendrie", array()), "date", array()), "d-m-Y"), "html", null, true);
        echo "<br>
Appointment Date: ";
        // line 14
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "heurdebut", array()), "H:i"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "heurfin", array()), "H:i"), "html", null, true);
        echo "<br>
<br>
cancel notifications: <br><b>For SMS:</b> <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("patient_profil_togglenotif");
        echo "?id=";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        echo "&toggle=sms&val=0\">click here</a> <br><b>For Email:</b> <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("patient_profil_togglenotif");
        echo "?id=";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        echo "&toggle=email&val=0\">click here</a>
<br>
<b>Best Regards,</b> <br>
Varan Team
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "DataBundle:Emails:statuschange.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 16,  64 => 14,  60 => 13,  55 => 11,  51 => 10,  47 => 9,  43 => 8,  37 => 5,  30 => 3,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello, {{ patient.firstname }} {{ patient.lastname }}
<br>
We hope you are fine, your appointment status has been changed by {{ doctor.firstname }} {{ doctor.lastname }}.
<br>
Status: {{ app.etat }}
<br>
Appointment Location: <br>
Name: {{ app.seance.calendrie.location.name }}<br>
Address: {{ app.seance.calendrie.location.adresse }}<br>
Ville: {{ app.seance.calendrie.location.ville }}<br>
Zip Code: {{ app.seance.calendrie.location.codezip }}<br>
-------------- <br>
Appointment Time: {{ app.seance.calendrie.date|date('d-m-Y') }}<br>
Appointment Date: {{ app.seance.heurdebut|date('H:i') }} - {{ app.seance.heurfin|date('H:i') }}<br>
<br>
cancel notifications: <br><b>For SMS:</b> <a href=\"{{ url('patient_profil_togglenotif') }}?id={{ id }}&toggle=sms&val=0\">click here</a> <br><b>For Email:</b> <a href=\"{{ url('patient_profil_togglenotif') }}?id={{ id }}&toggle=email&val=0\">click here</a>
<br>
<b>Best Regards,</b> <br>
Varan Team
", "DataBundle:Emails:statuschange.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\DataBundle/Resources/views/Emails/statuschange.html.twig");
    }
}

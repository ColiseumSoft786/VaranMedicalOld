<?php

/* locations/index.html.twig */
class __TwigTemplate_10f809be19c515ebd1934b679194e30f65a07bbb1159274d5b8b598bcc331c62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'addLocationModal' => array($this, 'block_addLocationModal'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56af1f6f9edb098c5f4e60c1458b7f81334538f89de3d96c4662fae5ab6e37a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56af1f6f9edb098c5f4e60c1458b7f81334538f89de3d96c4662fae5ab6e37a0->enter($__internal_56af1f6f9edb098c5f4e60c1458b7f81334538f89de3d96c4662fae5ab6e37a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "locations/index.html.twig"));

        // line 1
        $this->loadTemplate("base.html.twig", "locations/index.html.twig", 1)->display($context);
        // line 2
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_56af1f6f9edb098c5f4e60c1458b7f81334538f89de3d96c4662fae5ab6e37a0->leave($__internal_56af1f6f9edb098c5f4e60c1458b7f81334538f89de3d96c4662fae5ab6e37a0_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_f900444537655ea4dbb9517f7a23e30aced3e2b23d3366048fbabd7e699b56ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f900444537655ea4dbb9517f7a23e30aced3e2b23d3366048fbabd7e699b56ae->enter($__internal_f900444537655ea4dbb9517f7a23e30aced3e2b23d3366048fbabd7e699b56ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
    <!--************************************
            Preloader Start
    *************************************
    <div class=\"preloader-outer\">
        <div class=\"pin\"></div>
        <div class=\"pulse\"></div>
    </div>
    <!--************************************
            Preloader End
    *************************************-->

    <!--************************************
            Wrapper Start
    *************************************-->
    <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

        <!--************************************
\t\t\t\tMain Start
\t\t*************************************-->
        <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
            <div class=\"container\">
                <div class=\"row\">
                    <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                        <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                            <div class=\"tg-widgetdashboard\">
                                <div class=\"tg-widgetprofile\">
                                    <figure class=\"tg-directpostimg\"> 
                                        
                                        ";
        // line 36
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 37
            echo "                                            <a href=\"#\">
                                                <img src=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                            </a>
                                        ";
        } else {
            // line 41
            echo "                                            <a href=\"#\">
                                                <img src=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                            </a>
                                        ";
        }
        // line 45
        echo "                                        ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 46
            echo "                                            <figcaption>
                                                <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                    <em class=\"tg-usericonholder\">
                                                        <i class=\"fa fa-shield\"></i>
                                                        <span>";
            // line 50
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                    </em>
                                                </a>
                                            </figcaption>
                                        ";
        }
        // line 55
        echo "                                    </figure>
                                    <div class=\"tg-directposthead\">
                                        <h3><a href=\"#\">Dr. ";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                        <div class=\"tg-subjects\"></div>
                                        <ul class=\"tg-metadata\">
                                            <li><span class=\"tg-stars\"><span></span></span></li>
                                            <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                        </ul>
                                    </div>
                                    <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                ";
        // line 65
        $this->loadTemplate("profilDoctorNav.html.twig", "locations/index.html.twig", 65)->display($context);
        // line 66
        echo "                            </div>
                        </div>
                        <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                            <div class=\"tg-dashboardjobslocations\">
                                <div class=\"tg-dashboardbox\">
                                    <div class=\"tg-dashboardboxtitle\">
                                        <h2>";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Available Locations"), "html", null, true);
        echo "</h2>
                                    </div>
                                    <div class=\"tg-box tg-profilephoto\">
                                        <div class=\"row tg-rowmargin\">
                                            <div class=\"col-md-3 col-sm-6 col-xs-12 tg-columnpadding pull-right\" >
                                                <div class=\"form-group tg-formgroup \">
                                                    <a href=\"";
        // line 78
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("locations_new");
        echo "\" class=\"tg-btn tg-btn-lg\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Add Now"), "html", null, true);
        echo "</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id=\"divFormAdd\">

                                    </div>
                                    <div class=\"tg-box tg-availablelocation\">
                                        <div class=\"tg-servicelocations\">
                                            <div id=\"divErreur\" hidden>
                                                <div class=\"tg-alertmessages\">
                                                    <div class=\"alert alert-danger tg-alertmessage fade in\">
                                                        <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                                                        <i class=\"fa fa-bug\"></i>
                                                        <span><strong>";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Error Message"), "html", null, true);
        echo ".</strong> Adipisicing elit, sed do eiusmod et dolore magna aliqua enim ad minimati.</span>
                                                    </div>
                                                </div>
                                            </div>
                                            ";
        // line 97
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["locations"] ?? $this->getContext($context, "locations")));
        foreach ($context['_seq'] as $context["_key"] => $context["location"]) {
            // line 98
            echo "                                                <div class=\"tg-servicelocation\">
                                                    <div class=\"tg-directpost\">
                                                        <div class=\"tg-directinfo\">
                                                            <div class=\"tg-directposthead\">
                                                                <h3><a href=\"#\">";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["location"], "name", array()), "html", null, true);
            echo "</a> <i class=\"fa fa-check-circle\" ";
            if (($this->getAttribute($context["location"], "verified", array()) == 1)) {
                echo "style=\"color: #6b9311\" title=\"vérifier\" ";
            } else {
                echo "style=\"color: #9d9d9d\" title = \"non vérifier\"";
            }
            echo "></i><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_comments", array("location" => $this->getAttribute($context["location"], "id", array()))), "html", null, true);
            echo "\"><span style=\"margin-left: 10px\" class=\"glyphicon glyphicon-comment\"></span></a></h3>
                                                                <div class=\"tg-subjects\">";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute($context["location"], "ville", array()), "html", null, true);
            echo "</div>
                                                            </div>
                                                            <div class=\"tg-description\" style=\"max-height: none;\">
                                                                <p>";
            // line 106
            echo twig_escape_filter($this->env, $this->getAttribute($context["location"], "adresse", array()), "html", null, true);
            echo "</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class=\"tg-btnjoblocationeditdelete\" style=\"width: 10%\">
                                                        <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                            <a type=\"submit\" class=\"tg-btndelete showMap\" id=\"";
            // line 113
            echo twig_escape_filter($this->env, $this->getAttribute($context["location"], "id", array()), "html", null, true);
            echo "\" data-toggle=\"modal\" data-target=\"#showMap\" style=\"background-color: #2b2b2b\"><i class=\"fa fa-map-marker\" title=\"Afficher la carte\"></i></a><br>
                                                            <a class=\"tg-btndelete\" href=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_index", array("id" => $this->getAttribute($context["location"], "id", array()))), "html", null, true);
            echo "\" style=\"background-color: #2b2b2b\" title=\"Calendrier\"><i class=\"fa fa-calendar\"></i></a>
                                                        </div>
                                                        <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                            <a type=\"submit\" class=\"tg-btndelete deleteLocation\" id=\"";
            // line 117
            echo twig_escape_filter($this->env, $this->getAttribute($context["location"], "id", array()), "html", null, true);
            echo "\" style=\"background-color: #2b2b2b\" title=\"Supprimer\"><i class=\"fa fa-trash\"></i></a><br>
                                                            <a type=\"submit\" class=\"tg-btndelete editLocation\" id=\"";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute($context["location"], "id", array()), "html", null, true);
            echo "\" data-toggle=\"modal\" data-target=\"#editLocation\" style=\"background-color: #2b2b2b\" title=\"Modifier\"><i class=\"fa fa-pencil\"></i></a>
                                                        </div>

                                                    </div>
                                                    <br><br>
                                                </div>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['location'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 125
        echo "                                        </div>
                                    </div>
                                        
                                    <div>
                                        <!-- this is my comment -->
                                        ";
        // line 130
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Horaire:new"));
        echo "
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--************************************
                Main End
        *************************************-->

                                            
                                            
    </div>
    <!--************************************
            Wrapper End
    *************************************-->
    ";
        // line 150
        $this->loadTemplate("default/footer.html.twig", "locations/index.html.twig", 150)->display($context);
        // line 151
        echo "    ";
        $this->displayBlock('addLocationModal', $context, $blocks);
        // line 181
        echo "
<script>

    \$(document).ready(function () {

        \$(\".showMap\").click(function () {
            var location = \$(this).attr('id');
            var URL = \"";
        // line 188
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("locations_show", array("id" => "myID"));
        echo "\";
            URL = URL.replace(/myID/g, location);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#result').html(response);
                    return true;
                }
            });
        });

        \$(\".editLocation\").click(function () {
            var location = \$(this).attr('id');
            var URL = \"";
        // line 204
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("locations_edit", array("id" => "myID"));
        echo "\";
            URL = URL.replace(/myID/g, location);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#formEdit').html(response);
                    return true;
                }
            });
        });
        \$(\".deleteLocation\").click(function () {
            if (!confirm('Vous voulez vraiment supprime cette job location')) return false;
            var locations = \$(this).attr('id');
            var URL = \"";
        // line 220
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("locations_delete", array("id" => "myID"));
        echo "\";
            URL = URL.replace(/myID/g, locations);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    if (response == 'erreur') {
                        \$('#divErreur').show();
                        return true;
                    }
                    location.reload();
                    return true;
                }
            });
        });
    });
    </script>
";
        
        $__internal_f900444537655ea4dbb9517f7a23e30aced3e2b23d3366048fbabd7e699b56ae->leave($__internal_f900444537655ea4dbb9517f7a23e30aced3e2b23d3366048fbabd7e699b56ae_prof);

    }

    // line 151
    public function block_addLocationModal($context, array $blocks = array())
    {
        $__internal_332c3043ff0716099896c140548ec6bce8d16a26d0030672ad842bdc3d6be3c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_332c3043ff0716099896c140548ec6bce8d16a26d0030672ad842bdc3d6be3c9->enter($__internal_332c3043ff0716099896c140548ec6bce8d16a26d0030672ad842bdc3d6be3c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "addLocationModal"));

        // line 152
        echo "        <!--************************************
\t\t\t\tLight Box Start
\t*************************************-->
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"showMap\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2 id=\"locationName\"></h2>
                    <div id=\"result\">

                    </div>
                </div>
            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"editLocation\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2 id=\"locationName\"></h2>
                    <div id=\"formEdit\">

                    </div>
                </div>
            </div>
        </div>
        <!--************************************
                    Light Box End
        *************************************-->
        ";
        
        $__internal_332c3043ff0716099896c140548ec6bce8d16a26d0030672ad842bdc3d6be3c9->leave($__internal_332c3043ff0716099896c140548ec6bce8d16a26d0030672ad842bdc3d6be3c9_prof);

    }

    public function getTemplateName()
    {
        return "locations/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  363 => 152,  357 => 151,  330 => 220,  311 => 204,  292 => 188,  283 => 181,  280 => 151,  278 => 150,  255 => 130,  248 => 125,  235 => 118,  231 => 117,  225 => 114,  221 => 113,  211 => 106,  205 => 103,  193 => 102,  187 => 98,  183 => 97,  176 => 93,  156 => 78,  147 => 72,  139 => 66,  137 => 65,  131 => 64,  119 => 57,  115 => 55,  107 => 50,  101 => 46,  98 => 45,  92 => 42,  89 => 41,  81 => 38,  78 => 37,  76 => 36,  59 => 22,  38 => 3,  26 => 2,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include ('base.html.twig') %}
{% block body %}
    <body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
    <!--************************************
            Preloader Start
    *************************************
    <div class=\"preloader-outer\">
        <div class=\"pin\"></div>
        <div class=\"pulse\"></div>
    </div>
    <!--************************************
            Preloader End
    *************************************-->

    <!--************************************
            Wrapper Start
    *************************************-->
    <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
        {{ render(controller('AppBundle:Default:header')) }}

        <!--************************************
\t\t\t\tMain Start
\t\t*************************************-->
        <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
            <div class=\"container\">
                <div class=\"row\">
                    <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                        <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                            <div class=\"tg-widgetdashboard\">
                                <div class=\"tg-widgetprofile\">
                                    <figure class=\"tg-directpostimg\"> 
                                        
                                        {% if vich_uploader_asset(doctor, 'imageFile') %}
                                            <a href=\"#\">
                                                <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                            </a>
                                        {% else %}
                                            <a href=\"#\">
                                                <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                            </a>
                                        {% endif %}
                                        {% if app.user.verifier == 1 %}
                                            <figcaption>
                                                <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                    <em class=\"tg-usericonholder\">
                                                        <i class=\"fa fa-shield\"></i>
                                                        <span>{{ 'verified'|trans }}</span>
                                                    </em>
                                                </a>
                                            </figcaption>
                                        {% endif %}
                                    </figure>
                                    <div class=\"tg-directposthead\">
                                        <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                        <div class=\"tg-subjects\"></div>
                                        <ul class=\"tg-metadata\">
                                            <li><span class=\"tg-stars\"><span></span></span></li>
                                            <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                        </ul>
                                    </div>
                                    <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.id }) }}\">{{ 'Profile'|trans }}</a> </div>
                                {% include('profilDoctorNav.html.twig') %}
                            </div>
                        </div>
                        <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                            <div class=\"tg-dashboardjobslocations\">
                                <div class=\"tg-dashboardbox\">
                                    <div class=\"tg-dashboardboxtitle\">
                                        <h2>{{ 'Available Locations'|trans }}</h2>
                                    </div>
                                    <div class=\"tg-box tg-profilephoto\">
                                        <div class=\"row tg-rowmargin\">
                                            <div class=\"col-md-3 col-sm-6 col-xs-12 tg-columnpadding pull-right\" >
                                                <div class=\"form-group tg-formgroup \">
                                                    <a href=\"{{ path('locations_new') }}\" class=\"tg-btn tg-btn-lg\">{{ 'Add Now'|trans }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id=\"divFormAdd\">

                                    </div>
                                    <div class=\"tg-box tg-availablelocation\">
                                        <div class=\"tg-servicelocations\">
                                            <div id=\"divErreur\" hidden>
                                                <div class=\"tg-alertmessages\">
                                                    <div class=\"alert alert-danger tg-alertmessage fade in\">
                                                        <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                                                        <i class=\"fa fa-bug\"></i>
                                                        <span><strong>{{ 'Error Message'|trans }}.</strong> Adipisicing elit, sed do eiusmod et dolore magna aliqua enim ad minimati.</span>
                                                    </div>
                                                </div>
                                            </div>
                                            {% for location in locations %}
                                                <div class=\"tg-servicelocation\">
                                                    <div class=\"tg-directpost\">
                                                        <div class=\"tg-directinfo\">
                                                            <div class=\"tg-directposthead\">
                                                                <h3><a href=\"#\">{{ location.name }}</a> <i class=\"fa fa-check-circle\" {% if location.verified == 1 %}style=\"color: #6b9311\" title=\"vérifier\" {% else %}style=\"color: #9d9d9d\" title = \"non vérifier\"{% endif %}></i><a href=\"{{ path('doctors_comments',{'location':location.id}) }}\"><span style=\"margin-left: 10px\" class=\"glyphicon glyphicon-comment\"></span></a></h3>
                                                                <div class=\"tg-subjects\">{{ location.ville }}</div>
                                                            </div>
                                                            <div class=\"tg-description\" style=\"max-height: none;\">
                                                                <p>{{ location.adresse }}</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class=\"tg-btnjoblocationeditdelete\" style=\"width: 10%\">
                                                        <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                            <a type=\"submit\" class=\"tg-btndelete showMap\" id=\"{{ location.id }}\" data-toggle=\"modal\" data-target=\"#showMap\" style=\"background-color: #2b2b2b\"><i class=\"fa fa-map-marker\" title=\"Afficher la carte\"></i></a><br>
                                                            <a class=\"tg-btndelete\" href=\"{{ path('calendries_index', {'id':location.id}) }}\" style=\"background-color: #2b2b2b\" title=\"Calendrier\"><i class=\"fa fa-calendar\"></i></a>
                                                        </div>
                                                        <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                            <a type=\"submit\" class=\"tg-btndelete deleteLocation\" id=\"{{ location.id }}\" style=\"background-color: #2b2b2b\" title=\"Supprimer\"><i class=\"fa fa-trash\"></i></a><br>
                                                            <a type=\"submit\" class=\"tg-btndelete editLocation\" id=\"{{ location.id }}\" data-toggle=\"modal\" data-target=\"#editLocation\" style=\"background-color: #2b2b2b\" title=\"Modifier\"><i class=\"fa fa-pencil\"></i></a>
                                                        </div>

                                                    </div>
                                                    <br><br>
                                                </div>
                                            {% endfor %}
                                        </div>
                                    </div>
                                        
                                    <div>
                                        <!-- this is my comment -->
                                        {{ render(controller('DoctorsBundle:Horaire:new')) }}
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--************************************
                Main End
        *************************************-->

                                            
                                            
    </div>
    <!--************************************
            Wrapper End
    *************************************-->
    {% include ('default/footer.html.twig') %}
    {% block addLocationModal %}
        <!--************************************
\t\t\t\tLight Box Start
\t*************************************-->
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"showMap\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2 id=\"locationName\"></h2>
                    <div id=\"result\">

                    </div>
                </div>
            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"editLocation\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2 id=\"locationName\"></h2>
                    <div id=\"formEdit\">

                    </div>
                </div>
            </div>
        </div>
        <!--************************************
                    Light Box End
        *************************************-->
        {% endblock %}

<script>

    \$(document).ready(function () {

        \$(\".showMap\").click(function () {
            var location = \$(this).attr('id');
            var URL = \"{{ path('locations_show',{ 'id': 'myID' }) }}\";
            URL = URL.replace(/myID/g, location);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#result').html(response);
                    return true;
                }
            });
        });

        \$(\".editLocation\").click(function () {
            var location = \$(this).attr('id');
            var URL = \"{{ path('locations_edit',{ 'id': 'myID' }) }}\";
            URL = URL.replace(/myID/g, location);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#formEdit').html(response);
                    return true;
                }
            });
        });
        \$(\".deleteLocation\").click(function () {
            if (!confirm('Vous voulez vraiment supprime cette job location')) return false;
            var locations = \$(this).attr('id');
            var URL = \"{{ path('locations_delete',{ 'id': 'myID' }) }}\";
            URL = URL.replace(/myID/g, locations);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    if (response == 'erreur') {
                        \$('#divErreur').show();
                        return true;
                    }
                    location.reload();
                    return true;
                }
            });
        });
    });
    </script>
{% endblock %}
", "locations/index.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\locations\\index.html.twig");
    }
}

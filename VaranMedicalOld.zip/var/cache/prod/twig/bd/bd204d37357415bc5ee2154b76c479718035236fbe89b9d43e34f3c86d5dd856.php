<?php

/* AppointmentsBundle:Holiday:unblockweekend.html.twig */
class __TwigTemplate_e1dafd8c69c94806f9beb1bd71e831097e7c03367c904c39c01d6bc8f19cfc78 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppointmentsBundle:Holiday:unblockweekend.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "AppointmentsBundle:Holiday:unblockweekend.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
        ";
        // line 7
        echo "        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            ";
        // line 25
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 26
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 30
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 34
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 35
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 44
        echo "                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 54
        $this->loadTemplate("profilDoctorNav.html.twig", "AppointmentsBundle:Holiday:unblockweekend.html.twig", 54)->display($context);
        // line 55
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                            
                                <h4>Unblock a weekend day</h4>
                                ";
        // line 60
        if ((($context["add"] ?? $this->getContext($context, "add")) == true)) {
            // line 61
            echo "                                <div class=\"alert alert-success\">
                                    <label>New day has been added successfully.</label>
                                </div>
                                ";
        }
        // line 65
        echo "                                <div class=\"col-sm-offset-4 col-sm-4\">
                                    <form id=\"dayform\" action=\"\" method=\"post\">
                                        <div class=\"form-group\">
                                            <label>Select Date</label>
                                            <input type=\"date\" id=\"date\" onchange=\"checkdate(this.value)\" class=\"form-control\" name=\"date\" />
                                        </div>
                                        <div style=\"text-align: center\">
                                            <p id=\"msg\"></p>
                                        </div>
                                        <input disabled='' id='submit' style=\"margin-top: 20px\" type=\"submit\" class=\"btn btn-info btn-block\">
                                    </form>
                                    <script>
                                        function checkdate(value){
                                            \$('#submit').attr('disabled',\"disabled\");
                                            \$('#msg').html(\"Please Wait...\");
                                            \$.ajax({
                                                url: '";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("holiday_weekend_getdetailofselecteddate");
        echo "?date='+value,
                                                type: 'POST',
                                                success: function(result){
                                                    if(result == \"true\"){
                                                        \$('#msg').html(\"Click submit to Unblock this weekend day!\");
                                                        \$('#submit').removeAttr('disabled');
                                                    }else if(result == \"found\"){
                                                        \$('#msg').html(\"This already Unblocked\");
                                            
                                                    }else if(result == \"false\"){
                                                       \$('#msg').html(\"This day is not in weekend\"); 
                                                    }
                                
                                                }
                                            });
                                        }
                                        \$('#dayform').submit(function(e){
                                            if(\$('#date').val() == \"\"){
                                                e.preventDefault();
                                            }
                                        });
                                    </script>

                                </div>
                                <div style=\"margin-top: 10px\">
                                    <table>
                                        <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        ";
        // line 114
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["days"] ?? $this->getContext($context, "days")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 115
            echo "                                            <tr>
                                                <td>";
            // line 116
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "date", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                                                <td><a href=\"";
            // line 117
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("holiday_weekend_unblock_delete", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\">Delete</a></td>
                                            </tr>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 120
        echo "                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>


        ";
        // line 131
        $this->loadTemplate("default/footer.html.twig", "AppointmentsBundle:Holiday:unblockweekend.html.twig", 131)->display($context);
        // line 132
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AppointmentsBundle:Holiday:unblockweekend.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  237 => 132,  235 => 131,  222 => 120,  213 => 117,  209 => 116,  206 => 115,  202 => 114,  166 => 81,  148 => 65,  142 => 61,  140 => 60,  133 => 55,  131 => 54,  125 => 53,  113 => 46,  109 => 44,  101 => 39,  95 => 35,  92 => 34,  86 => 31,  83 => 30,  75 => 27,  72 => 26,  70 => 25,  54 => 12,  47 => 7,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}

        {#<body class=\"tg-home tg-login\">#}
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.idTable }) }}\">{{ 'Profile'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                            
                                <h4>Unblock a weekend day</h4>
                                {% if add == true %}
                                <div class=\"alert alert-success\">
                                    <label>New day has been added successfully.</label>
                                </div>
                                {% endif %}
                                <div class=\"col-sm-offset-4 col-sm-4\">
                                    <form id=\"dayform\" action=\"\" method=\"post\">
                                        <div class=\"form-group\">
                                            <label>Select Date</label>
                                            <input type=\"date\" id=\"date\" onchange=\"checkdate(this.value)\" class=\"form-control\" name=\"date\" />
                                        </div>
                                        <div style=\"text-align: center\">
                                            <p id=\"msg\"></p>
                                        </div>
                                        <input disabled='' id='submit' style=\"margin-top: 20px\" type=\"submit\" class=\"btn btn-info btn-block\">
                                    </form>
                                    <script>
                                        function checkdate(value){
                                            \$('#submit').attr('disabled',\"disabled\");
                                            \$('#msg').html(\"Please Wait...\");
                                            \$.ajax({
                                                url: '{{ path('holiday_weekend_getdetailofselecteddate') }}?date='+value,
                                                type: 'POST',
                                                success: function(result){
                                                    if(result == \"true\"){
                                                        \$('#msg').html(\"Click submit to Unblock this weekend day!\");
                                                        \$('#submit').removeAttr('disabled');
                                                    }else if(result == \"found\"){
                                                        \$('#msg').html(\"This already Unblocked\");
                                            
                                                    }else if(result == \"false\"){
                                                       \$('#msg').html(\"This day is not in weekend\"); 
                                                    }
                                
                                                }
                                            });
                                        }
                                        \$('#dayform').submit(function(e){
                                            if(\$('#date').val() == \"\"){
                                                e.preventDefault();
                                            }
                                        });
                                    </script>

                                </div>
                                <div style=\"margin-top: 10px\">
                                    <table>
                                        <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        {% for item in days %}
                                            <tr>
                                                <td>{{ item.date|date('d-m-Y') }}</td>
                                                <td><a href=\"{{ path('holiday_weekend_unblock_delete',{id:item.id}) }}\">Delete</a></td>
                                            </tr>
                                        {% endfor %}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>


        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}", "AppointmentsBundle:Holiday:unblockweekend.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AppointmentsBundle/Resources/views/Holiday/unblockweekend.html.twig");
    }
}

<?php

/* AppointmentsBundle:Holiday:display.html.twig */
class __TwigTemplate_048e8c0f7d785cf91e03eb9604356af73137baa355634773b935e1727bd91847 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppointmentsBundle:Holiday:display.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "AppointmentsBundle:Holiday:display.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
        ";
        // line 7
        echo "        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            ";
        // line 25
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 26
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 30
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 34
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 35
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 44
        echo "                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 54
        $this->loadTemplate("profilDoctorNav.html.twig", "AppointmentsBundle:Holiday:display.html.twig", 54)->display($context);
        // line 55
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <h2>Holidays</h2>
                                <h3>Your Weekends</h3>
                                <a href=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("holiday_addweekend");
        echo "\" class=\"label label-info\"> + add weekend</a>
                                <a href=\"";
        // line 61
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("holiday_weekend_unblock");
        echo "\" class=\"label label-danger\"> - Unblock Weekend</a>

                                <table class=\"table table-hover\">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Day</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    ";
        // line 72
        $context["count"] = 1;
        // line 73
        echo "                                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["weekend"] ?? $this->getContext($context, "weekend")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 74
            echo "                                        <tr>
                                            <th>";
            // line 75
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "</th>
                                            <td>";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "day", array()), "html", null, true);
            echo "</td>
                                            <td><a href=\"";
            // line 77
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("holiday_addweekend_delete", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\">delete</a></td>
                                        </tr>
                                        ";
            // line 79
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 80
            echo "                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 81
        echo "                                    </tbody>
                                </table>
                                <h3>Holidays by Admin</h3>
                                <table class=\"table table-hover\" border=\"0\">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Reason</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                    <tbody>
                                    ";
        // line 94
        $context["count"] = 1;
        // line 95
        echo "                                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pha"] ?? $this->getContext($context, "pha")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 96
            echo "                                        ";
            $context["check"] = 0;
            // line 97
            echo "                                        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["unb"] ?? $this->getContext($context, "unb")));
            foreach ($context['_seq'] as $context["_key"] => $context["inner"]) {
                // line 98
                echo "                                            ";
                if (($this->getAttribute($context["inner"], "ph", array()) == $context["item"])) {
                    // line 99
                    echo "                                                ";
                    $context["check"] = 1;
                    // line 100
                    echo "                                            ";
                }
                // line 101
                echo "                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['inner'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 102
            echo "                                        <tr>
                                            <td>";
            // line 103
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "</td>
                                            <td>";
            // line 104
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "date", array()), "html", null, true);
            echo "</td>
                                            <td>";
            // line 105
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "reason", array()), "html", null, true);
            echo "</td>
                                            <td><a id=\"pha";
            // line 106
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "\" onclick=\"changestatus(";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo ",'pha";
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "')\" href=\"javascript:void(0)\">";
            if ((($context["check"] ?? $this->getContext($context, "check")) == 1)) {
                echo "block";
            } else {
                echo "unblock";
            }
            echo "</a></td>
                                        </tr>
                                        ";
            // line 108
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 109
            echo "                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "
                                    </tbody>
                                    </table>
                                <script>
                                    function changestatus(id,pha){
                                        \$(\"#\"+pha).html('Changing...');
                                        \$(\"#\"+pha).attr('disabled','disabled');
                                        \$.ajax({
                                            url: '";
        // line 118
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("holiday_statuschange");
        echo "?id='+id,
                                            type: 'POST',
                                            success: function(result){
                                                if(result == 'block'){
                                                    \$(\"#\"+pha).html('block');
                                                }else{
                                                    \$(\"#\"+pha).html('unblock');
                                                }
                                            }
                                        })
                                    }
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>


        ";
        // line 138
        $this->loadTemplate("default/footer.html.twig", "AppointmentsBundle:Holiday:display.html.twig", 138)->display($context);
        // line 139
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AppointmentsBundle:Holiday:display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  307 => 139,  305 => 138,  282 => 118,  272 => 110,  266 => 109,  264 => 108,  249 => 106,  245 => 105,  241 => 104,  237 => 103,  234 => 102,  228 => 101,  225 => 100,  222 => 99,  219 => 98,  214 => 97,  211 => 96,  206 => 95,  204 => 94,  189 => 81,  183 => 80,  181 => 79,  176 => 77,  172 => 76,  168 => 75,  165 => 74,  160 => 73,  158 => 72,  144 => 61,  140 => 60,  133 => 55,  131 => 54,  125 => 53,  113 => 46,  109 => 44,  101 => 39,  95 => 35,  92 => 34,  86 => 31,  83 => 30,  75 => 27,  72 => 26,  70 => 25,  54 => 12,  47 => 7,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}

        {#<body class=\"tg-home tg-login\">#}
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\">
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.idTable }) }}\">{{ 'Profile'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <h2>Holidays</h2>
                                <h3>Your Weekends</h3>
                                <a href=\"{{ path('holiday_addweekend') }}\" class=\"label label-info\"> + add weekend</a>
                                <a href=\"{{ path('holiday_weekend_unblock') }}\" class=\"label label-danger\"> - Unblock Weekend</a>

                                <table class=\"table table-hover\">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Day</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {% set count = 1 %}
                                    {% for item in weekend %}
                                        <tr>
                                            <th>{{ count }}</th>
                                            <td>{{ item.day }}</td>
                                            <td><a href=\"{{ path('holiday_addweekend_delete',{id:item.id}) }}\">delete</a></td>
                                        </tr>
                                        {% set count = count + 1 %}
                                    {% endfor %}
                                    </tbody>
                                </table>
                                <h3>Holidays by Admin</h3>
                                <table class=\"table table-hover\" border=\"0\">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Reason</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                    <tbody>
                                    {% set count = 1 %}
                                    {% for item in pha %}
                                        {% set check = 0 %}
                                        {% for inner in unb %}
                                            {% if inner.ph == item %}
                                                {% set check = 1 %}
                                            {% endif %}
                                        {% endfor %}
                                        <tr>
                                            <td>{{ count }}</td>
                                            <td>{{ item.date }}</td>
                                            <td>{{ item.reason }}</td>
                                            <td><a id=\"pha{{ count }}\" onclick=\"changestatus({{ item.id }},'pha{{ count }}')\" href=\"javascript:void(0)\">{% if check == 1 %}block{% else %}unblock{% endif %}</a></td>
                                        </tr>
                                        {% set count = count + 1 %}
                                    {% endfor %}

                                    </tbody>
                                    </table>
                                <script>
                                    function changestatus(id,pha){
                                        \$(\"#\"+pha).html('Changing...');
                                        \$(\"#\"+pha).attr('disabled','disabled');
                                        \$.ajax({
                                            url: '{{ path('holiday_statuschange') }}?id='+id,
                                            type: 'POST',
                                            success: function(result){
                                                if(result == 'block'){
                                                    \$(\"#\"+pha).html('block');
                                                }else{
                                                    \$(\"#\"+pha).html('unblock');
                                                }
                                            }
                                        })
                                    }
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>


        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}", "AppointmentsBundle:Holiday:display.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AppointmentsBundle/Resources/views/Holiday/display.html.twig");
    }
}

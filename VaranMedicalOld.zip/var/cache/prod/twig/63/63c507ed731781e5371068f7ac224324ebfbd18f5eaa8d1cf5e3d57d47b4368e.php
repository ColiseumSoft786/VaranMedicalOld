<?php

/* certifications/new.html.twig */
class __TwigTemplate_babe4988c8c7f32f4c63918b7d1dd15318a57c3b0ebe49b54235fd1ad27138a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b44ea217eb381db2aa9f4c492f788cedef0ea7a7a175dc5e3a97b4ee574c458 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b44ea217eb381db2aa9f4c492f788cedef0ea7a7a175dc5e3a97b4ee574c458->enter($__internal_0b44ea217eb381db2aa9f4c492f788cedef0ea7a7a175dc5e3a97b4ee574c458_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "certifications/new.html.twig"));

        // line 1
        echo "<div class=\"row\">
    <div class=\"tg-alertmessages\">
        <div class=\"alert alert-success tg-alertmessage fade in\" hidden id=\"successCertification\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-check\"></i>
            <span><strong>Felecitation !</strong> Ajouter avec success.</span>
        </div>
        <div class=\"alert alert-warning tg-alertmessage fade in\" hidden id=\"warningCertification\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-exclamation-triangle\"></i>
            <span><strong>";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("warning Message"), "html", null, true);
        echo "</strong> Deja existe.</span>
        </div>
        <div class=\"alert alert-danger tg-alertmessage fade in\" hidden id=\"erreurCertification\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-bug\"></i>
            <span><strong>";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Error Message"), "html", null, true);
        echo "</strong> Erreur en ajout.</span>
        </div>
    </div>
</div>
<br><br>
<div class=\"row tg-rowmargin\">
    <form action=\"\" id=\"formCertification\">
        <div class=\"col-sm-10 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "title", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Titre")));
        echo "
                ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "
            </div>
        </div>
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "occasion", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "L'occasion")));
        echo "
            </div>
        </div>
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                ";
        // line 36
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'widget', array("attr" => array("class" => "form-control js-datepicker ", "placeholder" => "Date")));
        echo "
                <input type=\"hidden\" id=\"doctorsbundle_certifications_doctor\" name=\"doctorsbundle_certifications[doctor]\" >
            </div>
        </div>
        <div class=\"col-md-2 col-sm-3 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <button class=\"tg-btn tg-btn-lg\" type=\"submit\">";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("add now"), "html", null, true);
        echo "</button>
            </div>
        </div>
    </form>
</div>

";
        
        $__internal_0b44ea217eb381db2aa9f4c492f788cedef0ea7a7a175dc5e3a97b4ee574c458->leave($__internal_0b44ea217eb381db2aa9f4c492f788cedef0ea7a7a175dc5e3a97b4ee574c458_prof);

    }

    public function getTemplateName()
    {
        return "certifications/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 42,  74 => 36,  66 => 31,  58 => 26,  54 => 25,  42 => 16,  34 => 11,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"row\">
    <div class=\"tg-alertmessages\">
        <div class=\"alert alert-success tg-alertmessage fade in\" hidden id=\"successCertification\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-check\"></i>
            <span><strong>Felecitation !</strong> Ajouter avec success.</span>
        </div>
        <div class=\"alert alert-warning tg-alertmessage fade in\" hidden id=\"warningCertification\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-exclamation-triangle\"></i>
            <span><strong>{{ 'warning Message'|trans }}</strong> Deja existe.</span>
        </div>
        <div class=\"alert alert-danger tg-alertmessage fade in\" hidden id=\"erreurCertification\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-bug\"></i>
            <span><strong>{{ 'Error Message'|trans }}</strong> Erreur en ajout.</span>
        </div>
    </div>
</div>
<br><br>
<div class=\"row tg-rowmargin\">
    <form action=\"\" id=\"formCertification\">
        <div class=\"col-sm-10 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                {{ form_widget(form.title, {'attr':{'class':'form-control', 'placeholder':'Titre'}}) }}
                {{ form_widget(form._token) }}
            </div>
        </div>
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                {{ form_widget(form.occasion, {'attr':{'class':'form-control', 'placeholder':'L\\'occasion'}}) }}
            </div>
        </div>
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                {{ form_widget(form.date, {'attr':{'class':'form-control js-datepicker ', 'placeholder':'Date'}}) }}
                <input type=\"hidden\" id=\"doctorsbundle_certifications_doctor\" name=\"doctorsbundle_certifications[doctor]\" >
            </div>
        </div>
        <div class=\"col-md-2 col-sm-3 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <button class=\"tg-btn tg-btn-lg\" type=\"submit\">{{ 'add now'|trans }}</button>
            </div>
        </div>
    </form>
</div>

", "certifications/new.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\certifications\\new.html.twig");
    }
}

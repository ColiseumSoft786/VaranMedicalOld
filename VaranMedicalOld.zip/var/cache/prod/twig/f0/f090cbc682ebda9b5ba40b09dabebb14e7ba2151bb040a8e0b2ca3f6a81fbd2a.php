<?php

/* user/login2.html.twig */
class __TwigTemplate_cc44d8eb041769a1f871596bd1b8d04790c25ed24ca9536a6922f670f2e8dcb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login2.html.twig"));

        // line 1
        echo "<div class=\"tg-widget tg-widgetlogin\">
    <div class=\"tg-widgetcontent\">
        <div class=\"tg-widgettitle\">
            <h3>Connectez-vous à votre compte MedicalApp</h3>
        </div>
        <form action=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\" class=\"tg-themeform tg-formsignin\" id=\"fosloginform\">
            ";
        // line 7
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 8
            echo "                <div class=\"row\">
                    <div class=\"col-sm-12 col-xs-12\">
                        <div class=\"tg-alertmessages\">
                            <div class=\"alert alert-danger tg-alertmessage fade in\">
                                <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                                <i class=\"fa fa-bug\"></i>
                                <span><strong>Error Message.</strong> ";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</span>
                            </div>
                        </div>
                    </div>
                </div>
            ";
        }
        // line 20
        echo "            ";
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 21
            echo "                <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
            ";
        }
        // line 23
        echo "            <fieldset>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"tg-kepploginpassword\">
                    <div class=\"tg-checkbox\">
                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                        <label for=\"keeplogin\">Garder ma session active</label>
                    </div>
                </div>
                <div id=\"divformresult\" style=\"width: 40%\" class=\"center-block text-center\">
                    <div style=\"display: none\" id=\"_notmatched\" class=\"text-danger\">User name and password not matched</div>
                    <div style=\"display: none\" id=\"_matched\" class=\"text-success\">User name and password matched</div>
                </div>
                <div id=\"divemailcode\" style=\"width: 40%;margin-bottom: 20px;display: none\" class=\"center-block text-center\">
                    <div class=\"text-info\">Code has been sent to your Email</div>
                    <input type=\"text\" id=\"emailcode\" placeholder=\"Ender Code\" class=\"form-control\">
                </div>

                <button type=\"submit\" class=\"tg-btn col-sm-12 col-xs-12\" id=\"_submit\" name=\"_submit\" style=\"background-color: #00adcf\"><b>Se connecter</b></button>
            </fieldset>
            <a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_resetting_request");
        echo "\" class=\"\"><b>Mot de passe oublie ?</b></a>
            <br>
            <hr>
            <div class=\"tg-widgettitle\">
                <h3>Nouveau à MedicalApp ?</h3>
            </div>
            <button type=\"button\" class=\"tg-btn tg-btnnext col-sm-12 col-xs-12\" style=\"background-color: #00adcf\"><b>Créer un compte</b></button>

        </form>
        <script>
            var code;
            var formcheck = true;
            \$('#fosloginform').submit(function(e){
                if (formcheck){
                    e.preventDefault();
                    \$('#username').attr('readonly','readonly');
                    \$('#password').attr('readonly','readonly');
                    \$('#remember_me').attr('readonly','readonly');
                    \$('#_submit').attr('disabled','disabled');
                    \$.ajax({
                        url: '";
        // line 67
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_ipcheck");
        echo "',
                        type: 'POST',
                        data: \$(this).serialize(),
                        success: function(result){
                            if(result == 'false'){
                                \$('#_notmatched').show();
                                \$('#_matched').hide();
                                \$('#_submit').removeAttr('disabled');
                                \$('#username').removeAttr('readonly');
                                \$('#password').removeAttr('readonly');
                                \$('#remember_me').removeAttr('readonly');
                            }else if(result == 'true'){
                                \$('#_matched').show();
                                formcheck = false;
                                \$('#fosloginform').submit();
                            }else{
                                code = result;
                                \$('#_notmatched').hide();
                                \$('#_matched').show();
                                \$('#divemailcode').show();
                            }
                            alert(result);
                        }
                    })
                }

            });
            \$('#emailcode').keyup(function () {
                if (\$(this).val() == code){
                    \$('#_submit').removeAttr('disabled');
                    formcheck = false;
                }else{
                    \$('#_submit').attr('disabled','disabled');
                    formcheck = true;
                }
            })
        </script>
    </div>

</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/login2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 67,  90 => 47,  65 => 25,  61 => 23,  55 => 21,  52 => 20,  43 => 14,  35 => 8,  33 => 7,  29 => 6,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"tg-widget tg-widgetlogin\">
    <div class=\"tg-widgetcontent\">
        <div class=\"tg-widgettitle\">
            <h3>Connectez-vous à votre compte MedicalApp</h3>
        </div>
        <form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\" class=\"tg-themeform tg-formsignin\" id=\"fosloginform\">
            {% if error %}
                <div class=\"row\">
                    <div class=\"col-sm-12 col-xs-12\">
                        <div class=\"tg-alertmessages\">
                            <div class=\"alert alert-danger tg-alertmessage fade in\">
                                <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                                <i class=\"fa fa-bug\"></i>
                                <span><strong>Error Message.</strong> {{ error.messageKey|trans(error.messageData, 'security') }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            {% endif %}
            {% if csrf_token %}
                <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
            {% endif %}
            <fieldset>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"tg-kepploginpassword\">
                    <div class=\"tg-checkbox\">
                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                        <label for=\"keeplogin\">Garder ma session active</label>
                    </div>
                </div>
                <div id=\"divformresult\" style=\"width: 40%\" class=\"center-block text-center\">
                    <div style=\"display: none\" id=\"_notmatched\" class=\"text-danger\">User name and password not matched</div>
                    <div style=\"display: none\" id=\"_matched\" class=\"text-success\">User name and password matched</div>
                </div>
                <div id=\"divemailcode\" style=\"width: 40%;margin-bottom: 20px;display: none\" class=\"center-block text-center\">
                    <div class=\"text-info\">Code has been sent to your Email</div>
                    <input type=\"text\" id=\"emailcode\" placeholder=\"Ender Code\" class=\"form-control\">
                </div>

                <button type=\"submit\" class=\"tg-btn col-sm-12 col-xs-12\" id=\"_submit\" name=\"_submit\" style=\"background-color: #00adcf\"><b>Se connecter</b></button>
            </fieldset>
            <a href=\"{{ path('fos_user_resetting_request') }}\" class=\"\"><b>Mot de passe oublie ?</b></a>
            <br>
            <hr>
            <div class=\"tg-widgettitle\">
                <h3>Nouveau à MedicalApp ?</h3>
            </div>
            <button type=\"button\" class=\"tg-btn tg-btnnext col-sm-12 col-xs-12\" style=\"background-color: #00adcf\"><b>Créer un compte</b></button>

        </form>
        <script>
            var code;
            var formcheck = true;
            \$('#fosloginform').submit(function(e){
                if (formcheck){
                    e.preventDefault();
                    \$('#username').attr('readonly','readonly');
                    \$('#password').attr('readonly','readonly');
                    \$('#remember_me').attr('readonly','readonly');
                    \$('#_submit').attr('disabled','disabled');
                    \$.ajax({
                        url: '{{ path('user_ipcheck') }}',
                        type: 'POST',
                        data: \$(this).serialize(),
                        success: function(result){
                            if(result == 'false'){
                                \$('#_notmatched').show();
                                \$('#_matched').hide();
                                \$('#_submit').removeAttr('disabled');
                                \$('#username').removeAttr('readonly');
                                \$('#password').removeAttr('readonly');
                                \$('#remember_me').removeAttr('readonly');
                            }else if(result == 'true'){
                                \$('#_matched').show();
                                formcheck = false;
                                \$('#fosloginform').submit();
                            }else{
                                code = result;
                                \$('#_notmatched').hide();
                                \$('#_matched').show();
                                \$('#divemailcode').show();
                            }
                            alert(result);
                        }
                    })
                }

            });
            \$('#emailcode').keyup(function () {
                if (\$(this).val() == code){
                    \$('#_submit').removeAttr('disabled');
                    formcheck = false;
                }else{
                    \$('#_submit').attr('disabled','disabled');
                    formcheck = true;
                }
            })
        </script>
    </div>

</div>

", "user/login2.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\login2.html.twig");
    }
}

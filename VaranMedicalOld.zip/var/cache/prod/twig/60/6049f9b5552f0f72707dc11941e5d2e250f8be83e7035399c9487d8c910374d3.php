<?php

/* specialities/comboSpecialitiers.html.twig */
class __TwigTemplate_6df6c22c6c63185ea702b11f7fee74279d54ec1f2a764825cfc05386ec8d16fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "specialities/comboSpecialitiers.html.twig"));

        // line 1
        echo "<div class=\"col-lg-12\">
    <div class=\"form-group tg-formgroup\">
        <span class=\"tg-select\">
            <select id=\"comboSpecialitie\" name=\"specialite\">
                <option disabled=\"disabled\" selected=\"selected\">";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Selectionner"), "html", null, true);
        echo "</option>
                ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["specialities"] ?? $this->getContext($context, "specialities")));
        foreach ($context['_seq'] as $context["_key"] => $context["specialitie"]) {
            // line 7
            echo "                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["specialitie"], "libelle", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["specialitie"], "libelle", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['specialitie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "
            </select>
        </span>
    </div>
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "specialities/comboSpecialitiers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 9,  36 => 7,  32 => 6,  28 => 5,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"col-lg-12\">
    <div class=\"form-group tg-formgroup\">
        <span class=\"tg-select\">
            <select id=\"comboSpecialitie\" name=\"specialite\">
                <option disabled=\"disabled\" selected=\"selected\">{{ 'Selectionner'|trans }}</option>
                {% for specialitie in specialities %}
                    <option value=\"{{ specialitie.libelle }}\">{{ specialitie.libelle }}</option>
                {% endfor %}

            </select>
        </span>
    </div>
</div>", "specialities/comboSpecialitiers.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\specialities\\comboSpecialitiers.html.twig");
    }
}

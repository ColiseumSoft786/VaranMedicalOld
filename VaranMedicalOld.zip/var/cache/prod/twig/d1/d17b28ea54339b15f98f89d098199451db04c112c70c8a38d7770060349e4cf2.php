<?php

/* reasons/comboReasons.html.twig */
class __TwigTemplate_96fc29ac05f36700d0ce38f9a086c373d55764f7d85ddd19b0332a58e33123e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "reasons/comboReasons.html.twig"));

        // line 1
        echo "
<div class=\"col-lg-12\">
    <div class=\"form-group tg-formgroup\">
        <span class=\"tg-select\">
            <select id=\"appointmentsbundle_appointments_reason\" name=\"appointmentsbundle_appointments[reason]\">
                <option>";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Selectionner"), "html", null, true);
        echo "</option>
                ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["reasons"] ?? $this->getContext($context, "reasons")));
        foreach ($context['_seq'] as $context["_key"] => $context["reason"]) {
            // line 8
            echo "                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reason"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reason"], "reason", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reason'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "
            </select>
        </span>
    </div>
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "reasons/comboReasons.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 10,  37 => 8,  33 => 7,  29 => 6,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
<div class=\"col-lg-12\">
    <div class=\"form-group tg-formgroup\">
        <span class=\"tg-select\">
            <select id=\"appointmentsbundle_appointments_reason\" name=\"appointmentsbundle_appointments[reason]\">
                <option>{{ 'Selectionner'|trans }}</option>
                {% for reason in reasons %}
                    <option value=\"{{ reason.id }}\">{{ reason.reason }}</option>
                {% endfor %}

            </select>
        </span>
    </div>
</div>", "reasons/comboReasons.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\reasons\\comboReasons.html.twig");
    }
}

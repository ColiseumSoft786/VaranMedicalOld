<?php

/* specialities/profilEditcomboSpecialities.html.twig */
class __TwigTemplate_617f03888f6883f253cdfe77d06e3f88286cec96a6b99339ce122a41a325db65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a99eb095fd627f19b5da964c76fd03ada2e93d07c92be0bae86139bdd213ace = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a99eb095fd627f19b5da964c76fd03ada2e93d07c92be0bae86139bdd213ace->enter($__internal_2a99eb095fd627f19b5da964c76fd03ada2e93d07c92be0bae86139bdd213ace_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "specialities/profilEditcomboSpecialities.html.twig"));

        // line 1
        echo "<div class=\"row\">
    <div class=\"tg-alertmessages\">
        <div class=\"alert alert-success tg-alertmessage fade in\" hidden id=\"success\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-check\"></i>
            <span><strong>success Message.</strong> Ajouter avec succès.</span>
        </div>
        <div class=\"alert alert-warning tg-alertmessage fade in\" hidden id=\"warning\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-exclamation-triangle\"></i>
            <span><strong>warning Message.</strong> Existe déjà.</span>
        </div>
        <div class=\"alert alert-danger tg-alertmessage fade in\" hidden id=\"erreur\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-bug\"></i>
            <span><strong>Error Message.</strong> Erreur en ajout.</span>
        </div>
    </div>
</div>
<br><br>
<div class=\"row tg-rowmargin\">
        <div class=\"col-md-10 col-sm-9 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <span class=\"tg-select\">
                    <select id=\"specialitie\" required >
                        <option value=\"\">";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select/Type Specializations"), "html", null, true);
        echo "</option>
                        ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["specialities"] ?? $this->getContext($context, "specialities")));
        foreach ($context['_seq'] as $context["_key"] => $context["specialitie"]) {
            // line 28
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["specialitie"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["specialitie"], "libelle", array()), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['specialitie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "                    </select>
                </span>
            </div>
        </div>
        <div class=\"col-md-2 col-sm-3 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <button class=\"tg-btn tg-btn-lg\" id=\"AddSpecialities\" >";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("add now"), "html", null, true);
        echo "</button>
            </div>
        </div>
</div>
";
        
        $__internal_2a99eb095fd627f19b5da964c76fd03ada2e93d07c92be0bae86139bdd213ace->leave($__internal_2a99eb095fd627f19b5da964c76fd03ada2e93d07c92be0bae86139bdd213ace_prof);

    }

    public function getTemplateName()
    {
        return "specialities/profilEditcomboSpecialities.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 36,  68 => 30,  57 => 28,  53 => 27,  49 => 26,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"row\">
    <div class=\"tg-alertmessages\">
        <div class=\"alert alert-success tg-alertmessage fade in\" hidden id=\"success\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-check\"></i>
            <span><strong>success Message.</strong> Ajouter avec succès.</span>
        </div>
        <div class=\"alert alert-warning tg-alertmessage fade in\" hidden id=\"warning\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-exclamation-triangle\"></i>
            <span><strong>warning Message.</strong> Existe déjà.</span>
        </div>
        <div class=\"alert alert-danger tg-alertmessage fade in\" hidden id=\"erreur\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-bug\"></i>
            <span><strong>Error Message.</strong> Erreur en ajout.</span>
        </div>
    </div>
</div>
<br><br>
<div class=\"row tg-rowmargin\">
        <div class=\"col-md-10 col-sm-9 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <span class=\"tg-select\">
                    <select id=\"specialitie\" required >
                        <option value=\"\">{{ 'Select/Type Specializations'|trans }}</option>
                        {% for specialitie in specialities %}
                            <option value=\"{{ specialitie.id }}\">{{ specialitie.libelle }}</option>
                        {% endfor %}
                    </select>
                </span>
            </div>
        </div>
        <div class=\"col-md-2 col-sm-3 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <button class=\"tg-btn tg-btn-lg\" id=\"AddSpecialities\" >{{ 'add now'|trans }}</button>
            </div>
        </div>
</div>
", "specialities/profilEditcomboSpecialities.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\specialities\\profilEditcomboSpecialities.html.twig");
    }
}

<?php

/* PatientBundle:Doctor:display.html.twig */
class __TwigTemplate_2430290612fe6261688a5d7d69a37df6867ef294c325b936d38752158eb43d8d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PatientBundle:Doctor:display.html.twig"));

        // line 1
        $this->loadTemplate("base.html.twig", "PatientBundle:Doctor:display.html.twig", 1)->display($context);
        // line 2
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************-->

<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\">
                                    ";
        // line 32
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["patient"] ?? $this->getContext($context, "patient")), "imageFile")) {
            // line 33
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["patient"] ?? $this->getContext($context, "patient")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "image", array()), "html", null, true);
            echo "\" />
                                        </a>
                                    ";
        } else {
            // line 37
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                        </a>
                                    ";
        }
        // line 41
        echo "                                </figure>                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("patient_editProfil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Mis à jour"), "html", null, true);
        echo "</a> </div>

                            ";
        // line 51
        $this->loadTemplate("profilPatientNav.html.twig", "PatientBundle:Doctor:display.html.twig", 51)->display($context);
        // line 52
        echo "                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                      <h3>Your Doctors</h3>
                          ";
        // line 56
        if ((twig_length_filter($this->env, ($context["dp"] ?? $this->getContext($context, "dp"))) != 0)) {
            // line 57
            echo "                            <table>
                                <thead>
                                  <tr>
                                    <th>#</th>
                                    <th>Doctor Name</th>
                                    <th>Review</th>
                                    <th>Status</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  ";
            // line 67
            $context["count"] = 1;
            // line 68
            echo "                                  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["dp"] ?? $this->getContext($context, "dp")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 69
                echo "                                  <tr>
                                    <td>";
                // line 70
                echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
                echo "</td>
                                    <td>";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "doctor", array()), "firstname", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "doctor", array()), "lastname", array()), "html", null, true);
                echo "</td>
                                    <td style=\"width: 40%\">";
                // line 72
                if (($this->getAttribute($context["item"], "review", array()) == "")) {
                    // line 73
                    echo "                                       <form action=\"";
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctor_managment_display_review");
                    echo "\" method=\"post\">
                                          <input type=\"text\" placeholder=\"Enter Your Review\" name=\"review\">
                                          <input type=\"hidden\" name=\"id\" value=\"";
                    // line 75
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                          <input type=\"submit\" class='btn btn-primary' value=\"Submit\">
                                       </form>
                                       ";
                } else {
                    // line 78
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "review", array()), "html", null, true);
                    echo " ";
                }
                echo " </td>
                                    <td>";
                // line 79
                if (($this->getAttribute($context["item"], "block", array()) == 1)) {
                    echo " <label class=\"label label-danger\">Blocked</label> ";
                } else {
                    echo " <label class=\"label label-success\">Open for Appointments</label> ";
                }
                echo "</td>
                                  </tr>
                                  ";
                // line 81
                $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
                // line 82
                echo "                                  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 83
            echo "
                                </tbody>
                            </table>

                          ";
        }
        // line 88
        echo "                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
";
        // line 101
        $this->loadTemplate("default/footer.html.twig", "PatientBundle:Doctor:display.html.twig", 101)->display($context);
        // line 102
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "PatientBundle:Doctor:display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  220 => 102,  218 => 101,  203 => 88,  196 => 83,  190 => 82,  188 => 81,  179 => 79,  172 => 78,  165 => 75,  159 => 73,  157 => 72,  151 => 71,  147 => 70,  144 => 69,  139 => 68,  137 => 67,  125 => 57,  123 => 56,  117 => 52,  115 => 51,  108 => 49,  96 => 42,  93 => 41,  87 => 38,  84 => 37,  76 => 34,  73 => 33,  71 => 32,  55 => 19,  37 => 3,  25 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include ('base.html.twig') %}
{% block body %}
<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************-->

<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\">
                                    {% if vich_uploader_asset(patient, 'imageFile') %}
                                        <a href=\"#\">
                                            <img src=\"{{ vich_uploader_asset(patient, 'imageFile') }}\" alt=\"{{ patient.image }}\" />
                                        </a>
                                    {% else %}
                                        <a href=\"#\">
                                            <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                        </a>
                                    {% endif %}
                                </figure>                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">{{ patient.firstName }} {{ patient.lastName }}</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('patient_editProfil', {'id':app.user.idTable }) }}\">{{ 'Mis à jour'|trans }}</a> </div>

                            {% include('profilPatientNav.html.twig') %}
                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                      <h3>Your Doctors</h3>
                          {% if dp|length != 0 %}
                            <table>
                                <thead>
                                  <tr>
                                    <th>#</th>
                                    <th>Doctor Name</th>
                                    <th>Review</th>
                                    <th>Status</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {% set count = 1 %}
                                  {% for item in dp %}
                                  <tr>
                                    <td>{{ count }}</td>
                                    <td>{{ item.doctor.firstname }} {{ item.doctor.lastname }}</td>
                                    <td style=\"width: 40%\">{% if item.review == \"\" %}
                                       <form action=\"{{ path('doctor_managment_display_review') }}\" method=\"post\">
                                          <input type=\"text\" placeholder=\"Enter Your Review\" name=\"review\">
                                          <input type=\"hidden\" name=\"id\" value=\"{{ item.id }}\">
                                          <input type=\"submit\" class='btn btn-primary' value=\"Submit\">
                                       </form>
                                       {% else %} {{ item.review }} {% endif %} </td>
                                    <td>{% if item.block == 1 %} <label class=\"label label-danger\">Blocked</label> {% else %} <label class=\"label label-success\">Open for Appointments</label> {% endif %}</td>
                                  </tr>
                                  {% set count = count + 1 %}
                                  {% endfor %}

                                </tbody>
                            </table>

                          {% endif %}
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
{% include ('default/footer.html.twig') %}

{% endblock %}
", "PatientBundle:Doctor:display.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\PatientBundle/Resources/views/Doctor/display.html.twig");
    }
}

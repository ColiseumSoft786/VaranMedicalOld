<?php

/* doctors/doctorDetailsCertifications.html.twig */
class __TwigTemplate_de52e222b2acd23b0866508a8cea020ee54f1452623e29740733c6d683fe4271 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "doctors/doctorDetailsCertifications.html.twig"));

        // line 1
        if (($context["certifications"] ?? $this->getContext($context, "certifications"))) {
            // line 2
            echo "    <div class=\"tg-box\">
        <div class=\"tg-icontitle\">
            <h3 class=\"fa fa-mortar-board\">";
            // line 4
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Certification"), "html", null, true);
            echo "</h3>
        </div>
        <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle tg-education\">
            ";
            // line 7
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["certifications"] ?? $this->getContext($context, "certifications")));
            foreach ($context['_seq'] as $context["_key"] => $context["certification"]) {
                // line 8
                echo "                <li>
                    <span>";
                // line 9
                echo twig_escape_filter($this->env, $this->getAttribute($context["certification"], "title", array()), "html", null, true);
                echo "</span>
                    <span>";
                // line 10
                echo twig_escape_filter($this->env, $this->getAttribute($context["certification"], "occasion", array()), "html", null, true);
                echo "</span>
                    <span>";
                // line 11
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["certification"], "date", array()), "d-M-Y"), "html", null, true);
                echo "</span>
                </li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['certification'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 14
            echo "        </ul>
    </div>
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "doctors/doctorDetailsCertifications.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  49 => 11,  45 => 10,  41 => 9,  38 => 8,  34 => 7,  28 => 4,  24 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if certifications %}
    <div class=\"tg-box\">
        <div class=\"tg-icontitle\">
            <h3 class=\"fa fa-mortar-board\">{{ 'Certification'|trans }}</h3>
        </div>
        <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle tg-education\">
            {% for certification in certifications %}
                <li>
                    <span>{{ certification.title }}</span>
                    <span>{{ certification.occasion }}</span>
                    <span>{{ certification.date|date('d-M-Y') }}</span>
                </li>
            {% endfor %}
        </ul>
    </div>
{% endif %}", "doctors/doctorDetailsCertifications.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\doctors\\doctorDetailsCertifications.html.twig");
    }
}

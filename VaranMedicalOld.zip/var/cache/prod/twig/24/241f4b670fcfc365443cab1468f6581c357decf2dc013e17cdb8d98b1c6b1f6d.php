<?php

/* DataBundle:Emails:cutcopy.html.twig */
class __TwigTemplate_fd56c67a6e3fe0020b4e30a606f4a83919b3717c2629853d7d7c3c16f2f8829c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "DataBundle:Emails:cutcopy.html.twig"));

        // line 1
        echo "Hello, ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstname", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastname", array()), "html", null, true);
        echo "
<br>
We hope you are fine, your appointment is ";
        // line 3
        echo twig_escape_filter($this->env, ($context["type"] ?? $this->getContext($context, "type")), "html", null, true);
        echo " by ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstname", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastname", array()), "html", null, true);
        echo ".
<br>
Status: ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "etat", array()), "html", null, true);
        echo "
<br>
Previous Appointment Location: <br>
Name: ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["oldsea"] ?? $this->getContext($context, "oldsea")), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
        echo "<br>
Address: ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["oldsea"] ?? $this->getContext($context, "oldsea")), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
        echo "<br>
Ville: ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["oldsea"] ?? $this->getContext($context, "oldsea")), "calendrie", array()), "location", array()), "ville", array()), "html", null, true);
        echo "<br>
Zip Code: ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["oldsea"] ?? $this->getContext($context, "oldsea")), "calendrie", array()), "location", array()), "codezip", array()), "html", null, true);
        echo "<br>
-------------- <br>
Appointment Time: ";
        // line 13
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["oldsea"] ?? $this->getContext($context, "oldsea")), "calendrie", array()), "date", array()), "d-m-Y"), "html", null, true);
        echo "<br>
Appointment Date: ";
        // line 14
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["oldsea"] ?? $this->getContext($context, "oldsea")), "heurdebut", array()), "H:i"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "heurfin", array()), "H:i"), "html", null, true);
        echo "<br>
<br>
New Appointment Location: <br>
Name: ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["newsea"] ?? $this->getContext($context, "newsea")), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
        echo "<br>
Address: ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["newsea"] ?? $this->getContext($context, "newsea")), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
        echo "<br>
Ville: ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["newsea"] ?? $this->getContext($context, "newsea")), "calendrie", array()), "location", array()), "ville", array()), "html", null, true);
        echo "<br>
Zip Code: ";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["newsea"] ?? $this->getContext($context, "newsea")), "calendrie", array()), "location", array()), "codezip", array()), "html", null, true);
        echo "<br>
-------------- <br>
Appointment Time: ";
        // line 22
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["newsea"] ?? $this->getContext($context, "newsea")), "calendrie", array()), "date", array()), "d-m-Y"), "html", null, true);
        echo "<br>
Appointment Date: ";
        // line 23
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["newsea"] ?? $this->getContext($context, "newsea")), "heurdebut", array()), "H:i"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "seance", array()), "heurfin", array()), "H:i"), "html", null, true);
        echo "<br>
<br>
cancel notifications: <br><b>For SMS:</b> <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("patient_profil_togglenotif");
        echo "?id=";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        echo "&toggle=sms&val=0\">click here</a> <br><b>For Email:</b> <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("patient_profil_togglenotif");
        echo "?id=";
        echo twig_escape_filter($this->env, ($context["id"] ?? $this->getContext($context, "id")), "html", null, true);
        echo "&toggle=email&val=0\">click here</a>
<br>

<b>Best Regards,</b> <br>
Varan Team
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "DataBundle:Emails:cutcopy.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 25,  95 => 23,  91 => 22,  86 => 20,  82 => 19,  78 => 18,  74 => 17,  66 => 14,  62 => 13,  57 => 11,  53 => 10,  49 => 9,  45 => 8,  39 => 5,  30 => 3,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello, {{ patient.firstname }} {{ patient.lastname }}
<br>
We hope you are fine, your appointment is {{ type }} by {{ doctor.firstname }} {{ doctor.lastname }}.
<br>
Status: {{ app.etat }}
<br>
Previous Appointment Location: <br>
Name: {{ oldsea.calendrie.location.name }}<br>
Address: {{ oldsea.calendrie.location.adresse }}<br>
Ville: {{ oldsea.calendrie.location.ville }}<br>
Zip Code: {{ oldsea.calendrie.location.codezip }}<br>
-------------- <br>
Appointment Time: {{ oldsea.calendrie.date|date('d-m-Y') }}<br>
Appointment Date: {{ oldsea.heurdebut|date('H:i') }} - {{ app.seance.heurfin|date('H:i') }}<br>
<br>
New Appointment Location: <br>
Name: {{ newsea.calendrie.location.name }}<br>
Address: {{ newsea.calendrie.location.adresse }}<br>
Ville: {{ newsea.calendrie.location.ville }}<br>
Zip Code: {{ newsea.calendrie.location.codezip }}<br>
-------------- <br>
Appointment Time: {{ newsea.calendrie.date|date('d-m-Y') }}<br>
Appointment Date: {{ newsea.heurdebut|date('H:i') }} - {{ app.seance.heurfin|date('H:i') }}<br>
<br>
cancel notifications: <br><b>For SMS:</b> <a href=\"{{ url('patient_profil_togglenotif') }}?id={{ id }}&toggle=sms&val=0\">click here</a> <br><b>For Email:</b> <a href=\"{{ url('patient_profil_togglenotif') }}?id={{ id }}&toggle=email&val=0\">click here</a>
<br>

<b>Best Regards,</b> <br>
Varan Team
", "DataBundle:Emails:cutcopy.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\DataBundle/Resources/views/Emails/cutcopy.html.twig");
    }
}

<?php

/* educations/new.html.twig */
class __TwigTemplate_4c4785019664baaac7e821cf21cd2aae3d6fb551fb0bd5219a099f9d6b4ff174 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f255c7c35bd10053a21489e8fe514b298eca8afacd29c5da94b6f4c26c938531 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f255c7c35bd10053a21489e8fe514b298eca8afacd29c5da94b6f4c26c938531->enter($__internal_f255c7c35bd10053a21489e8fe514b298eca8afacd29c5da94b6f4c26c938531_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "educations/new.html.twig"));

        // line 1
        echo "<div class=\"row\">
    <div class=\"tg-alertmessages\">
        <div class=\"alert alert-success tg-alertmessage fade in\" hidden id=\"successEducation\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-check\"></i>
            <span><strong>success Message.</strong> Ajouté avec success.</span>
        </div>
        <div class=\"alert alert-warning tg-alertmessage fade in\" hidden id=\"warningEducation\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-exclamation-triangle\"></i>
            <span><strong>warning Message.</strong> Existe déjà.</span>
        </div>
        <div class=\"alert alert-danger tg-alertmessage fade in\" hidden id=\"erreurEducation\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-bug\"></i>
            <span><strong>Error Message.</strong> Erreur en ajout.</span>
        </div>
    </div>
</div>
<br><br>
<div class=\"row tg-rowmargin\">
    <form action=\"\" id=\"formEducation\">
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "typeOfSchool", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Type d'ecole (exp : Medical school)")));
        echo "
            </div>
        </div>
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                ";
        // line 30
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "school", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "L'ecole")));
        echo "
                ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "
                <input type=\"hidden\" id=\"doctorsbundle_educations_doctor\" name=\"doctorsbundle_educations[doctor]\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()), "html", null, true);
        echo "\" >
            </div>
        </div>
        <div class=\"col-md-2 col-sm-3 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <button class=\"tg-btn tg-btn-lg\" type=\"submit\">";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("add now"), "html", null, true);
        echo "</button>
            </div>
        </div>
    </form>
</div>
";
        
        $__internal_f255c7c35bd10053a21489e8fe514b298eca8afacd29c5da94b6f4c26c938531->leave($__internal_f255c7c35bd10053a21489e8fe514b298eca8afacd29c5da94b6f4c26c938531_prof);

    }

    public function getTemplateName()
    {
        return "educations/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 37,  64 => 32,  60 => 31,  56 => 30,  48 => 25,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"row\">
    <div class=\"tg-alertmessages\">
        <div class=\"alert alert-success tg-alertmessage fade in\" hidden id=\"successEducation\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-check\"></i>
            <span><strong>success Message.</strong> Ajouté avec success.</span>
        </div>
        <div class=\"alert alert-warning tg-alertmessage fade in\" hidden id=\"warningEducation\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-exclamation-triangle\"></i>
            <span><strong>warning Message.</strong> Existe déjà.</span>
        </div>
        <div class=\"alert alert-danger tg-alertmessage fade in\" hidden id=\"erreurEducation\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
            <i class=\"fa fa-bug\"></i>
            <span><strong>Error Message.</strong> Erreur en ajout.</span>
        </div>
    </div>
</div>
<br><br>
<div class=\"row tg-rowmargin\">
    <form action=\"\" id=\"formEducation\">
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                {{ form_widget(form.typeOfSchool, {'attr':{'class':'form-control', 'placeholder':'Type d\\'ecole (exp : Medical school)'}}) }}
            </div>
        </div>
        <div class=\"col-sm-5 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                {{ form_widget(form.school, {'attr':{'class':'form-control', 'placeholder':'L\\'ecole'}}) }}
                {{ form_widget(form._token) }}
                <input type=\"hidden\" id=\"doctorsbundle_educations_doctor\" name=\"doctorsbundle_educations[doctor]\" value=\"{{ app.user.idTable }}\" >
            </div>
        </div>
        <div class=\"col-md-2 col-sm-3 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <button class=\"tg-btn tg-btn-lg\" type=\"submit\">{{ 'add now'|trans }}</button>
            </div>
        </div>
    </form>
</div>
", "educations/new.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\educations\\new.html.twig");
    }
}

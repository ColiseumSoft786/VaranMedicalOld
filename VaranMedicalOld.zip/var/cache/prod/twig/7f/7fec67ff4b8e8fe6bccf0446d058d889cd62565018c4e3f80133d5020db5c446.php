<?php

/* seances/listOfSeancesOfAppointements.html.twig */
class __TwigTemplate_4c8c5508ef1cff7141cb4bf47e26dca8ab33d132be237738e321e472c442375d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "seances/listOfSeancesOfAppointements.html.twig"));

        // line 1
        echo "<div class=\"tg-timeslots\" style=\"width: 100%\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["seances"] ?? $this->getContext($context, "seances")));
        foreach ($context['_seq'] as $context["_key"] => $context["seance"]) {
            // line 3
            echo "        ";
            if (($this->getAttribute($context["seance"], "absence", array()) == 0)) {
                // line 4
                echo "                <span class=\"tg-radio\">
                        <a href=\"";
                // line 5
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_index", array("id" => $this->getAttribute($context["seance"], "id", array()))), "html", null, true);
                echo "\" class=\"btn btn-info ";
                if (($this->getAttribute($context["seance"], "dispo", array()) == 0)) {
                    echo " disabled ";
                }
                echo "\" ";
                if (($this->getAttribute($context["seance"], "dispo", array()) == 0)) {
                    echo " style=\"background-color: #aeaeae\" ";
                }
                echo ">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["seance"], "heurDebut", array()), "H:i"), "html", null, true);
                echo "</a>
                </span>
        ";
            }
            // line 8
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['seance'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "seances/listOfSeancesOfAppointements.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 9,  51 => 8,  35 => 5,  32 => 4,  29 => 3,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"tg-timeslots\" style=\"width: 100%\">
    {% for seance in seances %}
        {% if seance.absence == 0 %}
                <span class=\"tg-radio\">
                        <a href=\"{{ path('appointments_index', {'id':seance.id}) }}\" class=\"btn btn-info {% if seance.dispo == 0 %} disabled {% endif %}\" {% if seance.dispo == 0 %} style=\"background-color: #aeaeae\" {% endif %}>{{ seance.heurDebut|date(\"H:i\") }}</a>
                </span>
        {% endif %}
    {% endfor %}
</div>
", "seances/listOfSeancesOfAppointements.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\seances\\listOfSeancesOfAppointements.html.twig");
    }
}

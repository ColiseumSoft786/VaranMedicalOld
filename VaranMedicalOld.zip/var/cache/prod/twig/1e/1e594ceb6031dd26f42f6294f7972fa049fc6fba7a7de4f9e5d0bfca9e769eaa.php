<?php

/* profilPatientNav.html.twig */
class __TwigTemplate_62a3497ed156075c896db6b47f8ec2e60b9228797096c774bfdc2d1eec2e7644 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "profilPatientNav.html.twig"));

        // line 1
        echo "<nav id=\"tg-dashboardnav\" class=\"tg-dashboardnav\">
    <ul>
        <li> <a href=\"";
        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_appointmentsByUser", array("success" => "no"));
        echo "\"> <i class=\"fa fa-calendar-check-o\"></i> <span>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("My Appointements"), "html", null, true);
        echo "</span> </a> </li>
        <li> <a href=\"";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctor_managment_display");
        echo "\"> <i class=\"fa fa-user\"></i> <span>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Doctor Management"), "html", null, true);
        echo "</span> </a> </li>
        <li> <a href=\"#\"> <i class=\"fa fa-user\"></i> <span>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile Settings"), "html", null, true);
        echo "</span> </a> </li>
    </ul>
</nav>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "profilPatientNav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 5,  32 => 4,  26 => 3,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav id=\"tg-dashboardnav\" class=\"tg-dashboardnav\">
    <ul>
        <li> <a href=\"{{ path('appointments_appointmentsByUser', {'success':'no'}) }}\"> <i class=\"fa fa-calendar-check-o\"></i> <span>{{ 'My Appointements'|trans }}</span> </a> </li>
        <li> <a href=\"{{ path('doctor_managment_display') }}\"> <i class=\"fa fa-user\"></i> <span>{{ 'Doctor Management'|trans }}</span> </a> </li>
        <li> <a href=\"#\"> <i class=\"fa fa-user\"></i> <span>{{ 'Profile Settings'|trans }}</span> </a> </li>
    </ul>
</nav>

", "profilPatientNav.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\profilPatientNav.html.twig");
    }
}

<?php

/* user/login.html.twig */
class __TwigTemplate_8982a1ca2132bce3ea7994b33bc9fcccf5ff6405f426428d8829101499c667e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7779d08bed6fc40fe757978f7ce13f74d1b69909dd01d56870a8b6e43a7fc63e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7779d08bed6fc40fe757978f7ce13f74d1b69909dd01d56870a8b6e43a7fc63e->enter($__internal_7779d08bed6fc40fe757978f7ce13f74d1b69909dd01d56870a8b6e43a7fc63e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        // line 1
        echo "<form  method=\"post\" action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" class=\"tg-formtheme tg-formsigninsignup\" autocomplete=\"off\">
<fieldset>
    ";
        // line 3
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 4
            echo "        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
    ";
        }
        // line 6
        echo "    <div class=\"row tg-rowmargin\">
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" class=\"form-control\" placeholder=\"Nom d\\'utilisateur\"/>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"  placeholder=\"Mot de passe\"/>
            </div>
        </div>
        <div class=\"tg-kepploginpassword\">
            <div class=\"tg-checkbox\">
                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                <label for=\"keeplogin\">Garder ma session active</label>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <button type=\"submit\" class=\"tg-btn pull-right\" id=\"_submit\" name=\"_submit\">Se connecter</button>
        </div>
    </div>
</fieldset>
</form>
";
        
        $__internal_7779d08bed6fc40fe757978f7ce13f74d1b69909dd01d56870a8b6e43a7fc63e->leave($__internal_7779d08bed6fc40fe757978f7ce13f74d1b69909dd01d56870a8b6e43a7fc63e_prof);

    }

    public function getTemplateName()
    {
        return "user/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 9,  36 => 6,  30 => 4,  28 => 3,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<form  method=\"post\" action=\"{{ path(\"fos_user_security_check\") }}\" class=\"tg-formtheme tg-formsigninsignup\" autocomplete=\"off\">
<fieldset>
    {% if csrf_token %}
        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
    {% endif %}
    <div class=\"row tg-rowmargin\">
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" class=\"form-control\" placeholder=\"Nom d\\'utilisateur\"/>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <div class=\"form-group tg-formgroup\">
                <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"  placeholder=\"Mot de passe\"/>
            </div>
        </div>
        <div class=\"tg-kepploginpassword\">
            <div class=\"tg-checkbox\">
                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                <label for=\"keeplogin\">Garder ma session active</label>
            </div>
        </div>
        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
            <button type=\"submit\" class=\"tg-btn pull-right\" id=\"_submit\" name=\"_submit\">Se connecter</button>
        </div>
    </div>
</fieldset>
</form>
", "user/login.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\login.html.twig");
    }
}

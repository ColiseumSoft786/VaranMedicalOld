<?php

/* doctors/profilEditEducations.html.twig */
class __TwigTemplate_342efbd855f84cacd434172550af336f00728d891576dc92ed89d65cf3c19eb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f9fc654edbadba05ac84917f436a7af80ce22a3e149b460d4c7b9424805452f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f9fc654edbadba05ac84917f436a7af80ce22a3e149b460d4c7b9424805452f->enter($__internal_2f9fc654edbadba05ac84917f436a7af80ce22a3e149b460d4c7b9424805452f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "doctors/profilEditEducations.html.twig"));

        // line 1
        echo "<ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["educations"] ?? $this->getContext($context, "educations")));
        foreach ($context['_seq'] as $context["_key"] => $context["education"]) {
            // line 3
            echo "    <li> <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["education"], "typeOfSchool", array()), "html", null, true);
            echo " <button class=\"editEducation\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["education"], "id", array()), "html", null, true);
            echo "\" style=\"background-color: transparent\"><i class=\"fa fa-pencil\"></i></button>  <button class=\"deleteEducation\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["education"], "id", array()), "html", null, true);
            echo "\" style=\"background-color: transparent\"><i class=\"fa fa-close\"></i></button> </span>  <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["education"], "school", array()), "html", null, true);
            echo "</span> <span></span> </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['education'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ul>

<script>
    \$(document).ready(function () {
        \$(\".editEducation\").click(function () {

            var URL = \"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("educations_edit", array("id" => "sss"));
        echo "\";
            var idEducation = \$(this).attr('value');
            URL = URL.replace(/sss/g, idEducation);
            console.log('URL = '+URL);
            \$.ajax({
                type: \"POST\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#editEducation').html(response);
                    \$('#newEducation').hide();
                    \$('#educationsList').hide();
                }
            });
            return true;
        });

        \$(\".deleteEducation\").click(function () {
            if (!confirm('Vous voulez supprime cet enregistrement')) return false;
            var URL = \"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("educations_delete", array("education" => "sss"));
        echo "\";
            var idEducation = \$(this).attr('value');
            console.log(idEducation)
            URL = URL.replace(/sss/g, idEducation);
            console.log('URL = '+URL);
            \$.ajax({
                type: \"POST\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#educationsList').html(response);
                    \$('#successEducation').hide();
                }
            });
            return true;
        });
    });
</script>";
        
        $__internal_2f9fc654edbadba05ac84917f436a7af80ce22a3e149b460d4c7b9424805452f->leave($__internal_2f9fc654edbadba05ac84917f436a7af80ce22a3e149b460d4c7b9424805452f_prof);

    }

    public function getTemplateName()
    {
        return "doctors/profilEditEducations.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 30,  52 => 11,  44 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
    {% for education in educations %}
    <li> <span>{{ education.typeOfSchool }} <button class=\"editEducation\" value=\"{{ education.id }}\" style=\"background-color: transparent\"><i class=\"fa fa-pencil\"></i></button>  <button class=\"deleteEducation\" value=\"{{ education.id }}\" style=\"background-color: transparent\"><i class=\"fa fa-close\"></i></button> </span>  <span>{{ education.school }}</span> <span></span> </li>
    {% endfor %}
</ul>

<script>
    \$(document).ready(function () {
        \$(\".editEducation\").click(function () {

            var URL = \"{{ path('educations_edit',{ 'id': 'sss' }) }}\";
            var idEducation = \$(this).attr('value');
            URL = URL.replace(/sss/g, idEducation);
            console.log('URL = '+URL);
            \$.ajax({
                type: \"POST\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#editEducation').html(response);
                    \$('#newEducation').hide();
                    \$('#educationsList').hide();
                }
            });
            return true;
        });

        \$(\".deleteEducation\").click(function () {
            if (!confirm('Vous voulez supprime cet enregistrement')) return false;
            var URL = \"{{ path('educations_delete',{ 'education': 'sss' }) }}\";
            var idEducation = \$(this).attr('value');
            console.log(idEducation)
            URL = URL.replace(/sss/g, idEducation);
            console.log('URL = '+URL);
            \$.ajax({
                type: \"POST\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#educationsList').html(response);
                    \$('#successEducation').hide();
                }
            });
            return true;
        });
    });
</script>", "doctors/profilEditEducations.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\doctors\\profilEditEducations.html.twig");
    }
}

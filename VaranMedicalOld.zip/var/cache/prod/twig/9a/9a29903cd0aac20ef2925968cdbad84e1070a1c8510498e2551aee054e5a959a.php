<?php

/* invoices/new.html.twig */
class __TwigTemplate_63d4bddfcac9ddb6789f098f98def4b80f49fcb52d33b538dde5ca03d8372a71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf7feece4f14c1b9b03f9ff0a2e56d0124e55fdfacd120f1006e17a223f7f68d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf7feece4f14c1b9b03f9ff0a2e56d0124e55fdfacd120f1006e17a223f7f68d->enter($__internal_cf7feece4f14c1b9b03f9ff0a2e56d0124e55fdfacd120f1006e17a223f7f68d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "invoices/new.html.twig"));

        // line 1
        echo "<form class=\"tg-formbookappointment\" id=\"formAddServices\">
    <fieldset class=\"tg-formstepone tg-current\">
        <div class=\"row tg-rowmargin\">
            <div class=\"tg-alertmessages\" id=\"successMessage\">
                <div class=\"alert alert-success tg-alertmessage fade in\" id=\"addSuccess\" hidden>
                    <i class=\"fa fa-check\"></i>
                    <span><strong>";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("success Message"), "html", null, true);
        echo ".</strong> Adipisicing elit, sed do eiusmod.</span>
                </div>
                <div class=\"alert alert-danger tg-alertmessage fade in\" id=\"addErreur\" hidden>
                    <i class=\"fa fa-bug\"></i>
                    <span><strong>";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Error Message"), "html", null, true);
        echo ".</strong> Adipisicing elit, sed do eiusmod.</span>
                </div>
                <div class=\"alert alert-warning tg-alertmessage fade in\" id=\"addExist\" hidden>
                    <i class=\"fa fa-exclamation-triangle\"></i>
                    <span><strong>";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("warning Message"), "html", null, true);
        echo ".</strong> ce service est deja plannifier .</span>
                </div>
            </div>
            <br><br>
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                ";
        // line 20
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Specialities:getComboSpecialitiesByDoctor", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))));
        echo "
            </div>
            
            
            
            
            
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                <div id=\"comboServices\">

                </div>
            </div>
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                <div id=\"comboSubServices\">

                </div>
            </div>
            
            
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                <div class=\"form-group\">
                    ";
        // line 41
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "price", array()), 'widget', array("attr" => array("class" => "form-control js-datepicker", "placeholder" => "Prix")));
        echo "
                    <input type=\"hidden\" id=\"doctorsbundle_invoices_doctor\" name=\"doctorsbundle_invoices[doctor]\" value=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()), "html", null, true);
        echo "\">
                    ";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "
                </div>
            </div>
        </div>
        <div class=\"tg-btnbox\">
            <button type=\"submit\" class=\"tg-btn\">";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("add now"), "html", null, true);
        echo "</button>
        </div>
    </fieldset>
</form>

<script>
    \$('body').on('submit', '#formAddServices', function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();

        var \$form = \$(this);
        var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
        var data = (formdata !== null) ? formdata : \$form.serialize();

        var URL = \"";
        // line 62
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("invoices_new");
        echo "\";
        console.log(URL);

        \$.ajax({
            url: URL,
            type: \"POST\",
            contentType: false,
            processData: false,
            dataType: 'html',
            data: data,
            success: function (response) {
                if(response == 'Success') {
                    \$('#addExist').hide();
                    \$('#addErreur').hide();
                    \$('#addSuccess').show();
                }else if (response == 'deja'){
                    \$('#addErreur').hide();
                    \$('#addSuccess').hide();
                    \$('#addExist').show();
                }else {
                    \$('#addSuccess').hide();
                    \$('#addExist').hide();
                    \$('#addErreur').show();
                }
            }
        });


        return false
    });
    \$(document).ready(function () {
        \$(\"#comboSpecialitie\").change(function () {
            var specialitie = \$('#comboSpecialitie').val();

            var URL = \"";
        // line 96
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("services_comboServicesBySpecialitie", array("specialitie" => "ddd"));
        echo "\";
            URL = URL.replace(/ddd/g, specialitie);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$(\"#comboServices\").html(response);
                    return true;
                }
            });
        });

        \$(\".comboServices\").change(function () {
            var service = \$('.comboServices').val();
            console.log(service);
            var URL = \"";
        // line 112
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("subservices_comboSubServicesByService", array("service" => "ddd"));
        echo "\";
            URL = URL.replace(/ddd/g, service);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$(\"#comboSubServices\").html(response);
                    return true;
                }
            });
        });
    });
</script>
";
        
        $__internal_cf7feece4f14c1b9b03f9ff0a2e56d0124e55fdfacd120f1006e17a223f7f68d->leave($__internal_cf7feece4f14c1b9b03f9ff0a2e56d0124e55fdfacd120f1006e17a223f7f68d_prof);

    }

    public function getTemplateName()
    {
        return "invoices/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 112,  146 => 96,  109 => 62,  92 => 48,  84 => 43,  80 => 42,  76 => 41,  52 => 20,  44 => 15,  37 => 11,  30 => 7,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<form class=\"tg-formbookappointment\" id=\"formAddServices\">
    <fieldset class=\"tg-formstepone tg-current\">
        <div class=\"row tg-rowmargin\">
            <div class=\"tg-alertmessages\" id=\"successMessage\">
                <div class=\"alert alert-success tg-alertmessage fade in\" id=\"addSuccess\" hidden>
                    <i class=\"fa fa-check\"></i>
                    <span><strong>{{ 'success Message'|trans }}.</strong> Adipisicing elit, sed do eiusmod.</span>
                </div>
                <div class=\"alert alert-danger tg-alertmessage fade in\" id=\"addErreur\" hidden>
                    <i class=\"fa fa-bug\"></i>
                    <span><strong>{{ 'Error Message'|trans }}.</strong> Adipisicing elit, sed do eiusmod.</span>
                </div>
                <div class=\"alert alert-warning tg-alertmessage fade in\" id=\"addExist\" hidden>
                    <i class=\"fa fa-exclamation-triangle\"></i>
                    <span><strong>{{ 'warning Message'|trans }}.</strong> ce service est deja plannifier .</span>
                </div>
            </div>
            <br><br>
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                {{ render(controller('DoctorsBundle:Specialities:getComboSpecialitiesByDoctor', {'doctor':app.user.idTable})) }}
            </div>
            
            
            
            
            
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                <div id=\"comboServices\">

                </div>
            </div>
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                <div id=\"comboSubServices\">

                </div>
            </div>
            
            
            <div class=\"col-lg-12 col-sm-12 col-xs-12 tg-columnpadding\">
                <div class=\"form-group\">
                    {{ form_widget(form.price, {'attr':{'class':'form-control js-datepicker', 'placeholder':'Prix'}}) }}
                    <input type=\"hidden\" id=\"doctorsbundle_invoices_doctor\" name=\"doctorsbundle_invoices[doctor]\" value=\"{{ app.user.idTable }}\">
                    {{ form_widget(form._token) }}
                </div>
            </div>
        </div>
        <div class=\"tg-btnbox\">
            <button type=\"submit\" class=\"tg-btn\">{{ 'add now'|trans }}</button>
        </div>
    </fieldset>
</form>

<script>
    \$('body').on('submit', '#formAddServices', function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();

        var \$form = \$(this);
        var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
        var data = (formdata !== null) ? formdata : \$form.serialize();

        var URL = \"{{ path('invoices_new')}}\";
        console.log(URL);

        \$.ajax({
            url: URL,
            type: \"POST\",
            contentType: false,
            processData: false,
            dataType: 'html',
            data: data,
            success: function (response) {
                if(response == 'Success') {
                    \$('#addExist').hide();
                    \$('#addErreur').hide();
                    \$('#addSuccess').show();
                }else if (response == 'deja'){
                    \$('#addErreur').hide();
                    \$('#addSuccess').hide();
                    \$('#addExist').show();
                }else {
                    \$('#addSuccess').hide();
                    \$('#addExist').hide();
                    \$('#addErreur').show();
                }
            }
        });


        return false
    });
    \$(document).ready(function () {
        \$(\"#comboSpecialitie\").change(function () {
            var specialitie = \$('#comboSpecialitie').val();

            var URL = \"{{ path('services_comboServicesBySpecialitie', {'specialitie': 'ddd'}) }}\";
            URL = URL.replace(/ddd/g, specialitie);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$(\"#comboServices\").html(response);
                    return true;
                }
            });
        });

        \$(\".comboServices\").change(function () {
            var service = \$('.comboServices').val();
            console.log(service);
            var URL = \"{{ path('subservices_comboSubServicesByService', {'service': 'ddd'}) }}\";
            URL = URL.replace(/ddd/g, service);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$(\"#comboSubServices\").html(response);
                    return true;
                }
            });
        });
    });
</script>
", "invoices/new.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\invoices\\new.html.twig");
    }
}

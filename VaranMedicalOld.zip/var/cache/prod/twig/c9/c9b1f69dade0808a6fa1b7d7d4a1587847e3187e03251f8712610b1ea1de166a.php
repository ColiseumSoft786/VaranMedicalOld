<?php

/* user/profilupdate.html.twig */
class __TwigTemplate_ede3f6745357b25ba1f5bf2b3b0715f85f5aa941a0969057587a17e7f9299ee8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a2759abc867b0bab81d60814f5bcb6af9378911e5bb75c0783e6ab8f1b72623 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a2759abc867b0bab81d60814f5bcb6af9378911e5bb75c0783e6ab8f1b72623->enter($__internal_4a2759abc867b0bab81d60814f5bcb6af9378911e5bb75c0783e6ab8f1b72623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profilupdate.html.twig"));

        // line 1
        $this->loadTemplate("base.html.twig", "user/profilupdate.html.twig", 1)->display($context);
        // line 2
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_4a2759abc867b0bab81d60814f5bcb6af9378911e5bb75c0783e6ab8f1b72623->leave($__internal_4a2759abc867b0bab81d60814f5bcb6af9378911e5bb75c0783e6ab8f1b72623_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_a1666403b3727c1c85c48f7facfadb1dcb75ad34e9326e2647f02ec22a2d2c8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1666403b3727c1c85c48f7facfadb1dcb75ad34e9326e2647f02ec22a2d2c8f->enter($__internal_a1666403b3727c1c85c48f7facfadb1dcb75ad34e9326e2647f02ec22a2d2c8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
    <!--************************************
            Preloader Start
    *************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
    <!--************************************
            Preloader End
    *************************************-->

    <!--************************************
            Wrapper Start
    *************************************-->
    <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

        <!--************************************
                Main Start
        *************************************-->
        <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
            <div class=\"container\">
                <div class=\"row\">
                    <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                        <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                            <div class=\"tg-widgetdashboard\">
                                <div class=\"tg-widgetprofile\">
                                    <figure class=\"tg-directpostimg\"> 
                                        ";
        // line 35
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 36
            echo "                                            <a href=\"#\">
                                                <img src=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                            </a>
                                        ";
        } else {
            // line 40
            echo "                                            <a href=\"#\">
                                                <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                            </a>
                                        ";
        }
        // line 44
        echo "                                        ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 45
            echo "                                            <figcaption>
                                                <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                    <em class=\"tg-usericonholder\">
                                                        <i class=\"fa fa-shield\"></i>
                                                        <span>";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                    </em>
                                                </a>
                                            </figcaption>
                                        ";
        }
        // line 54
        echo "                                    </figure>
                                    <div class=\"tg-directposthead\">
                                        <h3><a href=\"#\">Dr. ";
        // line 56
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                        <div class=\"tg-subjects\"></div>
                                        <ul class=\"tg-metadata\">
                                            <li><span class=\"tg-stars\"><span></span></span></li>
                                            <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                        </ul>
                                    </div>
                                    <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                <nav id=\"tg-dashboardnav\" class=\"tg-dashboardnav\">
                                    <ul>
                                        <li> <a href=\"";
        // line 66
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("locations_index");
        echo "\"> <i class=\"fa fa-location-arrow\"></i> <span>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Job Locations"), "html", null, true);
        echo "</span> </a> </li>
                                        <li> <a href=\"#\"> <i class=\"fa fa-user\"></i> <span>";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile Settings"), "html", null, true);
        echo "</span> </a> </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                            <div class=\"tg-dashboardtabs\">
                                <ul class=\"tg-dashboardtabnav\" role=\"tablist\">
                                    <li role=\"presentation\" class=\"active\"> <a href=\"#overview\" aria-controls=\"overview\" role=\"tab\" data-toggle=\"tab\">";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Overview"), "html", null, true);
        echo "</a> </li>
                                    <li role=\"presentation\"> <a href=\"#services\" aria-controls=\"services\" role=\"tab\" data-toggle=\"tab\">";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Services"), "html", null, true);
        echo "</a> </li>
                                    <li role=\"presentation\"> <a href=\"#addphotos\" aria-controls=\"addphotos\" role=\"tab\" data-toggle=\"tab\" id=\"azer\">";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Photos"), "html", null, true);
        echo "(en construction)</a> </li>
                                </ul>
                                <div class=\"tab-content tg-dashboardtabcontent\">
                                    <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                        <div class=\"tg-searchbulder tg-searchprofilesttings\">
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>";
        // line 84
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Basic Information"), "html", null, true);
        echo "</h2>
                                                </div>
                                                <div class=\"tg-box tg-basicinformation\">
                                                    <div class=\"row tg-rowmargin\" id=\"basicInfo\">
                                                        ";
        // line 88
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:profilEditBasicInformation", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                                    </div>
                                                    <div id=\"formBasicInfo\">

                                                    </div>
                                                    <button class=\"btn btn-default pull-right\" id=\"editBasicInfo\"><i class=\"fa fa-edit\"></i></button>
                                                </div>

                                            </div>
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Specializations"), "html", null, true);
        echo "</h2>
                                                </div>
                                                <div class=\"tg-box tg-education tg-uiicons\">
                                                    ";
        // line 102
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Specialities:getComboSpecialities"));
        echo "
                                                    <div id=\"specialitiesList\">
                                                        ";
        // line 104
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:profilEditSpecialities", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>";
        // line 110
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Educations"), "html", null, true);
        echo "</h2>
                                                </div>
                                                <div class=\"tg-box tg-education tg-uiicons\">
                                                    <div class=\"row tg-rowmargin\" id=\"newEducation\">
                                                        ";
        // line 114
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Educations:new"));
        echo "
                                                    </div>
                                                    <div class=\"row tg-rowmargin\" id=\"editEducation\">

                                                    </div>
                                                    <div id=\"educationsList\">
                                                        ";
        // line 120
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:profilEditEducations", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>";
        // line 126
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Certifications"), "html", null, true);
        echo "</h2>
                                                </div>
                                                <div class=\"tg-box tg-education tg-uiicons\">
                                                    <div class=\"row tg-rowmargin\" id=\"newCertification\">
                                                        ";
        // line 130
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Certifications:new"));
        echo "
                                                    </div>
                                                    <div class=\"row tg-rowmargin\" id=\"editCertification\">

                                                    </div>
                                                    <div id=\"certificationList\">
                                                        ";
        // line 136
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:profilEditCertification", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>  
                                    <div role=\"tabpanel\" class=\"tab-pane\" id=\"services\">
                                        <div class=\"tg-dashboardbox tg-profilesettings\">
                                            ";
        // line 144
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Services:index", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                        </div>
                                        <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click <strong>invoices settings</strong> to update latest added detail (s).</span>
                                        </div>
                                    </div>                
                                    <div role=\"tabpanel\" class=\"tab-pane\" id=\"addphotos\">
                                        <div class=\"tg-dashboardbox\">
                                            <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                                                ";
        // line 152
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:profileEditImage", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <script>
            \$(document).ready(function() {
                // configure the bootstrap datepicker
                \$('.js-datepicker').datepicker({
                    format: 'dd-mm-yyyy'
                });
            });
        </script>
        <script>

            \$(document).ready(function () {
                \$('#upload').change(function() {
                    var filename = \$(this).val();
                    var lastIndex = filename.lastIndexOf(\"\\\\\");
                    if (lastIndex >= 0) {
                        filename = filename.substring(lastIndex + 1);
                    }
                    \$('#filename').val(filename);
                });

                \$(\"#AddSpecialities\").click(function () {
                    var specialitie = \$('#specialitie').val();
                    var DATA = 'specialitie='+ specialitie;
                    var URL = \"";
        // line 189
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_addSpecialitie");
        echo "\";
                    console.log(URL);
                    console.log(DATA);
                    \$.ajax({
                        type: \"POST\",
                        url: URL,
                        data: DATA,
                        cache: false,
                        success: function (response) {
                            console.log('done');
                            if (response == 'warning'){
                                \$('#warning').show()
                            }else {
                                \$('#success').show();
                                \$('#specialitiesList').html(response);
                            }
                            return true;

                        }
                    });
                });
                \$(\"#editBasicInfo\").click(function () {
                    var URL = \"";
        // line 211
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_edit", array("id" => "myID"));
        echo "\";
                    var idDoctor = '";
        // line 212
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()), "html", null, true);
        echo "'
                    URL = URL.replace(/myID/g, idDoctor);
                    \$.ajax({
                        type: \"POST\",
                        url: URL,
                        cache: false,
                        success: function (response) {
                            \$('#basicInfo').hide();
                            \$('#editBasicInfo').hide();
                            \$('#formBasicInfo').html(response);
                            return true;
                        }
                    });
                });
                
                \$('body').on('submit', '#formEducation', function (e) {
                    // On empêche le navigateur de soumettre le formulaire
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var \$form = \$(this);
                    var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
                    var data = (formdata !== null) ? formdata : \$form.serialize();

                    var URL = \"";
        // line 236
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("educations_addEducation", array("idOwner" => "myID"));
        echo "\";
                    var idDoctor = '";
        // line 237
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()), "html", null, true);
        echo "'
                    URL = URL.replace(/myID/g, idDoctor);

                    console.log('Click sur valider add consommation avec url = '+URL);

                    \$.ajax({
                        url: URL,
                        type: \"POST\",
                        contentType: false, // obligatoire pour de l'upload
                        processData: false, // obligatoire pour de l'upload
                        dataType: 'html', // selon le retour attendu
                        data: data,
                        success: function (response) {
                            \$('#successEducation').show();
                            \$('#educationsList').html(response);
                            return true;
                        }
                    });
                    return false;
                });

                \$('body').on('submit', '#formCertification', function (e) {
                    // On empêche le navigateur de soumettre le formulaire
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var \$form = \$(this);
                    var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
                    var data = (formdata !== null) ? formdata : \$form.serialize();

                    var URL = \"";
        // line 267
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("certifications_addCertification", array("idOwner" => "myID"));
        echo "\";
                    var idDoctor = '";
        // line 268
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()), "html", null, true);
        echo "'
                    URL = URL.replace(/myID/g, idDoctor);

                    console.log('Click sur valider add consommation avec url = '+URL);

                    \$.ajax({
                        url: URL,
                        type: \"POST\",
                        contentType: false, // obligatoire pour de l'upload
                        processData: false, // obligatoire pour de l'upload
                        dataType: 'html', // selon le retour attendu
                        data: data,
                        success: function (response) {
                            \$('#successCertification').show();
                            \$('#certificationList').html(response);
                            return true;
                        }
                    });
                    return false;
                });
                
            \$('body').on('submit', '#formEditDoctorImage', function (e) {
                // On empêche le navigateur de soumettre le formulaire
                e.preventDefault();
                e.stopImmediatePropagation();

                var \$form = \$(this);
                var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
                var data = (formdata !== null) ? formdata : \$form.serialize();

                var URL = \"";
        // line 298
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_edit", array("id" => "myID"));
        echo "\";
                var idDoctor = '";
        // line 299
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()), "html", null, true);
        echo "'
                URL = URL.replace(/myID/g, idDoctor);


                \$.ajax({
                    url: URL,
                    type: \"POST\",
                    contentType: false, // obligatoire pour de l'upload
                    processData: false, // obligatoire pour de l'upload
                    dataType: 'html', // selon le retour attendu
                    data: data,
                    success: function (response) {
                        location.reload();
                        return true;
                    }
                });
                return false;
            });
            });
        </script>


    </div>
    <!--************************************
            Wrapper End
    *************************************-->
    ";
        // line 325
        $this->loadTemplate("default/footer.html.twig", "user/profilupdate.html.twig", 325)->display($context);
        // line 326
        echo "
";
        
        $__internal_a1666403b3727c1c85c48f7facfadb1dcb75ad34e9326e2647f02ec22a2d2c8f->leave($__internal_a1666403b3727c1c85c48f7facfadb1dcb75ad34e9326e2647f02ec22a2d2c8f_prof);

    }

    public function getTemplateName()
    {
        return "user/profilupdate.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  481 => 326,  479 => 325,  450 => 299,  446 => 298,  413 => 268,  409 => 267,  376 => 237,  372 => 236,  345 => 212,  341 => 211,  316 => 189,  276 => 152,  265 => 144,  254 => 136,  245 => 130,  238 => 126,  229 => 120,  220 => 114,  213 => 110,  204 => 104,  199 => 102,  193 => 99,  179 => 88,  172 => 84,  162 => 77,  158 => 76,  154 => 75,  143 => 67,  137 => 66,  129 => 63,  117 => 56,  113 => 54,  105 => 49,  99 => 45,  96 => 44,  90 => 41,  87 => 40,  79 => 37,  76 => 36,  74 => 35,  58 => 22,  37 => 3,  25 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include ('base.html.twig') %}
{% block body %}
    <body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
    <!--************************************
            Preloader Start
    *************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
    <!--************************************
            Preloader End
    *************************************-->

    <!--************************************
            Wrapper Start
    *************************************-->
    <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
        {{ render(controller('AppBundle:Default:header')) }}

        <!--************************************
                Main Start
        *************************************-->
        <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
            <div class=\"container\">
                <div class=\"row\">
                    <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                        <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                            <div class=\"tg-widgetdashboard\">
                                <div class=\"tg-widgetprofile\">
                                    <figure class=\"tg-directpostimg\"> 
                                        {% if vich_uploader_asset(doctor, 'imageFile') %}
                                            <a href=\"#\">
                                                <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                            </a>
                                        {% else %}
                                            <a href=\"#\">
                                                <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                            </a>
                                        {% endif %}
                                        {% if app.user.verifier == 1 %}
                                            <figcaption>
                                                <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                    <em class=\"tg-usericonholder\">
                                                        <i class=\"fa fa-shield\"></i>
                                                        <span>{{ 'verified'|trans }}</span>
                                                    </em>
                                                </a>
                                            </figcaption>
                                        {% endif %}
                                    </figure>
                                    <div class=\"tg-directposthead\">
                                        <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                        <div class=\"tg-subjects\"></div>
                                        <ul class=\"tg-metadata\">
                                            <li><span class=\"tg-stars\"><span></span></span></li>
                                            <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                        </ul>
                                    </div>
                                    <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.id }) }}\">{{ 'Profile'|trans }}</a> </div>
                                <nav id=\"tg-dashboardnav\" class=\"tg-dashboardnav\">
                                    <ul>
                                        <li> <a href=\"{{ path('locations_index')}}\"> <i class=\"fa fa-location-arrow\"></i> <span>{{ 'Job Locations'|trans }}</span> </a> </li>
                                        <li> <a href=\"#\"> <i class=\"fa fa-user\"></i> <span>{{ 'Profile Settings'|trans }}</span> </a> </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                            <div class=\"tg-dashboardtabs\">
                                <ul class=\"tg-dashboardtabnav\" role=\"tablist\">
                                    <li role=\"presentation\" class=\"active\"> <a href=\"#overview\" aria-controls=\"overview\" role=\"tab\" data-toggle=\"tab\">{{ 'Overview'|trans }}</a> </li>
                                    <li role=\"presentation\"> <a href=\"#services\" aria-controls=\"services\" role=\"tab\" data-toggle=\"tab\">{{ 'Services'|trans }}</a> </li>
                                    <li role=\"presentation\"> <a href=\"#addphotos\" aria-controls=\"addphotos\" role=\"tab\" data-toggle=\"tab\" id=\"azer\">{{ 'Photos'|trans }}(en construction)</a> </li>
                                </ul>
                                <div class=\"tab-content tg-dashboardtabcontent\">
                                    <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                        <div class=\"tg-searchbulder tg-searchprofilesttings\">
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>{{ 'Basic Information'|trans }}</h2>
                                                </div>
                                                <div class=\"tg-box tg-basicinformation\">
                                                    <div class=\"row tg-rowmargin\" id=\"basicInfo\">
                                                        {{ render(controller('DoctorsBundle:Doctors:profilEditBasicInformation', {'doctor': doctor.id})) }}
                                                    </div>
                                                    <div id=\"formBasicInfo\">

                                                    </div>
                                                    <button class=\"btn btn-default pull-right\" id=\"editBasicInfo\"><i class=\"fa fa-edit\"></i></button>
                                                </div>

                                            </div>
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>{{ 'Specializations'|trans }}</h2>
                                                </div>
                                                <div class=\"tg-box tg-education tg-uiicons\">
                                                    {{ render(controller('DoctorsBundle:Specialities:getComboSpecialities')) }}
                                                    <div id=\"specialitiesList\">
                                                        {{ render(controller('DoctorsBundle:Doctors:profilEditSpecialities', {'doctor': doctor.id})) }}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>{{ 'Educations'|trans }}</h2>
                                                </div>
                                                <div class=\"tg-box tg-education tg-uiicons\">
                                                    <div class=\"row tg-rowmargin\" id=\"newEducation\">
                                                        {{ render(controller('DoctorsBundle:Educations:new')) }}
                                                    </div>
                                                    <div class=\"row tg-rowmargin\" id=\"editEducation\">

                                                    </div>
                                                    <div id=\"educationsList\">
                                                        {{ render(controller('DoctorsBundle:Doctors:profilEditEducations', {'doctor': doctor.id})) }}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2>{{ 'Certifications'|trans }}</h2>
                                                </div>
                                                <div class=\"tg-box tg-education tg-uiicons\">
                                                    <div class=\"row tg-rowmargin\" id=\"newCertification\">
                                                        {{ render(controller('DoctorsBundle:Certifications:new')) }}
                                                    </div>
                                                    <div class=\"row tg-rowmargin\" id=\"editCertification\">

                                                    </div>
                                                    <div id=\"certificationList\">
                                                        {{ render(controller('DoctorsBundle:Doctors:profilEditCertification', {'doctor': doctor.id})) }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>  
                                    <div role=\"tabpanel\" class=\"tab-pane\" id=\"services\">
                                        <div class=\"tg-dashboardbox tg-profilesettings\">
                                            {{ render(controller('DoctorsBundle:Services:index', {'doctor':doctor.id})) }}
                                        </div>
                                        <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click <strong>invoices settings</strong> to update latest added detail (s).</span>
                                        </div>
                                    </div>                
                                    <div role=\"tabpanel\" class=\"tab-pane\" id=\"addphotos\">
                                        <div class=\"tg-dashboardbox\">
                                            <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                                                {{ render(controller('DoctorsBundle:Doctors:profileEditImage', {'doctor': doctor.id})) }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <script>
            \$(document).ready(function() {
                // configure the bootstrap datepicker
                \$('.js-datepicker').datepicker({
                    format: 'dd-mm-yyyy'
                });
            });
        </script>
        <script>

            \$(document).ready(function () {
                \$('#upload').change(function() {
                    var filename = \$(this).val();
                    var lastIndex = filename.lastIndexOf(\"\\\\\");
                    if (lastIndex >= 0) {
                        filename = filename.substring(lastIndex + 1);
                    }
                    \$('#filename').val(filename);
                });

                \$(\"#AddSpecialities\").click(function () {
                    var specialitie = \$('#specialitie').val();
                    var DATA = 'specialitie='+ specialitie;
                    var URL = \"{{ path('doctors_addSpecialitie') }}\";
                    console.log(URL);
                    console.log(DATA);
                    \$.ajax({
                        type: \"POST\",
                        url: URL,
                        data: DATA,
                        cache: false,
                        success: function (response) {
                            console.log('done');
                            if (response == 'warning'){
                                \$('#warning').show()
                            }else {
                                \$('#success').show();
                                \$('#specialitiesList').html(response);
                            }
                            return true;

                        }
                    });
                });
                \$(\"#editBasicInfo\").click(function () {
                    var URL = \"{{ path('doctors_edit',{ 'id': 'myID' }) }}\";
                    var idDoctor = '{{ app.user.idTable }}'
                    URL = URL.replace(/myID/g, idDoctor);
                    \$.ajax({
                        type: \"POST\",
                        url: URL,
                        cache: false,
                        success: function (response) {
                            \$('#basicInfo').hide();
                            \$('#editBasicInfo').hide();
                            \$('#formBasicInfo').html(response);
                            return true;
                        }
                    });
                });
                
                \$('body').on('submit', '#formEducation', function (e) {
                    // On empêche le navigateur de soumettre le formulaire
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var \$form = \$(this);
                    var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
                    var data = (formdata !== null) ? formdata : \$form.serialize();

                    var URL = \"{{ path('educations_addEducation',{ 'idOwner': 'myID' }) }}\";
                    var idDoctor = '{{ app.user.idTable }}'
                    URL = URL.replace(/myID/g, idDoctor);

                    console.log('Click sur valider add consommation avec url = '+URL);

                    \$.ajax({
                        url: URL,
                        type: \"POST\",
                        contentType: false, // obligatoire pour de l'upload
                        processData: false, // obligatoire pour de l'upload
                        dataType: 'html', // selon le retour attendu
                        data: data,
                        success: function (response) {
                            \$('#successEducation').show();
                            \$('#educationsList').html(response);
                            return true;
                        }
                    });
                    return false;
                });

                \$('body').on('submit', '#formCertification', function (e) {
                    // On empêche le navigateur de soumettre le formulaire
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var \$form = \$(this);
                    var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
                    var data = (formdata !== null) ? formdata : \$form.serialize();

                    var URL = \"{{ path('certifications_addCertification',{ 'idOwner': 'myID' }) }}\";
                    var idDoctor = '{{ app.user.idTable }}'
                    URL = URL.replace(/myID/g, idDoctor);

                    console.log('Click sur valider add consommation avec url = '+URL);

                    \$.ajax({
                        url: URL,
                        type: \"POST\",
                        contentType: false, // obligatoire pour de l'upload
                        processData: false, // obligatoire pour de l'upload
                        dataType: 'html', // selon le retour attendu
                        data: data,
                        success: function (response) {
                            \$('#successCertification').show();
                            \$('#certificationList').html(response);
                            return true;
                        }
                    });
                    return false;
                });
                
            \$('body').on('submit', '#formEditDoctorImage', function (e) {
                // On empêche le navigateur de soumettre le formulaire
                e.preventDefault();
                e.stopImmediatePropagation();

                var \$form = \$(this);
                var formdata = (window.FormData) ? new FormData(\$form[0]) : null;
                var data = (formdata !== null) ? formdata : \$form.serialize();

                var URL = \"{{ path('doctors_edit',{ 'id': 'myID' }) }}\";
                var idDoctor = '{{ app.user.idTable }}'
                URL = URL.replace(/myID/g, idDoctor);


                \$.ajax({
                    url: URL,
                    type: \"POST\",
                    contentType: false, // obligatoire pour de l'upload
                    processData: false, // obligatoire pour de l'upload
                    dataType: 'html', // selon le retour attendu
                    data: data,
                    success: function (response) {
                        location.reload();
                        return true;
                    }
                });
                return false;
            });
            });
        </script>


    </div>
    <!--************************************
            Wrapper End
    *************************************-->
    {% include ('default/footer.html.twig') %}

{% endblock %}", "user/profilupdate.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\profilupdate.html.twig");
    }
}

<?php

/* seances/listeSeancesCalendar.html.twig */
class __TwigTemplate_7171d7da4faa98ec2ce28d4b885372aa95fa931de05b06856751df65aad81442 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "seances/listeSeancesCalendar.html.twig"));

        // line 1
        if ((null === $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "deleatedAt", array()))) {
            // line 2
            echo "    ";
            if ((($this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "absence", array()) == 1) && (twig_date_format_filter($this->env, "now", "Y-m-d") <= twig_date_format_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "date", array()), "Y-m-d")))) {
                // line 3
                echo "        {
        \"id\": ";
                // line 4
                echo twig_escape_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "id", array()), "html", null, true);
                echo ",
        \"name\": \"Absent\",
        \"startdate\": \"";
                // line 6
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "date", array()), "Y-m-d"), "html", null, true);
                echo "\",
        \"enddate\": \"\",
        \"color\": \"#787683\",
        \"url\": \"";
                // line 9
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("seances_index", array("calendrie" => $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "id", array()))), "html", null, true);
                echo "\"
        },
    ";
            } else {
                // line 12
                echo "        ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["seances"] ?? $this->getContext($context, "seances")));
                foreach ($context['_seq'] as $context["_key"] => $context["seance"]) {
                    // line 13
                    echo "            {
            \"id\": ";
                    // line 14
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "id", array()), "html", null, true);
                    echo ",
            \"name\": \"";
                    // line 15
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["seance"], "heurDebut", array()), "H:i"), "html", null, true);
                    echo "\",
            \"startdate\": \"";
                    // line 16
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "date", array()), "Y-m-d"), "html", null, true);
                    echo "\",
            \"enddate\": \"\",
            ";
                    // line 18
                    if (($this->getAttribute($context["seance"], "dispo", array()) == 0)) {
                        // line 19
                        echo "                \"color\": \"#b21c27\",
                \"url\": \"\"
            ";
                    } else {
                        // line 22
                        echo "                \"color\": \"#dfe0d8\",
                \"url\": \"\"
            ";
                    }
                    // line 25
                    echo "
            },
        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['seance'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 28
                echo "    ";
            }
            // line 29
            echo "    ";
            if ((twig_date_format_filter($this->env, "now", "Y-m-d") <= twig_date_format_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "date", array()), "Y-m-d"))) {
                // line 30
                echo "        {
        \"id\": ";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "id", array()), "html", null, true);
                echo ",
        \"name\": \"Planifier...\",
        \"startdate\": \"";
                // line 33
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "date", array()), "Y-m-d"), "html", null, true);
                echo "\",
        \"enddate\": \"\",
        \"color\": \"#484848\",
        \"url\": \"";
                // line 36
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("seances_index", array("calendrie" => $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "id", array()))), "html", null, true);
                echo "\"
        },
    ";
            }
            // line 39
            echo "
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "seances/listeSeancesCalendar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 39,  108 => 36,  102 => 33,  97 => 31,  94 => 30,  91 => 29,  88 => 28,  80 => 25,  75 => 22,  70 => 19,  68 => 18,  63 => 16,  59 => 15,  55 => 14,  52 => 13,  47 => 12,  41 => 9,  35 => 6,  30 => 4,  27 => 3,  24 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if calendrie.deleatedAt is null %}
    {% if calendrie.absence == 1 and \"now\"|date('Y-m-d')  <= calendrie.date|date('Y-m-d') %}
        {
        \"id\": {{ calendrie.id }},
        \"name\": \"Absent\",
        \"startdate\": \"{{ calendrie.date|date('Y-m-d') }}\",
        \"enddate\": \"\",
        \"color\": \"#787683\",
        \"url\": \"{{ path('seances_index', {'calendrie':calendrie.id}) }}\"
        },
    {% else %}
        {% for seance in seances  %}
            {
            \"id\": {{ calendrie.id }},
            \"name\": \"{{ seance.heurDebut|date('H:i') }}\",
            \"startdate\": \"{{ calendrie.date|date('Y-m-d') }}\",
            \"enddate\": \"\",
            {% if seance.dispo == 0 %}
                \"color\": \"#b21c27\",
                \"url\": \"\"
            {% else %}
                \"color\": \"#dfe0d8\",
                \"url\": \"\"
            {% endif %}

            },
        {% endfor %}
    {% endif %}
    {% if \"now\"|date('Y-m-d')  <= calendrie.date|date('Y-m-d') %}
        {
        \"id\": {{ calendrie.id }},
        \"name\": \"Planifier...\",
        \"startdate\": \"{{ calendrie.date|date('Y-m-d') }}\",
        \"enddate\": \"\",
        \"color\": \"#484848\",
        \"url\": \"{{ path('seances_index', {'calendrie':calendrie.id}) }}\"
        },
    {% endif %}

{% endif %}
", "seances/listeSeancesCalendar.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\seances\\listeSeancesCalendar.html.twig");
    }
}

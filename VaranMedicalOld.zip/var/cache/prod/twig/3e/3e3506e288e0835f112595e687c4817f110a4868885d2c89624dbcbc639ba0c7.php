<?php

/* seances/weekSeancesByLocation.html.twig */
class __TwigTemplate_5428cfe91d5cdb049a417628698d8cc4e0573a7913e578c77417f604e037acfb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "seances/weekSeancesByLocation.html.twig"));

        // line 1
        echo "<div class=\"tg-dashboardbox\">
    ";
        // line 2
        if ((twig_length_filter($this->env, ($context["calendries"] ?? $this->getContext($context, "calendries"))) != 0)) {
            // line 3
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["calendries"] ?? $this->getContext($context, "calendries")));
            foreach ($context['_seq'] as $context["_key"] => $context["calendrie"]) {
                // line 4
                echo "            ";
                if (($this->getAttribute($context["calendrie"], "deleatedat", array()) == null)) {
                    // line 5
                    echo "                ";
                    if (($this->getAttribute($context["calendrie"], "absence", array()) == 0)) {
                        // line 6
                        echo "                    ";
                        if (($this->getAttribute($context["calendrie"], "public", array()) == 1)) {
                            // line 7
                            echo "                        <div class=\"row\">
                            <div class=\"col-sm-12 col-xs-12 tg-columnpadding\">
                                <div class=\"tg-dateandtimeslots\">
                                    <div class=\"tg-datebox\">
                                        <time datetime=\"2011-10-10\">";
                            // line 11
                            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["calendrie"], "date", array()), "M-d"), "html", null, true);
                            echo ", ";
                            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["calendrie"], "date", array()), "l"), "html", null, true);
                            echo "</time>
                                        <label style=\"color: white\">";
                            // line 12
                            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["calendrie"], "location", array()), "name", array()), "html", null, true);
                            echo "</label>
                                        <span>";
                            // line 13
                            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Seances:getNbrOfSeancesActive", array("calendrie" => $this->getAttribute($context["calendrie"], "id", array()))));
                            echo " Available</span>
                                        <i class=\"fa fa-calendar-check-o\"></i>
                                    </div>
                                    <div class=\"tg-timeslots\">
                                        ";
                            // line 17
                            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Seances:getSeacesByCalendarAppointements", array("calendar" => $this->getAttribute($context["calendrie"], "id", array()))));
                            echo "
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                    ";
                        }
                        // line 24
                        echo "
                ";
                    }
                    // line 26
                    echo "            ";
                }
                // line 27
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['calendrie'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "    ";
        } else {
            // line 29
            echo "        <p>doctor not available in this location</p>
    ";
        }
        // line 31
        echo "
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "seances/weekSeancesByLocation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 31,  90 => 29,  87 => 28,  81 => 27,  78 => 26,  74 => 24,  64 => 17,  57 => 13,  53 => 12,  47 => 11,  41 => 7,  38 => 6,  35 => 5,  32 => 4,  27 => 3,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"tg-dashboardbox\">
    {% if calendries|length != 0 %}
        {% for calendrie in calendries %}
            {% if calendrie.deleatedat == null %}
                {% if calendrie.absence == 0 %}
                    {% if calendrie.public == 1 %}
                        <div class=\"row\">
                            <div class=\"col-sm-12 col-xs-12 tg-columnpadding\">
                                <div class=\"tg-dateandtimeslots\">
                                    <div class=\"tg-datebox\">
                                        <time datetime=\"2011-10-10\">{{ calendrie.date|date(\"M-d\") }}, {{ calendrie.date|date(\"l\") }}</time>
                                        <label style=\"color: white\">{{ calendrie.location.name }}</label>
                                        <span>{{ render(controller('AppointmentsBundle:Seances:getNbrOfSeancesActive', {'calendrie': calendrie.id })) }} Available</span>
                                        <i class=\"fa fa-calendar-check-o\"></i>
                                    </div>
                                    <div class=\"tg-timeslots\">
                                        {{ render(controller('AppointmentsBundle:Seances:getSeacesByCalendarAppointements', {'calendar': calendrie.id })) }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                    {% endif %}

                {% endif %}
            {% endif %}
        {% endfor %}
    {% else %}
        <p>doctor not available in this location</p>
    {% endif %}

</div>", "seances/weekSeancesByLocation.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\seances\\weekSeancesByLocation.html.twig");
    }
}

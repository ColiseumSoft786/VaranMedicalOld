<?php

/* user/profil.html.twig */
class __TwigTemplate_fcd05077a0887ebd1f6507aebcfc690b04e7c18c5580b0e59e4c7dc57b1a41e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb592a932118034b68d1653abe4346bb1a193f1d8960057c5ac4cbac63df46a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb592a932118034b68d1653abe4346bb1a193f1d8960057c5ac4cbac63df46a4->enter($__internal_fb592a932118034b68d1653abe4346bb1a193f1d8960057c5ac4cbac63df46a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profil.html.twig"));

        // line 1
        $this->loadTemplate("base.html.twig", "user/profil.html.twig", 1)->display($context);
        // line 2
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 3
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_fb592a932118034b68d1653abe4346bb1a193f1d8960057c5ac4cbac63df46a4->leave($__internal_fb592a932118034b68d1653abe4346bb1a193f1d8960057c5ac4cbac63df46a4_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_71820ab785de2899db330b814b25936bd7a2a694b4a2cf58950a033d22f43e26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_71820ab785de2899db330b814b25936bd7a2a694b4a2cf58950a033d22f43e26->enter($__internal_71820ab785de2899db330b814b25936bd7a2a694b4a2cf58950a033d22f43e26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

    <body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\">
                                    ";
        // line 38
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 39
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                        </a>
                                    ";
        } else {
            // line 43
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 44
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                        </a>
                                    ";
        }
        // line 47
        echo "                                    ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 48
            echo "                                    <figcaption>
                                        <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                            <em class=\"tg-usericonholder\">
                                                <i class=\"fa fa-shield\"></i>
                                                <span>";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                            </em>
                                        </a>
                                    </figcaption>
                                    ";
        }
        // line 57
        echo "                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. ";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profilEdit", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Mis à jour"), "html", null, true);
        echo "</a> </div>
                                ";
        // line 67
        $this->loadTemplate("profilDoctorNav.html.twig", "user/profil.html.twig", 67)->display($context);
        // line 68
        echo "                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardtabs\">
                            <ul class=\"tg-dashboardtabnav\" role=\"tablist\">
                                <li role=\"presentation\" class=\"active\"> <a href=\"#overview\" aria-controls=\"overview\" role=\"tab\" data-toggle=\"tab\">";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Overview"), "html", null, true);
        echo "</a> </li>
                                <li role=\"presentation\"> <a href=\"#services\" aria-controls=\"services\" role=\"tab\" data-toggle=\"tab\">";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Services"), "html", null, true);
        echo "</a> </li>
                                <li role=\"presentation\"> <a href=\"#addphotos\" aria-controls=\"addphotos\" role=\"tab\" data-toggle=\"tab\">";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Photos"), "html", null, true);
        echo "(en construction)</a> </li>
                            </ul>
                            <div class=\"tab-content tg-dashboardtabcontent\">
                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                    ";
        // line 79
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:getDoctorSpecialities", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                    ";
        // line 80
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Educations:getDoctorEducation", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                    ";
        // line 81
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Certifications:getDoctorCertification", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                    ";
        // line 82
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_DOCTOR")) {
            // line 83
            echo "                                        ";
            if ($this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "professionalStatement", array())) {
                // line 84
                echo "                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2><i class=\"fa fa-user\"></i> ";
                // line 86
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Professional Statement"), "html", null, true);
                echo "</h2>
                                                </div>
                                                <div class=\"tg-box tg-basicinformation\">
                                                    <div class=\"row tg-rowmargin\">
                                                        ";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "professionalStatement", array()), "html", null, true);
                echo "
                                                    </div>
                                                </div>
                                            </div>
                                        ";
            }
            // line 95
            echo "                                    ";
        }
        // line 96
        echo "                                    <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click sur <strong>Mis à jour</strong> pour modifier ou mettre à jour vos informations.</span>
                                    </div>
                                </div>
                                <div role=\"tabpanel\" class=\"tab-pane\" id=\"services\">
                                    <div class=\"tg-dashboardbox tg-profilesettings\">
                                        ";
        // line 101
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Services:index", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
        echo "
                                    </div>
                                    <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click <strong>invoices settings</strong> to update latest added detail (s).</span>
                                    </div>
                                </div>
                                <div role=\"tabpanel\" class=\"tab-pane\" id=\"addphotos\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                                            ";
        // line 109
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_DOCTOR")) {
            // line 110
            echo "                                                ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Doctors:profileEditImage", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
            echo "
                                            ";
        } elseif ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_PATIENT")) {
            // line 112
            echo "                                                ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("PatientBundle:Patient:profileEditImage", array("doctor" => $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()))));
            echo "
                                            ";
        }
        // line 114
        echo "                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
";
        // line 132
        $this->loadTemplate("default/footer.html.twig", "user/profil.html.twig", 132)->display($context);
        
        $__internal_71820ab785de2899db330b814b25936bd7a2a694b4a2cf58950a033d22f43e26->leave($__internal_71820ab785de2899db330b814b25936bd7a2a694b4a2cf58950a033d22f43e26_prof);

    }

    public function getTemplateName()
    {
        return "user/profil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  255 => 132,  235 => 114,  229 => 112,  223 => 110,  221 => 109,  210 => 101,  203 => 96,  200 => 95,  192 => 90,  185 => 86,  181 => 84,  178 => 83,  176 => 82,  172 => 81,  168 => 80,  164 => 79,  157 => 75,  153 => 74,  149 => 73,  142 => 68,  140 => 67,  134 => 66,  122 => 59,  118 => 57,  110 => 52,  104 => 48,  101 => 47,  95 => 44,  92 => 43,  84 => 40,  81 => 39,  79 => 38,  63 => 25,  40 => 4,  27 => 3,  25 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
{% block body %}


    <body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\">
                                    {% if vich_uploader_asset(doctor, 'imageFile') %}
                                        <a href=\"#\">
                                            <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                        </a>
                                    {% else %}
                                        <a href=\"#\">
                                            <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                        </a>
                                    {% endif %}
                                    {% if app.user.verifier == 1 %}
                                    <figcaption>
                                        <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                            <em class=\"tg-usericonholder\">
                                                <i class=\"fa fa-shield\"></i>
                                                <span>{{ 'verified'|trans }}</span>
                                            </em>
                                        </a>
                                    </figcaption>
                                    {% endif %}
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profilEdit', {'doctor': app.user.idTable }) }}\">{{ 'Mis à jour'|trans }}</a> </div>
                                {% include('profilDoctorNav.html.twig') %}
                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardtabs\">
                            <ul class=\"tg-dashboardtabnav\" role=\"tablist\">
                                <li role=\"presentation\" class=\"active\"> <a href=\"#overview\" aria-controls=\"overview\" role=\"tab\" data-toggle=\"tab\">{{ 'Overview'|trans }}</a> </li>
                                <li role=\"presentation\"> <a href=\"#services\" aria-controls=\"services\" role=\"tab\" data-toggle=\"tab\">{{ 'Services'|trans }}</a> </li>
                                <li role=\"presentation\"> <a href=\"#addphotos\" aria-controls=\"addphotos\" role=\"tab\" data-toggle=\"tab\">{{ 'Photos'|trans }}(en construction)</a> </li>
                            </ul>
                            <div class=\"tab-content tg-dashboardtabcontent\">
                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                    {{ render(controller('DoctorsBundle:Doctors:getDoctorSpecialities', { 'doctor': doctor.id })) }}
                                    {{ render(controller('DoctorsBundle:Educations:getDoctorEducation', { 'doctor': doctor.id })) }}
                                    {{ render(controller('DoctorsBundle:Certifications:getDoctorCertification', { 'doctor': doctor.id })) }}
                                    {% if is_granted('ROLE_DOCTOR') %}
                                        {% if doctor.professionalStatement %}
                                            <div class=\"tg-dashboardbox\">
                                                <div class=\"tg-dashboardboxtitle\">
                                                    <h2><i class=\"fa fa-user\"></i> {{ 'Professional Statement'|trans }}</h2>
                                                </div>
                                                <div class=\"tg-box tg-basicinformation\">
                                                    <div class=\"row tg-rowmargin\">
                                                        {{ doctor.professionalStatement }}
                                                    </div>
                                                </div>
                                            </div>
                                        {% endif %}
                                    {% endif %}
                                    <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click sur <strong>Mis à jour</strong> pour modifier ou mettre à jour vos informations.</span>
                                    </div>
                                </div>
                                <div role=\"tabpanel\" class=\"tab-pane\" id=\"services\">
                                    <div class=\"tg-dashboardbox tg-profilesettings\">
                                        {{ render(controller('DoctorsBundle:Services:index', {'doctor':doctor.id})) }}
                                    </div>
                                    <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click <strong>invoices settings</strong> to update latest added detail (s).</span>
                                    </div>
                                </div>
                                <div role=\"tabpanel\" class=\"tab-pane\" id=\"addphotos\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                                            {% if is_granted('ROLE_DOCTOR') %}
                                                {{ render(controller('DoctorsBundle:Doctors:profileEditImage', {'doctor': doctor.id})) }}
                                            {% elseif is_granted('ROLE_PATIENT') %}
                                                {{ render(controller('PatientBundle:Patient:profileEditImage', {'doctor': doctor.id})) }}
                                            {% endif %}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
{% include ('default/footer.html.twig') %}
{% endblock %}
{% endif %}", "user/profil.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\profil.html.twig");
    }
}

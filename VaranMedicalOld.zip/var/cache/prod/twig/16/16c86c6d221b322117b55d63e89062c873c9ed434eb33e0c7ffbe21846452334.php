<?php

/* doctors/doctorDetailsEducations.html.twig */
class __TwigTemplate_1a3e6f5dd14945b87d07a453b9cc681adf1e53e27c78498367b07631df1b1e9b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "doctors/doctorDetailsEducations.html.twig"));

        // line 1
        if (($context["educations"] ?? $this->getContext($context, "educations"))) {
            // line 2
            echo "<div class=\"tg-box\">
    <div class=\"tg-icontitle\">
        <h3 class=\"fa fa-mortar-board\">";
            // line 4
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Education"), "html", null, true);
            echo "</h3>
    </div>
    <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle tg-education\">
        ";
            // line 7
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["educations"] ?? $this->getContext($context, "educations")));
            foreach ($context['_seq'] as $context["_key"] => $context["education"]) {
                // line 8
                echo "        <li>
            <span>";
                // line 9
                echo twig_escape_filter($this->env, $this->getAttribute($context["education"], "typeOfSchool", array()), "html", null, true);
                echo "</span>
            <span>";
                // line 10
                echo twig_escape_filter($this->env, $this->getAttribute($context["education"], "school", array()), "html", null, true);
                echo "</span>
        </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['education'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "    </ul>
</div>
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "doctors/doctorDetailsEducations.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 13,  45 => 10,  41 => 9,  38 => 8,  34 => 7,  28 => 4,  24 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if educations %}
<div class=\"tg-box\">
    <div class=\"tg-icontitle\">
        <h3 class=\"fa fa-mortar-board\">{{ 'Education'|trans }}</h3>
    </div>
    <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle tg-education\">
        {% for education in educations %}
        <li>
            <span>{{ education.typeOfSchool }}</span>
            <span>{{ education.school }}</span>
        </li>
        {% endfor %}
    </ul>
</div>
{% endif %}", "doctors/doctorDetailsEducations.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\doctors\\doctorDetailsEducations.html.twig");
    }
}

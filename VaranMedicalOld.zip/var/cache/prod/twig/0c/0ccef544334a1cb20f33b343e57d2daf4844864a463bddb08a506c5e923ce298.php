<?php

/* services/settings.html.twig */
class __TwigTemplate_79f986fa59006a5444e86d57a7f227568f79ca3cfd6272d87867e5eba68359d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_74c4e5547d0a6182b23e85a5f1254040b22b0e83a39a55d669dc5b235eea47d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74c4e5547d0a6182b23e85a5f1254040b22b0e83a39a55d669dc5b235eea47d2->enter($__internal_74c4e5547d0a6182b23e85a5f1254040b22b0e83a39a55d669dc5b235eea47d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "services/settings.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "services/settings.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            $this->displayBlock('body', $context, $blocks);
        }
        // line 133
        echo "
";
        
        $__internal_74c4e5547d0a6182b23e85a5f1254040b22b0e83a39a55d669dc5b235eea47d2->leave($__internal_74c4e5547d0a6182b23e85a5f1254040b22b0e83a39a55d669dc5b235eea47d2_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_bb80773b69d326f2d08303a6605626a78ba2bcb35bf36732bff580177b83e55b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb80773b69d326f2d08303a6605626a78ba2bcb35bf36732bff580177b83e55b->enter($__internal_bb80773b69d326f2d08303a6605626a78ba2bcb35bf36732bff580177b83e55b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\"> 
                                    ";
        // line 39
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 40
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                        </a>
                                    ";
        } else {
            // line 44
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                        </a>
                                    ";
        }
        // line 48
        echo "                                    ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 49
            echo "                                        <figcaption>
                                            <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                <em class=\"tg-usericonholder\">
                                                    <i class=\"fa fa-shield\"></i>
                                                    <span>";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                </em>
                                            </a>
                                        </figcaption>
                                    ";
        }
        // line 58
        echo "                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. ";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profilEdit", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Mis à jour"), "html", null, true);
        echo "</a> </div>
                            ";
        // line 68
        $this->loadTemplate("profilDoctorNav.html.twig", "services/settings.html.twig", 68)->display($context);
        // line 69
        echo "                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardinvoices\">
                            <div class=\"tg-dashboardbox\">
                                <div class=\"tg-dashboardboxtitle\">
                                    <h2>";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Invoices"), "html", null, true);
        echo "</h2>
                                </div>
                                <div class=\"col-lg-8\">
                                    ";
        // line 78
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Services:comboServicesByDoctor", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))));
        echo "
                                </div>
                                <div class=\"col-lg-4\">
                                    <button type=\"button\" class=\"tg-btn pull-right\" data-toggle=\"modal\" data-target=\"#addService\">";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("add new"), "html", null, true);
        echo "</button>
                                </div>
                                <div id=\"listSubServices\"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"addService\" tabindex=\"-1\" role=\"dialog\">
    <div class=\"modal-dialog tg-modaldialog\">
        <div class=\"modal-content tg-modalcontent\">
            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
            <h2>";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Add new service"), "html", null, true);
        echo "</h2>
            ";
        // line 101
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Invoices:new"));
        echo "
        </div>

    </div>
</div>
<!--************************************
        Wrapper End
*************************************-->
";
        // line 109
        $this->loadTemplate("default/footer.html.twig", "services/settings.html.twig", 109)->display($context);
        // line 110
        echo "<script>
    \$(document).ready(function () {
        \$(\"#serviceDoctor\").change(function () {
            var service = \$('#serviceDoctor').val();
            var doctor = ";
        // line 114
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "id", array()), "html", null, true);
        echo ";

            var URL = \"";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("invoices_listSubServices", array("doctor" => "sss", "service" => "ddd")), "html", null, true);
        echo "\";
            URL = URL.replace(/sss/g, doctor);
            URL = URL.replace(/ddd/g, service);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$(\"#listSubServices\").html(response);
                    return true;
                }
            });
        });
    });
</script>
";
        
        $__internal_bb80773b69d326f2d08303a6605626a78ba2bcb35bf36732bff580177b83e55b->leave($__internal_bb80773b69d326f2d08303a6605626a78ba2bcb35bf36732bff580177b83e55b_prof);

    }

    public function getTemplateName()
    {
        return "services/settings.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  219 => 116,  214 => 114,  208 => 110,  206 => 109,  195 => 101,  191 => 100,  169 => 81,  163 => 78,  157 => 75,  149 => 69,  147 => 68,  141 => 67,  129 => 60,  125 => 58,  117 => 53,  111 => 49,  108 => 48,  102 => 45,  99 => 44,  91 => 41,  88 => 40,  86 => 39,  70 => 26,  47 => 5,  41 => 4,  33 => 133,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
{% block body %}


<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\"> 
                                    {% if vich_uploader_asset(doctor, 'imageFile') %}
                                        <a href=\"#\">
                                            <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                        </a>
                                    {% else %}
                                        <a href=\"#\">
                                            <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                        </a>
                                    {% endif %}
                                    {% if app.user.verifier == 1 %}
                                        <figcaption>
                                            <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                <em class=\"tg-usericonholder\">
                                                    <i class=\"fa fa-shield\"></i>
                                                    <span>{{ 'verified'|trans }}</span>
                                                </em>
                                            </a>
                                        </figcaption>
                                    {% endif %}
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profilEdit', {'doctor': app.user.idTable }) }}\">{{ 'Mis à jour'|trans }}</a> </div>
                            {% include('profilDoctorNav.html.twig') %}
                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardinvoices\">
                            <div class=\"tg-dashboardbox\">
                                <div class=\"tg-dashboardboxtitle\">
                                    <h2>{{ 'Invoices'|trans }}</h2>
                                </div>
                                <div class=\"col-lg-8\">
                                    {{ render(controller('DoctorsBundle:Services:comboServicesByDoctor', {'doctor':app.user.idTable})) }}
                                </div>
                                <div class=\"col-lg-4\">
                                    <button type=\"button\" class=\"tg-btn pull-right\" data-toggle=\"modal\" data-target=\"#addService\">{{ 'add new'|trans }}</button>
                                </div>
                                <div id=\"listSubServices\"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"addService\" tabindex=\"-1\" role=\"dialog\">
    <div class=\"modal-dialog tg-modaldialog\">
        <div class=\"modal-content tg-modalcontent\">
            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
            <h2>{{ 'Add new service'|trans }}</h2>
            {{ render(controller('DoctorsBundle:Invoices:new')) }}
        </div>

    </div>
</div>
<!--************************************
        Wrapper End
*************************************-->
{% include ('default/footer.html.twig') %}
<script>
    \$(document).ready(function () {
        \$(\"#serviceDoctor\").change(function () {
            var service = \$('#serviceDoctor').val();
            var doctor = {{ doctor.id }};

            var URL = \"{{ path('invoices_listSubServices', {'doctor' : 'sss', 'service': 'ddd'}) }}\";
            URL = URL.replace(/sss/g, doctor);
            URL = URL.replace(/ddd/g, service);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$(\"#listSubServices\").html(response);
                    return true;
                }
            });
        });
    });
</script>
{% endblock %}
{% endif %}

", "services/settings.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\services\\settings.html.twig");
    }
}

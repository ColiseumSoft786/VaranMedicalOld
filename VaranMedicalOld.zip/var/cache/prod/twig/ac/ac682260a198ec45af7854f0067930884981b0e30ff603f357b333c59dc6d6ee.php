<?php

/* doctors/profilEditBasicInformation.html.twig */
class __TwigTemplate_a9000c82b820e892e5e82b2c63a2954278b18d9dbd2a48a67d5a4c9f5566224a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_36ff5789a374bb7f6b2741c54c4d4463509388dfc04c33529e89b2bc0fd0086a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36ff5789a374bb7f6b2741c54c4d4463509388dfc04c33529e89b2bc0fd0086a->enter($__internal_36ff5789a374bb7f6b2741c54c4d4463509388dfc04c33529e89b2bc0fd0086a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "doctors/profilEditBasicInformation.html.twig"));

        // line 1
        echo "<ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
    <li><b>";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Name"), "html", null, true);
        echo " :</b> ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "title", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</li>
    <li><b>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Birthday"), "html", null, true);
        echo " :</b> ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "birthday", array()), "d-M-Y"), "html", null, true);
        echo "</li>
    ";
        // line 4
        if ($this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "GSM", array())) {
            // line 5
            echo "        <li><b>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Phone"), "html", null, true);
            echo ":</b> ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "GSM", array()), "html", null, true);
            echo " </li>
    ";
        }
        // line 7
        echo "    ";
        if ($this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "professionalStatement", array())) {
            // line 8
            echo "        <li><b>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Professional Statement"), "html", null, true);
            echo ":</b> ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "professionalStatement", array()), "html", null, true);
            echo " </li>
    ";
        }
        // line 10
        echo "</ul>";
        
        $__internal_36ff5789a374bb7f6b2741c54c4d4463509388dfc04c33529e89b2bc0fd0086a->leave($__internal_36ff5789a374bb7f6b2741c54c4d4463509388dfc04c33529e89b2bc0fd0086a_prof);

    }

    public function getTemplateName()
    {
        return "doctors/profilEditBasicInformation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 10,  54 => 8,  51 => 7,  43 => 5,  41 => 4,  35 => 3,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
    <li><b>{{ 'Name'|trans }} :</b> {{ doctor.title }} {{ doctor.firstName }} {{ doctor.lastName }}</li>
    <li><b>{{ 'Birthday'|trans }} :</b> {{ doctor.birthday|date('d-M-Y') }}</li>
    {% if doctor.GSM %}
        <li><b>{{ 'Phone'|trans }}:</b> {{ doctor.GSM }} </li>
    {% endif %}
    {% if doctor.professionalStatement %}
        <li><b>{{ 'Professional Statement'|trans }}:</b> {{ doctor.professionalStatement }} </li>
    {% endif %}
</ul>", "doctors/profilEditBasicInformation.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\doctors\\profilEditBasicInformation.html.twig");
    }
}

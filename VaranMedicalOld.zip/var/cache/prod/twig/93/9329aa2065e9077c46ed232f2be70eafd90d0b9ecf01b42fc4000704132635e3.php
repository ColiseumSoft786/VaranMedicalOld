<?php

/* calendries/listeCalendries.html.twig */
class __TwigTemplate_553a059003f851f2866dbecb7f461ac0742b257257f16aba26a93445f69f34e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1d475c27053718418270a196ab46ffc71c479fad086e50a50e3089341b22511 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1d475c27053718418270a196ab46ffc71c479fad086e50a50e3089341b22511->enter($__internal_f1d475c27053718418270a196ab46ffc71c479fad086e50a50e3089341b22511_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calendries/listeCalendries.html.twig"));

        // line 1
        echo "
<div class=\"tg-favoritlistingbox monthly\" id=\"mycalendar\">

</div>
    <script type=\"text/javascript\" src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/Calendar/js/jquery.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/Calendar/js/monthly.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\">

        var sampleEvents = {
            \"monthly\": [
                ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["calendries"] ?? $this->getContext($context, "calendries")));
        foreach ($context['_seq'] as $context["_key"] => $context["calendrie"]) {
            // line 12
            echo "                    ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Seances:getSeacesByCalendar", array("calendar" => $this->getAttribute($context["calendrie"], "id", array()))));
            echo "
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['calendrie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "            ]
        };
    </script>
</div>

<script>

    \$(document).ready(function () {
        \$('#mycalendar').monthly({
            mode: 'event',
            dataType: 'json',
            events: sampleEvents
        });
    });
</script>

";
        
        $__internal_f1d475c27053718418270a196ab46ffc71c479fad086e50a50e3089341b22511->leave($__internal_f1d475c27053718418270a196ab46ffc71c479fad086e50a50e3089341b22511_prof);

    }

    public function getTemplateName()
    {
        return "calendries/listeCalendries.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 14,  44 => 12,  40 => 11,  32 => 6,  28 => 5,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
<div class=\"tg-favoritlistingbox monthly\" id=\"mycalendar\">

</div>
    <script type=\"text/javascript\" src=\"{{ asset('assets/Calendar/js/jquery.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('assets/Calendar/js/monthly.js') }}\"></script>
    <script type=\"text/javascript\">

        var sampleEvents = {
            \"monthly\": [
                {% for calendrie in calendries %}
                    {{ render(controller('AppointmentsBundle:Seances:getSeacesByCalendar', {'calendar':calendrie.id})) }}
                {% endfor %}
            ]
        };
    </script>
</div>

<script>

    \$(document).ready(function () {
        \$('#mycalendar').monthly({
            mode: 'event',
            dataType: 'json',
            events: sampleEvents
        });
    });
</script>

", "calendries/listeCalendries.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\calendries\\listeCalendries.html.twig");
    }
}

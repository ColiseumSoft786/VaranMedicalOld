<?php

/* settings/edit.html.twig */
class __TwigTemplate_4110096c1bb989b3dc9deda48a20b1455064d0e6caf90ffcd8da3593ff08f566 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b3ce01931b6f5ecce265fd9a62e04f88f9d0d1aa50fdde14ce950d3b24a7d77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b3ce01931b6f5ecce265fd9a62e04f88f9d0d1aa50fdde14ce950d3b24a7d77->enter($__internal_7b3ce01931b6f5ecce265fd9a62e04f88f9d0d1aa50fdde14ce950d3b24a7d77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "settings/edit.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "settings/edit.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
            // line 116
            echo "<script type=\"text/javascript\">
    \$('.clockpicker').clockpicker({
        placement: 'top',
        align: 'left',
        donetext: 'Done'
    });
</script>

";
        }
        
        $__internal_7b3ce01931b6f5ecce265fd9a62e04f88f9d0d1aa50fdde14ce950d3b24a7d77->leave($__internal_7b3ce01931b6f5ecce265fd9a62e04f88f9d0d1aa50fdde14ce950d3b24a7d77_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_affb9aac533a2ab63b8ac36fd6f84056144344eb7584be0097f8c1f4f2d5b3fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_affb9aac533a2ab63b8ac36fd6f84056144344eb7584be0097f8c1f4f2d5b3fa->enter($__internal_affb9aac533a2ab63b8ac36fd6f84056144344eb7584be0097f8c1f4f2d5b3fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\"> 
                                    ";
        // line 39
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 40
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                        </a>
                                    ";
        } else {
            // line 44
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                        </a>
                                    ";
        }
        // line 47
        echo "                                         
                                    ";
        // line 48
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 49
            echo "                                        <figcaption>
                                            <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                <em class=\"tg-usericonholder\">
                                                    <i class=\"fa fa-shield\"></i>
                                                    <span>";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                </em>
                                            </a>
                                        </figcaption>
                                    ";
        }
        // line 58
        echo "                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. ";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profilEdit", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Mis à jour"), "html", null, true);
        echo "</a> </div>
                            ";
        // line 68
        $this->loadTemplate("profilDoctorNav.html.twig", "settings/edit.html.twig", 68)->display($context);
        // line 69
        echo "                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardtabs\">
                            <div class=\"tab-content tg-dashboardtabcontent\">
                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"tg-dashboardboxtitle\">
                                            <h2><i class=\"fa fa-gears\"></i> ";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Settings"), "html", null, true);
        echo "</h2>
                                        </div>
                                        <div class=\"tg-box tg-experience tg-uiicons\">
                                            <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
                                                <form action=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("settings_edit", array("id" => $this->getAttribute(($context["setting"] ?? $this->getContext($context, "setting")), "id", array()))), "html", null, true);
        echo "\" method=\"post\">
                                                    <div class=\" col-lg-12 col-sm-6 col-xs-12 tg-columnpadding\">
                                                        <li> <span>Durée des rendez-vous</span> <span>";
        // line 83
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "durreAppointment", array()), 'widget', array("attr" => array("class" => "form-control clockpicker")));
        echo "</span> </li>
                                                        <input type=\"hidden\" value=\"";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["setting"] ?? $this->getContext($context, "setting")), "doctor", array()), "id", array()), "html", null, true);
        echo "\" id=\"appointmentsbundle_settings_doctor\" name=\"appointmentsbundle_settings[doctor]\" />
                                                        ";
        // line 85
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "_token", array()), 'widget');
        echo "
                                                    </div>
                                                    <br> <br><br><br><br>
                                                    <div class=\"col-lg-2 pull-right\">
                                                        <div class=\"tg-btnbox\">
                                                            <button type=\"submit\" class=\"tg-btn\">";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("update"), "html", null, true);
        echo "</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
";
        // line 114
        $this->loadTemplate("default/footer.html.twig", "settings/edit.html.twig", 114)->display($context);
        
        $__internal_affb9aac533a2ab63b8ac36fd6f84056144344eb7584be0097f8c1f4f2d5b3fa->leave($__internal_affb9aac533a2ab63b8ac36fd6f84056144344eb7584be0097f8c1f4f2d5b3fa_prof);

    }

    public function getTemplateName()
    {
        return "settings/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 114,  197 => 90,  189 => 85,  185 => 84,  181 => 83,  176 => 81,  169 => 77,  159 => 69,  157 => 68,  151 => 67,  139 => 60,  135 => 58,  127 => 53,  121 => 49,  119 => 48,  116 => 47,  110 => 45,  107 => 44,  99 => 41,  96 => 40,  94 => 39,  78 => 26,  55 => 5,  49 => 4,  33 => 116,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}


<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\"> 
                                    {% if vich_uploader_asset(doctor, 'imageFile') %}
                                        <a href=\"#\">
                                            <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                        </a>
                                    {% else %}
                                        <a href=\"#\">
                                            <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                        </a>
                                    {% endif %}                                         
                                    {% if app.user.verifier == 1 %}
                                        <figcaption>
                                            <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                <em class=\"tg-usericonholder\">
                                                    <i class=\"fa fa-shield\"></i>
                                                    <span>{{ 'verified'|trans }}</span>
                                                </em>
                                            </a>
                                        </figcaption>
                                    {% endif %}
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profilEdit', {'doctor': app.user.idTable }) }}\">{{ 'Mis à jour'|trans }}</a> </div>
                            {% include('profilDoctorNav.html.twig') %}
                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardtabs\">
                            <div class=\"tab-content tg-dashboardtabcontent\">
                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"tg-dashboardboxtitle\">
                                            <h2><i class=\"fa fa-gears\"></i> {{ 'Settings'|trans }}</h2>
                                        </div>
                                        <div class=\"tg-box tg-experience tg-uiicons\">
                                            <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
                                                <form action=\"{{ path('settings_edit', { 'id' : setting.id }) }}\" method=\"post\">
                                                    <div class=\" col-lg-12 col-sm-6 col-xs-12 tg-columnpadding\">
                                                        <li> <span>Durée des rendez-vous</span> <span>{{ form_widget(edit_form.durreAppointment, {'attr':{'class':'form-control clockpicker',}}) }}</span> </li>
                                                        <input type=\"hidden\" value=\"{{ setting.doctor.id }}\" id=\"appointmentsbundle_settings_doctor\" name=\"appointmentsbundle_settings[doctor]\" />
                                                        {{ form_widget(edit_form._token) }}
                                                    </div>
                                                    <br> <br><br><br><br>
                                                    <div class=\"col-lg-2 pull-right\">
                                                        <div class=\"tg-btnbox\">
                                                            <button type=\"submit\" class=\"tg-btn\">{{ 'update'|trans }}</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
{% include ('default/footer.html.twig') %}
{% endblock %}
<script type=\"text/javascript\">
    \$('.clockpicker').clockpicker({
        placement: 'top',
        align: 'left',
        donetext: 'Done'
    });
</script>

{% endif %}
", "settings/edit.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\settings\\edit.html.twig");
    }
}

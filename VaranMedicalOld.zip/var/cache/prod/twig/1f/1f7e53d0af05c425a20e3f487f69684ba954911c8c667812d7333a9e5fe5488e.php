<?php

/* AdminBundle:Holiday:publicholiday.html.twig */
class __TwigTemplate_6a2deee07febb8b3b0b13b78cae54739fc0597eb65e263ba62c4be78149a23ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Holiday:publicholiday.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Holiday:publicholiday.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Admin: Public Holidays";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
    <section class=\"content-header\">
        <h1>
            Public Holidays
        </h1>
        <ol class=\"breadcrumb\">
            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>
            <li class=\"active\">Weekends</li>
        </ol>
    </section>

    <section class=\"content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"box box-info\">
                    <div class=\"box-header with-border\">
                        <a class=\"label label-info\" href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_holiday_index_pHoliday_add");
        echo "\"><span class=\"fa fa-plus-circle\"></span> Create a Public Holiday</a>

                        <div class=\"box-tools pull-right\">
                            <button type=\"button\" class=\"btn btn-box-tool\" data-widget=\"collapse\"><i class=\"fa fa-minus\"></i>
                            </button>
                            ";
        // line 28
        echo "                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class=\"box-body\">
                        <div class=\"table-responsive\">
                            <table class=\"table no-margin\">
                                <thead>
                                <tr>
                                    <th style=\"text-align: center;\">#</th>
                                    <th style=\"text-align: center;\">Date</th>
                                    <th style=\"text-align: center;\">Added By</th>
                                    <th style=\"text-align: center;\">Reason</th>
                                    <th style=\"text-align: center;\">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                ";
        // line 45
        $context["count"] = 1;
        // line 46
        echo "                                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["holi"] ?? $this->getContext($context, "holi")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 47
            echo "                                    <tr  style=\"text-align: center;\">
                                        <td>";
            // line 48
            echo twig_escape_filter($this->env, ($context["count"] ?? $this->getContext($context, "count")), "html", null, true);
            echo "</td>
                                        <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "date", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "admin", array()), "name", array()), "html", null, true);
            echo "</td>
                                        <td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "reason", array()), "html", null, true);
            echo "</td>
                                        <td><a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_holiday_index_pHoliday_delete", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\">Delete</a></td>
                                    </tr>
                                    ";
            // line 54
            $context["count"] = (($context["count"] ?? $this->getContext($context, "count")) + 1);
            // line 55
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "

                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->

                    <!-- /.box-footer -->
                </div>
            </div>

        </div>
    </section>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Holiday:publicholiday.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 56,  131 => 55,  129 => 54,  124 => 52,  120 => 51,  116 => 50,  112 => 49,  108 => 48,  105 => 47,  100 => 46,  98 => 45,  79 => 28,  71 => 22,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::admin.html.twig\" %}

{% block title %}Admin: Public Holidays{% endblock %}

{% block body %}

    <section class=\"content-header\">
        <h1>
            Public Holidays
        </h1>
        <ol class=\"breadcrumb\">
            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>
            <li class=\"active\">Weekends</li>
        </ol>
    </section>

    <section class=\"content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"box box-info\">
                    <div class=\"box-header with-border\">
                        <a class=\"label label-info\" href=\"{{ path('admin_holiday_index_pHoliday_add') }}\"><span class=\"fa fa-plus-circle\"></span> Create a Public Holiday</a>

                        <div class=\"box-tools pull-right\">
                            <button type=\"button\" class=\"btn btn-box-tool\" data-widget=\"collapse\"><i class=\"fa fa-minus\"></i>
                            </button>
                            {#<button type=\"button\" class=\"btn btn-box-tool\" data-widget=\"remove\"><i class=\"fa fa-times\"></i></button>#}
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class=\"box-body\">
                        <div class=\"table-responsive\">
                            <table class=\"table no-margin\">
                                <thead>
                                <tr>
                                    <th style=\"text-align: center;\">#</th>
                                    <th style=\"text-align: center;\">Date</th>
                                    <th style=\"text-align: center;\">Added By</th>
                                    <th style=\"text-align: center;\">Reason</th>
                                    <th style=\"text-align: center;\">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                {% set count = 1 %}
                                {% for item in holi %}
                                    <tr  style=\"text-align: center;\">
                                        <td>{{ count }}</td>
                                        <td>{{ item.date }}</td>
                                        <td>{{ item.admin.name }}</td>
                                        <td>{{ item.reason }}</td>
                                        <td><a href=\"{{ path('admin_holiday_index_pHoliday_delete',{id:item.id}) }}\">Delete</a></td>
                                    </tr>
                                    {% set count = count + 1 %}
                                {% endfor %}


                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->

                    <!-- /.box-footer -->
                </div>
            </div>

        </div>
    </section>



{% endblock %}
", "AdminBundle:Holiday:publicholiday.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AdminBundle/Resources/views/Holiday/publicholiday.html.twig");
    }
}

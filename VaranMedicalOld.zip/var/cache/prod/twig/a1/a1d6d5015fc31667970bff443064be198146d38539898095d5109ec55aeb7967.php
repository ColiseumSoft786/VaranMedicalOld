<?php

/* settings/index.html.twig */
class __TwigTemplate_9bf00c8f1cdfaee4c7bf36e75e237c8525def3acad1c1aab997de2834fffd40a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c00f570d6400306b9f4f57bd57fb2d28d48a8a9a9152a146957550e0ee1df340 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c00f570d6400306b9f4f57bd57fb2d28d48a8a9a9152a146957550e0ee1df340->enter($__internal_c00f570d6400306b9f4f57bd57fb2d28d48a8a9a9152a146957550e0ee1df340_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "settings/index.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "settings/index.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_c00f570d6400306b9f4f57bd57fb2d28d48a8a9a9152a146957550e0ee1df340->leave($__internal_c00f570d6400306b9f4f57bd57fb2d28d48a8a9a9152a146957550e0ee1df340_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_b5dc4283d2b879e049c1da2f4c55fe8c952a642b7cab1f4be3bf3ca62c1f2951 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5dc4283d2b879e049c1da2f4c55fe8c952a642b7cab1f4be3bf3ca62c1f2951->enter($__internal_b5dc4283d2b879e049c1da2f4c55fe8c952a642b7cab1f4be3bf3ca62c1f2951_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

        <body class=\"tg-home tg-login\">
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!--************************************
                Preloader Start
        *************************************--
        <div class=\"preloader-outer\">
            <div class=\"pin\"></div>
            <div class=\"pulse\"></div>
        </div>
        <!--************************************
                Preloader End
        *************************************-->

        <!--************************************
                Wrapper Start
        *************************************-->
        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                    Main Start
            *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\"> 
                                            ";
        // line 39
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 40
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 44
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 48
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 49
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 58
        echo "                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profilEdit", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Mis à jour"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 68
        $this->loadTemplate("profilDoctorNav.html.twig", "settings/index.html.twig", 68)->display($context);
        // line 69
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <div class=\"tg-dashboardtabs\">
                                    <div class=\"tab-content tg-dashboardtabcontent\">
                                        <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                                <div class=\"tg-dashboardbox\">
                                                    <div class=\"tg-dashboardboxtitle\">
                                                        <h2><i class=\"fa fa-gears\"></i> ";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Settings"), "html", null, true);
        echo "</h2>
                                                    </div>
                                                    <div class=\"tg-box tg-experience tg-uiicons\">
                                                        <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
                                                            ";
        // line 81
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["settings"] ?? $this->getContext($context, "settings")));
        foreach ($context['_seq'] as $context["_key"] => $context["setting"]) {
            // line 82
            echo "                                                                ";
            $context["id"] = $this->getAttribute($context["setting"], "id", array());
            // line 83
            echo "                                                                <li> <span>Durée des rendez-vous</span> <span>";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["setting"], "durreAppointment", array()), "H:i"), "html", null, true);
            echo "</span> </li>
                                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['setting'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "                                                        </ul>
                                                    </div>
                                                </div>

                                            <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click sur <strong>
                                                <a href=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("settings_edit", array("id" => ($context["id"] ?? $this->getContext($context, "id")))), "html", null, true);
        echo "\">ICI</a></strong> pour modifier ou mettre à jour vos informations.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <!--************************************
                    Main End
            *************************************-->

        </div>
        <!--************************************
                Wrapper End
        *************************************-->
        ";
        // line 108
        $this->loadTemplate("default/footer.html.twig", "settings/index.html.twig", 108)->display($context);
        // line 109
        echo "    ";
        
        $__internal_b5dc4283d2b879e049c1da2f4c55fe8c952a642b7cab1f4be3bf3ca62c1f2951->leave($__internal_b5dc4283d2b879e049c1da2f4c55fe8c952a642b7cab1f4be3bf3ca62c1f2951_prof);

    }

    public function getTemplateName()
    {
        return "settings/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 109,  207 => 108,  186 => 90,  179 => 85,  170 => 83,  167 => 82,  163 => 81,  156 => 77,  146 => 69,  144 => 68,  138 => 67,  126 => 60,  122 => 58,  114 => 53,  108 => 49,  105 => 48,  99 => 45,  96 => 44,  88 => 41,  85 => 40,  83 => 39,  67 => 26,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}


        <body class=\"tg-home tg-login\">
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!--************************************
                Preloader Start
        *************************************--
        <div class=\"preloader-outer\">
            <div class=\"pin\"></div>
            <div class=\"pulse\"></div>
        </div>
        <!--************************************
                Preloader End
        *************************************-->

        <!--************************************
                Wrapper Start
        *************************************-->
        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                    Main Start
            *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\"> 
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profilEdit', {'doctor': app.user.idTable }) }}\">{{ 'Mis à jour'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <div class=\"tg-dashboardtabs\">
                                    <div class=\"tab-content tg-dashboardtabcontent\">
                                        <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                                <div class=\"tg-dashboardbox\">
                                                    <div class=\"tg-dashboardboxtitle\">
                                                        <h2><i class=\"fa fa-gears\"></i> {{ 'Settings'|trans }}</h2>
                                                    </div>
                                                    <div class=\"tg-box tg-experience tg-uiicons\">
                                                        <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
                                                            {% for setting in settings %}
                                                                {% set id = setting.id %}
                                                                <li> <span>Durée des rendez-vous</span> <span>{{ setting.durreAppointment|date('H:i') }}</span> </li>
                                                            {% endfor %}
                                                        </ul>
                                                    </div>
                                                </div>

                                            <div class=\"tg-updateall\"> <span class=\"tg-note\">* Click sur <strong>
                                                <a href=\"{{ path('settings_edit', {'id': id}) }}\">ICI</a></strong> pour modifier ou mettre à jour vos informations.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <!--************************************
                    Main End
            *************************************-->

        </div>
        <!--************************************
                Wrapper End
        *************************************-->
        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}", "settings/index.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\settings\\index.html.twig");
    }
}

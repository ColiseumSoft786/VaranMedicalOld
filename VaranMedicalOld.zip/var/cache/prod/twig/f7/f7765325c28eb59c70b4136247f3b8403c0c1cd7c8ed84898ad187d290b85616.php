<?php

/* patient/profil.html.twig */
class __TwigTemplate_884c9ec9c1bbf919a8ec4a938984120ea67321aab49645b31b1bd59ed2249e11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "patient/profil.html.twig"));

        // line 1
        $this->loadTemplate("base.html.twig", "patient/profil.html.twig", 1)->display($context);
        // line 2
        $this->displayBlock('body', $context, $blocks);
        // line 136
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<body class=\"tg-home tg-login\">

<link href=\"https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css\" rel=\"stylesheet\">
<script src=\"https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js\"></script>

<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">                    
                                <figure class=\"tg-directpostimg\">
                                    ";
        // line 39
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["patient"] ?? $this->getContext($context, "patient")), "imageFile")) {
            // line 40
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["patient"] ?? $this->getContext($context, "patient")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "image", array()), "html", null, true);
            echo "\" />
                                        </a>
                                    ";
        } else {
            // line 44
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                        </a>
                                    ";
        }
        // line 48
        echo "                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("patient_editProfil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Mis à jour"), "html", null, true);
        echo "</a> </div>

                            ";
        // line 59
        $this->loadTemplate("profilPatientNav.html.twig", "patient/profil.html.twig", 59)->display($context);
        // line 60
        echo "                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardtabs\">
                            <h3>";
        // line 64
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profil"), "html", null, true);
        echo "</h3>
                            <hr>
                            <br>
                            <div class=\"tab-content tg-dashboardtabcontent\">
                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                    <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
                                        <li><b>";
        // line 70
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Name"), "html", null, true);
        echo " :</b> ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "lastName", array()), "html", null, true);
        echo "</li>
                                        <li><b>";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Birthday"), "html", null, true);
        echo " :</b> ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "birthday", array()), "d-M-Y"), "html", null, true);
        echo "</li>
                                        ";
        // line 72
        if ($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "GSM", array())) {
            // line 73
            echo "                                            <li><b>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("GSM"), "html", null, true);
            echo ":</b> ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "gSM", array()), "html", null, true);
            echo " </li>
                                        ";
        }
        // line 75
        echo "                                        ";
        if ($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "travail", array())) {
            // line 76
            echo "                                            <li><b>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Work"), "html", null, true);
            echo ":</b> ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "travail", array()), "html", null, true);
            echo " </li>
                                        ";
        }
        // line 78
        echo "                                        ";
        if ($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "domicile", array())) {
            // line 79
            echo "                                            <li><b>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Home"), "html", null, true);
            echo ":</b> ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "domicile", array()), "html", null, true);
            echo " </li>
                                        ";
        }
        // line 81
        echo "                                        ";
        if ($this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "adresse", array())) {
            // line 82
            echo "                                            <li><b>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Adresse"), "html", null, true);
            echo ":</b> ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["patient"] ?? $this->getContext($context, "patient")), "adresse", array()), "html", null, true);
            echo " </li>
                                        ";
        }
        // line 84
        echo "                                    </ul>
                                    <div class=\"tg-updateall\"> <span class=\"tg-note\">* Cliquez sur <strong>Mise à jour</strong> pour modifier ou mettre à jour vos informations.</span>
                                    </div>
                                </div>

                            </div>
                            <div class=\"col-md-12\">
                                <hr>
                                ";
        // line 92
        if ((($context["notif"] ?? $this->getContext($context, "notif")) != null)) {
            // line 93
            echo "                                    <ul>
                                        <li> <span>Email Notification</span> <span class=\"pull-right\"><input type=\"checkbox\"  ";
            // line 94
            if (($this->getAttribute(($context["notif"] ?? $this->getContext($context, "notif")), "email", array()) == 1)) {
                echo "checked onchange=\"toggle(";
                echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
                echo ",'email',0)\"";
            } else {
                echo "onchange=\"toggle(";
                echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
                echo ",'email',1)\"";
            }
            echo " data-toggle=\"toggle\"></span> </li>
                                    </ul>
                                    <hr>
                                    <ul>
                                        <li> <span>SMS Notification</span> <span class=\"pull-right\"><input type=\"checkbox\" ";
            // line 98
            if (($this->getAttribute(($context["notif"] ?? $this->getContext($context, "notif")), "sms", array()) == 1)) {
                echo "checked onchange=\"toggle(";
                echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
                echo ",'sms',0)\"";
            } else {
                echo "onchange=\"toggle(";
                echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
                echo ",'sms',1)\"";
            }
            echo " data-toggle=\"toggle\"></span> </li>

                                    </ul>
                                ";
        } else {
            // line 102
            echo "                                    <ul>
                                        <li> <span>Email Notification</span> <span class=\"pull-right\"><input onchange=\"toggle(";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
            echo ",'email',0)\" type=\"checkbox\" checked data-toggle=\"toggle\"></span> </li>
                                    </ul>
                                    <hr>
                                    <ul>
                                        <li> <span>SMS Notification</span> <span class=\"pull-right\"><input onchange=\"toggle(";
            // line 107
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "id", array()), "html", null, true);
            echo ",'sms',0)\" type=\"checkbox\" checked data-toggle=\"toggle\"></span> </li>

                                    </ul>
                                ";
        }
        // line 111
        echo "                                <script>
                                    function toggle(id,toggle,val){
                                        window.location = \"";
        // line 113
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("patient_profil_togglenotif");
        echo "?id=\"+id+\"&toggle=\"+toggle+\"&val=\"+val;
                                    }
                                </script>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
";
        // line 133
        $this->loadTemplate("default/footer.html.twig", "patient/profil.html.twig", 133)->display($context);
        // line 134
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "patient/profil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  292 => 134,  290 => 133,  267 => 113,  263 => 111,  256 => 107,  249 => 103,  246 => 102,  231 => 98,  216 => 94,  213 => 93,  211 => 92,  201 => 84,  193 => 82,  190 => 81,  182 => 79,  179 => 78,  171 => 76,  168 => 75,  160 => 73,  158 => 72,  152 => 71,  144 => 70,  135 => 64,  129 => 60,  127 => 59,  120 => 57,  108 => 50,  104 => 48,  98 => 45,  95 => 44,  87 => 41,  84 => 40,  82 => 39,  66 => 26,  41 => 3,  35 => 2,  27 => 136,  25 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include ('base.html.twig') %}
{% block body %}
<body class=\"tg-home tg-login\">

<link href=\"https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css\" rel=\"stylesheet\">
<script src=\"https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js\"></script>

<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************--
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">                    
                                <figure class=\"tg-directpostimg\">
                                    {% if vich_uploader_asset(patient, 'imageFile') %}
                                        <a href=\"#\">
                                            <img src=\"{{ vich_uploader_asset(patient, 'imageFile') }}\" alt=\"{{ patient.image }}\" />
                                        </a>
                                    {% else %}
                                        <a href=\"#\">
                                            <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                        </a>
                                    {% endif %}
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">{{ patient.firstName }} {{ patient.lastName }}</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('patient_editProfil', {'id':app.user.idTable }) }}\">{{ 'Mis à jour'|trans }}</a> </div>

                            {% include('profilPatientNav.html.twig') %}
                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardtabs\">
                            <h3>{{ 'Profil'|trans }}</h3>
                            <hr>
                            <br>
                            <div class=\"tab-content tg-dashboardtabcontent\">
                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                                    <ul class=\"tg-themelist tg-liststyledot tg-listdatastyle\">
                                        <li><b>{{ 'Name'|trans }} :</b> {{ patient.firstName }} {{ patient.lastName }}</li>
                                        <li><b>{{ 'Birthday'|trans }} :</b> {{ patient.birthday|date('d-M-Y') }}</li>
                                        {% if patient.GSM %}
                                            <li><b>{{ 'GSM'|trans }}:</b> {{ patient.gSM }} </li>
                                        {% endif %}
                                        {% if patient.travail %}
                                            <li><b>{{ 'Work'|trans }}:</b> {{ patient.travail }} </li>
                                        {% endif %}
                                        {% if patient.domicile %}
                                            <li><b>{{ 'Home'|trans }}:</b> {{ patient.domicile }} </li>
                                        {% endif %}
                                        {% if patient.adresse %}
                                            <li><b>{{ 'Adresse'|trans }}:</b> {{ patient.adresse }} </li>
                                        {% endif %}
                                    </ul>
                                    <div class=\"tg-updateall\"> <span class=\"tg-note\">* Cliquez sur <strong>Mise à jour</strong> pour modifier ou mettre à jour vos informations.</span>
                                    </div>
                                </div>

                            </div>
                            <div class=\"col-md-12\">
                                <hr>
                                {% if notif != null %}
                                    <ul>
                                        <li> <span>Email Notification</span> <span class=\"pull-right\"><input type=\"checkbox\"  {% if notif.email == 1 %}checked onchange=\"toggle({{ user.id }},'email',0)\"{% else %}onchange=\"toggle({{ user.id }},'email',1)\"{% endif %} data-toggle=\"toggle\"></span> </li>
                                    </ul>
                                    <hr>
                                    <ul>
                                        <li> <span>SMS Notification</span> <span class=\"pull-right\"><input type=\"checkbox\" {% if notif.sms == 1 %}checked onchange=\"toggle({{ user.id }},'sms',0)\"{% else %}onchange=\"toggle({{ user.id }},'sms',1)\"{% endif %} data-toggle=\"toggle\"></span> </li>

                                    </ul>
                                {% else %}
                                    <ul>
                                        <li> <span>Email Notification</span> <span class=\"pull-right\"><input onchange=\"toggle({{ user.id }},'email',0)\" type=\"checkbox\" checked data-toggle=\"toggle\"></span> </li>
                                    </ul>
                                    <hr>
                                    <ul>
                                        <li> <span>SMS Notification</span> <span class=\"pull-right\"><input onchange=\"toggle({{ user.id }},'sms',0)\" type=\"checkbox\" checked data-toggle=\"toggle\"></span> </li>

                                    </ul>
                                {% endif %}
                                <script>
                                    function toggle(id,toggle,val){
                                        window.location = \"{{ path('patient_profil_togglenotif') }}?id=\"+id+\"&toggle=\"+toggle+\"&val=\"+val;
                                    }
                                </script>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
{% include ('default/footer.html.twig') %}

{% endblock %}

", "patient/profil.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\patient\\profil.html.twig");
    }
}

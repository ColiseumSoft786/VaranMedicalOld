<?php

/* user/login.html.twig */
class __TwigTemplate_fadd68ee0058e3e077d170950f7159ae0cd325fbc803f162cba654489233a10d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <h3>Hello</h3>
    <form  method=\"post\" action=\"";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" class=\"tg-formtheme tg-formsigninsignup\" autocomplete=\"off\">
        <fieldset>
            ";
        // line 6
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 7
            echo "                <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
            ";
        }
        // line 9
        echo "            <div class=\"row tg-rowmargin\">
                <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                    <div class=\"form-group tg-formgroup\">
                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 12
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" class=\"form-control\" placeholder=\"Nom d\\'utilisateur\"/>
                    </div>
                </div>
                <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                    <div class=\"form-group tg-formgroup\">
                        <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"  placeholder=\"Mot de passe\"/>
                    </div>
                </div>
                <div class=\"tg-kepploginpassword\">
                    <div class=\"tg-checkbox\">
                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                        <label for=\"keeplogin\">Garder ma session active</label>
                    </div>
                </div>
                <input type=\"text\">
                <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                    <button type=\"submit\" class=\"tg-btn pull-right\" id=\"_submit\" name=\"_submit\">Se connecter</button>
                </div>
            </div>
        </fieldset>
    </form>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 12,  56 => 9,  50 => 7,  48 => 6,  43 => 4,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends\"base.html.twig\" %}
{% block body %}
    <h3>Hello</h3>
    <form  method=\"post\" action=\"{{ path(\"fos_user_security_check\") }}\" class=\"tg-formtheme tg-formsigninsignup\" autocomplete=\"off\">
        <fieldset>
            {% if csrf_token %}
                <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
            {% endif %}
            <div class=\"row tg-rowmargin\">
                <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                    <div class=\"form-group tg-formgroup\">
                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" class=\"form-control\" placeholder=\"Nom d\\'utilisateur\"/>
                    </div>
                </div>
                <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                    <div class=\"form-group tg-formgroup\">
                        <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"  placeholder=\"Mot de passe\"/>
                    </div>
                </div>
                <div class=\"tg-kepploginpassword\">
                    <div class=\"tg-checkbox\">
                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                        <label for=\"keeplogin\">Garder ma session active</label>
                    </div>
                </div>
                <input type=\"text\">
                <div class=\"col-md-12 col-sm-12 col-xs-12 tg-columnpadding\">
                    <button type=\"submit\" class=\"tg-btn pull-right\" id=\"_submit\" name=\"_submit\">Se connecter</button>
                </div>
            </div>
        </fieldset>
    </form>

{% endblock %}
", "user/login.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\login.html.twig");
    }
}

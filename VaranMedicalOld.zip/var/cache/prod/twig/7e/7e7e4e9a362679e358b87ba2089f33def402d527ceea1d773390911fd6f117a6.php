<?php

/* Comments/index.html.twig */
class __TwigTemplate_a302bb8e55d154cdcffe5f3cfdc4232a3d523eb32ba4d81882621ae68b3b1440 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'addLocationModal' => array($this, 'block_addLocationModal'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6ab675b7eedf4bd30229beee0ccee24f4ce0c79543a29a039e90c9bb3f9d524 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6ab675b7eedf4bd30229beee0ccee24f4ce0c79543a29a039e90c9bb3f9d524->enter($__internal_f6ab675b7eedf4bd30229beee0ccee24f4ce0c79543a29a039e90c9bb3f9d524_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Comments/index.html.twig"));

        // line 1
        $this->loadTemplate("base.html.twig", "Comments/index.html.twig", 1)->display($context);
        // line 2
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_f6ab675b7eedf4bd30229beee0ccee24f4ce0c79543a29a039e90c9bb3f9d524->leave($__internal_f6ab675b7eedf4bd30229beee0ccee24f4ce0c79543a29a039e90c9bb3f9d524_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_fa14ecb5e0940675b99325d2815a0dac0aaff8b2bc82e886fff48101b5cdd2d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa14ecb5e0940675b99325d2815a0dac0aaff8b2bc82e886fff48101b5cdd2d5->enter($__internal_fa14ecb5e0940675b99325d2815a0dac0aaff8b2bc82e886fff48101b5cdd2d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\"> 
                                    ";
        // line 35
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 36
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                        </a>
                                    ";
        } else {
            // line 40
            echo "                                        <a href=\"#\">
                                            <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                        </a>
                                    ";
        }
        // line 44
        echo "                                    ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 45
            echo "                                        <figcaption>
                                            <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                <em class=\"tg-usericonholder\">
                                                    <i class=\"fa fa-shield\"></i>
                                                    <span>";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                </em>
                                            </a>
                                        </figcaption>
                                    ";
        }
        // line 54
        echo "                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. ";
        // line 56
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                            ";
        // line 64
        $this->loadTemplate("profilDoctorNav.html.twig", "Comments/index.html.twig", 64)->display($context);
        // line 65
        echo "                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardjobslocations\">
                            <div class=\"tg-dashboardbox\">

                                <div class=\"tg-box tg-profilephoto\">
                                    <div class=\"row tg-rowmargin\">
                                        <div class=\"col-md-3 col-sm-6 col-xs-12 tg-columnpadding pull-right\" >
                                            <div class=\"form-group tg-formgroup \">
                                                <a href=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_comments_new", array("location" => ($context["location"] ?? $this->getContext($context, "location")))), "html", null, true);
        echo "\" class=\"tg-btn tg-btn-lg\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Add New Comments"), "html", null, true);
        echo "</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tg-dashboardboxtitle\">
                                    <h2>";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Available Comments"), "html", null, true);
        echo "</h2>
                                </div>
                                <div id=\"divFormAdd\">

                                </div>
                                <div class=\"tg-box tg-availablelocation\">
                                    <div class=\"tg-servicelocations\">
                                        <div id=\"divErreur\" hidden>
                                            <div class=\"tg-alertmessages\">
                                                <div class=\"alert alert-danger tg-alertmessage fade in\">
                                                    <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                                                    <i class=\"fa fa-bug\"></i>
                                                    <span><strong>";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Error Message"), "html", null, true);
        echo ".</strong> Adipisicing elit, sed do eiusmod et dolore magna aliqua enim ad minimati.</span>
                                                </div>
                                            </div>
                                        </div>
                                        ";
        // line 97
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["comments"] ?? $this->getContext($context, "comments")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 98
            echo "                                            <div class=\"tg-servicelocation\">
                                                <div class=\"tg-directpost\">
                                                    <div class=\"tg-directinfo\">
                                                        <div class=\"tg-directposthead\">
                                                            <h3><a href=\"#\">";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "comment", array()), "html", null, true);
            echo "</a></h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <ul class=\"tg-servicesinfo\">
                                                    <li>

                                                    </li>
                                                </ul>
                                                <div class=\"tg-btnjoblocationeditdelete\" style=\"width: 10%\">
                                                    <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                        <a href=\"";
            // line 113
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_comments_edit", array("comment" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"tg-btndelete editLocation\"  style=\"background-color: #2b2b2b\" title=\"Modifier\"><i class=\"fa fa-pencil\"></i></a>

                                                    </div>
                                                    <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                        <a href=\"";
            // line 117
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctors_comments_delete", array("comment" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"tg-btndelete deleteLocation\" id=\"\" style=\"background-color: #2b2b2b\" title=\"Supprimer\"><i class=\"fa fa-trash\"></i></a><br>
                                                    </div>
                                                </div>
                                                <br><br>
                                            </div>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 123
        echo "                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
";
        // line 140
        $this->loadTemplate("default/footer.html.twig", "Comments/index.html.twig", 140)->display($context);
        // line 141
        $this->displayBlock('addLocationModal', $context, $blocks);
        // line 171
        echo "
";
        
        $__internal_fa14ecb5e0940675b99325d2815a0dac0aaff8b2bc82e886fff48101b5cdd2d5->leave($__internal_fa14ecb5e0940675b99325d2815a0dac0aaff8b2bc82e886fff48101b5cdd2d5_prof);

    }

    // line 141
    public function block_addLocationModal($context, array $blocks = array())
    {
        $__internal_6b9fa966274e434525d8110b76cca1328e654cf86413b697186880422f30cfe2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b9fa966274e434525d8110b76cca1328e654cf86413b697186880422f30cfe2->enter($__internal_6b9fa966274e434525d8110b76cca1328e654cf86413b697186880422f30cfe2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "addLocationModal"));

        // line 142
        echo "    <!--************************************
            Light Box Start
*************************************-->
    ";
        // line 167
        echo "<!--************************************
                Light Box End
    *************************************-->
";
        
        $__internal_6b9fa966274e434525d8110b76cca1328e654cf86413b697186880422f30cfe2->leave($__internal_6b9fa966274e434525d8110b76cca1328e654cf86413b697186880422f30cfe2_prof);

    }

    public function getTemplateName()
    {
        return "Comments/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  268 => 167,  263 => 142,  257 => 141,  249 => 171,  247 => 141,  245 => 140,  226 => 123,  214 => 117,  207 => 113,  193 => 102,  187 => 98,  183 => 97,  176 => 93,  161 => 81,  150 => 75,  138 => 65,  136 => 64,  130 => 63,  118 => 56,  114 => 54,  106 => 49,  100 => 45,  97 => 44,  91 => 41,  88 => 40,  80 => 37,  77 => 36,  75 => 35,  59 => 22,  38 => 3,  26 => 2,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include ('base.html.twig') %}
{% block body %}
<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
            Main Start
    *************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                        <div class=\"tg-widgetdashboard\">
                            <div class=\"tg-widgetprofile\">
                                <figure class=\"tg-directpostimg\"> 
                                    {% if vich_uploader_asset(doctor, 'imageFile') %}
                                        <a href=\"#\">
                                            <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                        </a>
                                    {% else %}
                                        <a href=\"#\">
                                            <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                        </a>
                                    {% endif %}
                                    {% if app.user.verifier == 1 %}
                                        <figcaption>
                                            <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                <em class=\"tg-usericonholder\">
                                                    <i class=\"fa fa-shield\"></i>
                                                    <span>{{ 'verified'|trans }}</span>
                                                </em>
                                            </a>
                                        </figcaption>
                                    {% endif %}
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                    <div class=\"tg-subjects\"></div>
                                    <ul class=\"tg-metadata\">
                                        <li><span class=\"tg-stars\"><span></span></span></li>
                                        <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                    </ul>
                                </div>
                                <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.id }) }}\">{{ 'Profile'|trans }}</a> </div>
                            {% include('profilDoctorNav.html.twig') %}
                        </div>
                    </div>
                    <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                        <div class=\"tg-dashboardjobslocations\">
                            <div class=\"tg-dashboardbox\">

                                <div class=\"tg-box tg-profilephoto\">
                                    <div class=\"row tg-rowmargin\">
                                        <div class=\"col-md-3 col-sm-6 col-xs-12 tg-columnpadding pull-right\" >
                                            <div class=\"form-group tg-formgroup \">
                                                <a href=\"{{ path('doctors_comments_new',{'location':location}) }}\" class=\"tg-btn tg-btn-lg\">{{ 'Add New Comments'|trans }}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tg-dashboardboxtitle\">
                                    <h2>{{ 'Available Comments'|trans }}</h2>
                                </div>
                                <div id=\"divFormAdd\">

                                </div>
                                <div class=\"tg-box tg-availablelocation\">
                                    <div class=\"tg-servicelocations\">
                                        <div id=\"divErreur\" hidden>
                                            <div class=\"tg-alertmessages\">
                                                <div class=\"alert alert-danger tg-alertmessage fade in\">
                                                    <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
                                                    <i class=\"fa fa-bug\"></i>
                                                    <span><strong>{{ 'Error Message'|trans }}.</strong> Adipisicing elit, sed do eiusmod et dolore magna aliqua enim ad minimati.</span>
                                                </div>
                                            </div>
                                        </div>
                                        {% for item in comments %}
                                            <div class=\"tg-servicelocation\">
                                                <div class=\"tg-directpost\">
                                                    <div class=\"tg-directinfo\">
                                                        <div class=\"tg-directposthead\">
                                                            <h3><a href=\"#\">{{ item.comment }}</a></h3>
                                                        </div>
                                                    </div>
                                                </div>
                                                <ul class=\"tg-servicesinfo\">
                                                    <li>

                                                    </li>
                                                </ul>
                                                <div class=\"tg-btnjoblocationeditdelete\" style=\"width: 10%\">
                                                    <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                        <a href=\"{{ path('doctors_comments_edit',{comment:item.id}) }}\" class=\"tg-btndelete editLocation\"  style=\"background-color: #2b2b2b\" title=\"Modifier\"><i class=\"fa fa-pencil\"></i></a>

                                                    </div>
                                                    <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >
                                                        <a href=\"{{ path('doctors_comments_delete',{comment:item.id}) }}\" class=\"tg-btndelete deleteLocation\" id=\"\" style=\"background-color: #2b2b2b\" title=\"Supprimer\"><i class=\"fa fa-trash\"></i></a><br>
                                                    </div>
                                                </div>
                                                <br><br>
                                            </div>
                                        {% endfor %}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--************************************
            Main End
    *************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
{% include ('default/footer.html.twig') %}
{% block addLocationModal %}
    <!--************************************
            Light Box Start
*************************************-->
    {#<div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"showMap\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog tg-modaldialog\">
            <div class=\"modal-content tg-modalcontent\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                <h2 id=\"locationName\"></h2>
                <div id=\"result\">

                </div>
            </div>
        </div>
    </div>
    <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"editLocation\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog tg-modaldialog\">
            <div class=\"modal-content tg-modalcontent\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                <h2 id=\"locationName\"></h2>
                <div id=\"formEdit\">

                </div>
            </div>
        </div>
    </div>
    #}<!--************************************
                Light Box End
    *************************************-->
{% endblock %}

{#<script>

    \$(document).ready(function () {

        \$(\".showMap\").click(function () {
            var location = \$(this).attr('id');
            var URL = \"{{ path('locations_show',{ 'id': 'myID' }) }}\";
            URL = URL.replace(/myID/g, location);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#result').html(response);
                    return true;
                }
            });
        });

        \$(\".editLocation\").click(function () {
            var location = \$(this).attr('id');
            var URL = \"{{ path('locations_edit',{ 'id': 'myID' }) }}\";
            URL = URL.replace(/myID/g, location);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    \$('#formEdit').html(response);
                    return true;
                }
            });
        });
        \$(\".deleteLocation\").click(function () {
            if (!confirm('Vous voulez vraiment supprime cette job location')) return false;
            var locations = \$(this).attr('id');
            var URL = \"{{ path('locations_delete',{ 'id': 'myID' }) }}\";
            URL = URL.replace(/myID/g, locations);
            console.log(URL);
            \$.ajax({
                type: \"GET\",
                url: URL,
                cache: false,
                success: function (response) {
                    if (response == 'erreur') {
                        \$('#divErreur').show();
                        return true;
                    }
                    location.reload();
                    return true;
                }
            });
        });
    });
</script>#}
{% endblock %}
", "Comments/index.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\Comments\\index.html.twig");
    }
}

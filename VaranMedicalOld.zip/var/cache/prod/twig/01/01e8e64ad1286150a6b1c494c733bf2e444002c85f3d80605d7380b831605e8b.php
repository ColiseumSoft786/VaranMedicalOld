<?php

/* doctors/profilEditSpecialities.html.twig */
class __TwigTemplate_098a35827cb3e53d37cfc14e3c3b4364eaced62c6e7cc089177ec9944b970b90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38f45af33110293c86cff994d8efdb71d7f5592993cf5cd20536fa4700bf40d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38f45af33110293c86cff994d8efdb71d7f5592993cf5cd20536fa4700bf40d3->enter($__internal_38f45af33110293c86cff994d8efdb71d7f5592993cf5cd20536fa4700bf40d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "doctors/profilEditSpecialities.html.twig"));

        // line 1
        echo "<ul class=\"tg-threecolumns tg-liststyledot\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["specialities"] ?? $this->getContext($context, "specialities")));
        foreach ($context['_seq'] as $context["_key"] => $context["specialitie"]) {
            // line 3
            echo "        <li> <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["specialitie"], "libelle", array()), "html", null, true);
            echo "</span> <button href=\"\" class=\"deleteSpecialisation\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["specialitie"], "id", array()), "html", null, true);
            echo "\" style=\"background-color: transparent\"><i class=\"fa fa-close\"></i></button> </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['specialitie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ul>

<script>
        \$(document).ready(function () {
                \$(\".deleteSpecialisation\").click(function () {
                        if (!confirm('Vous voulez supprime cette specialitie')) return false;
                        var URL = \"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("doctor_deleteSpecialitie", array("id" => "sss"));
        echo "\";
                        var idSpecialitie = \$(this).attr('value');
                        URL = URL.replace(/sss/g, idSpecialitie);
                        console.log('URL = '+URL);
                        \$.ajax({
                                type: \"POST\",
                                url: URL,
                                cache: false,
                                success: function (response) {
                                        \$('#specialitiesList').html(response);
                                        \$('#success').hide();
                                }
                        });
                        return true;
                });
        });
</script>";
        
        $__internal_38f45af33110293c86cff994d8efdb71d7f5592993cf5cd20536fa4700bf40d3->leave($__internal_38f45af33110293c86cff994d8efdb71d7f5592993cf5cd20536fa4700bf40d3_prof);

    }

    public function getTemplateName()
    {
        return "doctors/profilEditSpecialities.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 11,  40 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul class=\"tg-threecolumns tg-liststyledot\">
    {% for specialitie in specialities %}
        <li> <span>{{ specialitie.libelle }}</span> <button href=\"\" class=\"deleteSpecialisation\" value=\"{{ specialitie.id }}\" style=\"background-color: transparent\"><i class=\"fa fa-close\"></i></button> </li>
    {% endfor %}
</ul>

<script>
        \$(document).ready(function () {
                \$(\".deleteSpecialisation\").click(function () {
                        if (!confirm('Vous voulez supprime cette specialitie')) return false;
                        var URL = \"{{ path('doctor_deleteSpecialitie',{ 'id': 'sss' }) }}\";
                        var idSpecialitie = \$(this).attr('value');
                        URL = URL.replace(/sss/g, idSpecialitie);
                        console.log('URL = '+URL);
                        \$.ajax({
                                type: \"POST\",
                                url: URL,
                                cache: false,
                                success: function (response) {
                                        \$('#specialitiesList').html(response);
                                        \$('#success').hide();
                                }
                        });
                        return true;
                });
        });
</script>", "doctors/profilEditSpecialities.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\doctors\\profilEditSpecialities.html.twig");
    }
}

<?php

/* services/comboServicesByDoctor.html.twig */
class __TwigTemplate_c97a8ae75ae0530714da89f794d70dd21f5a50acb04e8f7e6ed4f5ee7307f16f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdb6e1d7784c3a063fd55e75accbb266442eac8f53aa1ce81324e89640b63c7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdb6e1d7784c3a063fd55e75accbb266442eac8f53aa1ce81324e89640b63c7b->enter($__internal_fdb6e1d7784c3a063fd55e75accbb266442eac8f53aa1ce81324e89640b63c7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "services/comboServicesByDoctor.html.twig"));

        // line 1
        echo "<div class=\"col-lg-4\">
    <div class=\"form-group tg-formgroup\">
        <span class=\"tg-select\">
            <select id=\"serviceDoctor\">
                <option>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Selectionner"), "html", null, true);
        echo "</option>
                ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["services"] ?? $this->getContext($context, "services")));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 7
            echo "                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["service"], "service", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "            </select>
        </span>
    </div>
</div>

";
        
        $__internal_fdb6e1d7784c3a063fd55e75accbb266442eac8f53aa1ce81324e89640b63c7b->leave($__internal_fdb6e1d7784c3a063fd55e75accbb266442eac8f53aa1ce81324e89640b63c7b_prof);

    }

    public function getTemplateName()
    {
        return "services/comboServicesByDoctor.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 9,  36 => 7,  32 => 6,  28 => 5,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"col-lg-4\">
    <div class=\"form-group tg-formgroup\">
        <span class=\"tg-select\">
            <select id=\"serviceDoctor\">
                <option>{{ 'Selectionner'|trans }}</option>
                {% for service in services %}
                    <option value=\"{{ service.id }}\">{{ service.service }}</option>
                {% endfor %}
            </select>
        </span>
    </div>
</div>

", "services/comboServicesByDoctor.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\services\\comboServicesByDoctor.html.twig");
    }
}

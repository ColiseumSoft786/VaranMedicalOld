<?php

/* calendries/index.html.twig */
class __TwigTemplate_c7d1f5611aa27dae7c8b99eb5bc6e355375ab42ab75e2413a4b440149750393e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38a7e4fb6d0efabd9fb024f5675834076e14070d7ff99a6820b281c2133cbc53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38a7e4fb6d0efabd9fb024f5675834076e14070d7ff99a6820b281c2133cbc53->enter($__internal_38a7e4fb6d0efabd9fb024f5675834076e14070d7ff99a6820b281c2133cbc53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "calendries/index.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "calendries/index.html.twig", 2)->display($context);
        // line 3
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 4
            echo "    ";
            $this->displayBlock('body', $context, $blocks);
        }
        
        $__internal_38a7e4fb6d0efabd9fb024f5675834076e14070d7ff99a6820b281c2133cbc53->leave($__internal_38a7e4fb6d0efabd9fb024f5675834076e14070d7ff99a6820b281c2133cbc53_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_54fe73a7df915e553c3d9b80b011c2864b43384b7b8b029bef70890b2f5c28fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54fe73a7df915e553c3d9b80b011c2864b43384b7b8b029bef70890b2f5c28fd->enter($__internal_54fe73a7df915e553c3d9b80b011c2864b43384b7b8b029bef70890b2f5c28fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "

        ";
        // line 8
        echo "        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\"> 
                                            ";
        // line 26
        if ($this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile")) {
            // line 27
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset(($context["doctor"] ?? $this->getContext($context, "doctor")), "imageFile"), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "image", array()), "html", null, true);
            echo "\" />
                                                </a>
                                            ";
        } else {
            // line 31
            echo "                                                <a href=\"#\">
                                                    <img src=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/thumbnails/img-20.jpg"), "html", null, true);
            echo "\" alt=\"image description\">
                                                </a>
                                            ";
        }
        // line 35
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "verifier", array()) == 1)) {
            // line 36
            echo "                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("verified"), "html", null, true);
            echo "</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            ";
        }
        // line 45
        echo "                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. ";
        // line 47
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array()), "html", null, true);
        echo "</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profil", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Profile"), "html", null, true);
        echo "</a> </div>
                                    ";
        // line 55
        $this->loadTemplate("profilDoctorNav.html.twig", "calendries/index.html.twig", 55)->display($context);
        // line 56
        echo "                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <div class=\"tg-dashboardappointments\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"tg-dashboardboxtitle\">
                                            <h2>Calendrier</h2>
                                        </div>
                                        <div id=\"searchBar\">
                                            <div class=\"col-md-6\">
                                                ";
        // line 66
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("DoctorsBundle:Locations:getComboLocationByDoctor", array("doctor" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "idTable", array()))));
        echo "
                                            </div>

                                            <div class=\"col-md-3\">
                                                ";
        // line 71
        echo "                                                <button id=\"settings_toggle\" type=\"button\" class=\"tg-btn btn-block\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Calender Entries"), "html", null, true);
        echo "</button>
                                            </div>
                                            <div class=\"col-md-3\">
                                                <button type=\"button\" class=\"tg-btn btn-block\" style=\"background-color: coral\" data-toggle=\"modal\" data-target=\"#add_absence\">";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Create Absence"), "html", null, true);
        echo "</button>
                                            </div>
                                        </div>
                                    </div>
                                    <br><br>
                                    <div id=\"addSeanceFram\"></div>
                                    <div id=\"settings\" style=\"display: none;\">
                                        <form id=\"appform\" action=\"";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_create_app");
        echo "\" method=\"POST\">
                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-4\">
                                                    <label for=\"\">";
        // line 84
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</label>
                                                    <select name=\"loc\" id=\"loc\" class=\"form-control\">
                                                        <option value=\"\">";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</option>
                                                        ";
        // line 87
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["locations"] ?? $this->getContext($context, "locations")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 88
            echo "                                                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</option>
                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 90
        echo "                                                    </select>
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start Date"), "html", null, true);
        echo "</label>
                                                    <input id=\"from\" name=\"sdate\" type=\"date\" value=\"";
        // line 94
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" min=\"";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("End Date"), "html", null, true);
        echo "</label>
                                                    <input id=\"to\" name=\"edate\" type=\"date\" value=\"";
        // line 98
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" min=\"";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                                                </div>
                                            </div>

                                            ";
        // line 106
        echo "                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-offset-2 col-md-4\">
                                                    <label>";
        // line 108
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start Time"), "html", null, true);
        echo "</label>
                                                    <input id=\"stime\" type=\"text\" name=\"stime\" placeholder=\"Enter Start Time\" class=\"form-control clockpicker\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>";
        // line 112
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("End Time"), "html", null, true);
        echo "</label>
                                                    <input id=\"etime\" class=\"form-control clockpicker\" name=\"etime\" placeholder=\"Enter End Time\" type=\"text\">
                                                </div></div>

                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-6\">
                                                    <label for=\"\">";
        // line 117
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Appointment Time"), "html", null, true);
        echo "</label>
                                                    <select id=\"atime\" name=\"atime\" class=\"form-control\">
                                                        <option value=\"\">";
        // line 119
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Appointment Time"), "html", null, true);
        echo "</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div>
                                                <div class=\"col-md-6\">
                                                    <label for=\"\">";
        // line 133
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Pause Time"), "html", null, true);
        echo "</label>
                                                    <select id=\"ptime\" name=\"ptime\" class=\"form-control\">
                                                        <option value=\"\">";
        // line 135
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Pause Time"), "html", null, true);
        echo "</option>
                                                        <option value=\"5\">5 min</option>
                                                        <option value=\"10\">10 min</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div></div>


                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-3\">
                                                    <div style=\"margin-top: 25px\">
                                                        <input checked id=\"break\" name=\"break\" type=\"checkbox\"> ";
        // line 154
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("I need break"), "html", null, true);
        echo "
                                                    </div>
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>";
        // line 158
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start of Break"), "html", null, true);
        echo "</label>
                                                    <input id=\"sbtime\" name=\"sbtime\" class=\"form-control clockpicker\" placeholder=\"Enter Start of break\" type=\"text\">
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>";
        // line 162
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("End of Break"), "html", null, true);
        echo "</label>
                                                    <input id=\"ebtime\" name=\"ebtime\" class=\"form-control clockpicker\" type=\"text\" placeholder=\"Enter End of break\">
                                                </div></div>


                                            <script type=\"text/javascript\">
                                                \$('.clockpicker').clockpicker({
                                                    placement: 'top',
                                                    align: 'left',
                                                    donetext: 'Done'
                                                });
                                            </script>
                                            <div class=\"col-md-12\" style=\"margin-top: 10px;margin-bottom: 10px\">
                                                <input type=\"submit\" value=\"Confirm Scheduling\" class=\"btn btn-info btn-block\">
                                            </div>
                                        </form>
                                        <script>
                                            \$('#break').change(function(){
                                                if(!document.getElementById('break').checked) {
                                                    \$('#sbtime').attr(\"disabled\",\"disabled\");
                                                    \$('#ebtime').attr(\"disabled\",\"disabled\");
                                                } else {
                                                    \$('#sbtime').removeAttr('disabled');
                                                    \$('#ebtime').removeAttr('disabled');
                                                }
                                            });
                                            \$('#appform').submit(function(e){
                                                var check = true;
                                                if(\$('#loc').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#from').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#to').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#stime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#etime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#atime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#ptime').val() == \"\"){
                                                    check = false;
                                                }if(document.getElementById('break').checked){
                                                    if(\$('#sbtime').val() == \"\"){
                                                        check = false;
                                                    }else if(\$('#ebtime').val() == \"\"){
                                                        check = false;
                                                    }
                                                }if(check){
                                                    var sdate = new Date(\$('#from').val());
                                                    var edate = new Date(\$('#to').val());
                                                    if(sdate > edate){
                                                        alert(\"Start date should be greater than end date\")
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    var check12 = \"01/01/2017 \"+\$('#stime').val()+\":00\";
                                                    var check34 = \"01/01/2017 \"+\$('#etime').val()+\":00\";
                                                    var stime = Date.parse(check12);
                                                    var etime = Date.parse(check34);
                                                    if(stime > etime){
                                                        alert(\"Start time should be greater than end time\");
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    if(!confirm(\"Are you sure ? If there are appointments already, they will be overwritten.\")) return false;

                                                }else{
                                                    alert('Fill Everything in this form');
                                                    e.preventDefault();
                                                }
                                            });
                                        </script>
                                    </div>
                                    <script>
                                        \$('#settings_toggle').click(function(){
                                           \$('#settings').toggle();
                                        });
                                    </script>
                                    <div id=\"listeCalendrie\">
                                        ";
        // line 242
        if ((null === ($context["calendrie"] ?? $this->getContext($context, "calendrie")))) {
            // line 243
            echo "                                            ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Calendries:getCalendriesByLocation", array("location" => 0)));
            echo "
                                        ";
        } else {
            // line 245
            echo "                                            ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Calendries:getCalendriesByLocation", array("location" => $this->getAttribute(($context["calendrie"] ?? $this->getContext($context, "calendrie")), "location", array()))));
            echo "
                                        ";
        }
        // line 247
        echo "
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <!--************************************
\t\t\t\tLight Box Start
\t*************************************-->
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"addSeances\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <div id=\"addSeancesZone\">

                    </div>
                </div>
            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"tg-appointmentlightbox\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>";
        // line 276
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Add new job location"), "html", null, true);
        echo "</h2>
                    ";
        // line 277
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Calendries:new"));
        echo "
                </div>

            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"add_absence\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>";
        // line 286
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Create your absence"), "html", null, true);
        echo "</h2>
                    <form id=\"abs\" action=\"";
        // line 287
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_create_absence");
        echo "\" method=\"post\">
                        <div class=\"col-md-12\">
                            <label for=\"\">";
        // line 289
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</label>
                            <select name=\"loc\" id=\"location\" class=\"form-control\">
                                <option value=\"\">";
        // line 291
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Location"), "html", null, true);
        echo "</option>
                                ";
        // line 292
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["locations"] ?? $this->getContext($context, "locations")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 293
            echo "                                    <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 295
        echo "                            </select>

                        </div>

                            ";
        // line 300
        echo "                        <div class=\"col-md-6\">
                            <label for=\"\">";
        // line 301
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Start Date"), "html", null, true);
        echo "</label>
                            <input type=\"date\" name=\"date\" value=\"";
        // line 302
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" min=\"";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y-m-d"), "html", null, true);
        echo "\" class=\"form-control\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">";
        // line 305
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Select Number of Days"), "html", null, true);
        echo "</label>
                            <input type=\"number\" name=\"day\" class=\"form-control\" value=\"1\" min=\"1\">
                            <input type=\"submit\" value=\"Confirm\" class=\"tg-btn pull-right\" style=\"margin-top: 10px;background-color: coral\">
                        </div>

                    </form>
                    <script>
                        \$('#abs').submit(function(e){
                            var val = \$('#location option:selected').val();
                            if(val == \"\"){
                                e.preventDefault();
                                alert('Select Your Calender Location');
                            }

                        })
                    </script>
                </div>

            </div>
        </div>
        <!--************************************
                    Light Box End
        *************************************-->
        <script>



            \$(document).ready(function () {
                \$(\"#appointmentsbundle_calendries_location\").change(function () {
                    \$('#dateSearch').val('');

                    var locationId = \$('#appointmentsbundle_calendries_location').val();
                    var URL = \"";
        // line 337
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_getCalendriesByLocation", array("location" => "sss"));
        echo "\";
                    URL = URL.replace(/sss/g, locationId);
                    \$.ajax({
                        type: \"GET\",
                        url: URL,
                        cache: false,
                        success: function (response) {
                            \$('#addSeanceFram').hide();
                            \$(\"#listeCalendrie\").html(response);
                            return true;
                        }
                    });
                });

            });
        </script>
        </div>
        <!--************************************
                Wrapper End
        *************************************-->
        ";
        // line 357
        $this->loadTemplate("default/footer.html.twig", "calendries/index.html.twig", 357)->display($context);
        // line 358
        echo "    ";
        
        $__internal_54fe73a7df915e553c3d9b80b011c2864b43384b7b8b029bef70890b2f5c28fd->leave($__internal_54fe73a7df915e553c3d9b80b011c2864b43384b7b8b029bef70890b2f5c28fd_prof);

    }

    public function getTemplateName()
    {
        return "calendries/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  570 => 358,  568 => 357,  545 => 337,  510 => 305,  502 => 302,  498 => 301,  495 => 300,  489 => 295,  478 => 293,  474 => 292,  470 => 291,  465 => 289,  460 => 287,  456 => 286,  444 => 277,  440 => 276,  409 => 247,  403 => 245,  397 => 243,  395 => 242,  312 => 162,  305 => 158,  298 => 154,  276 => 135,  271 => 133,  254 => 119,  249 => 117,  241 => 112,  234 => 108,  230 => 106,  221 => 98,  217 => 97,  209 => 94,  205 => 93,  200 => 90,  189 => 88,  185 => 87,  181 => 86,  176 => 84,  170 => 81,  160 => 74,  153 => 71,  146 => 66,  134 => 56,  132 => 55,  126 => 54,  114 => 47,  110 => 45,  102 => 40,  96 => 36,  93 => 35,  87 => 32,  84 => 31,  76 => 28,  73 => 27,  71 => 26,  55 => 13,  48 => 8,  44 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% if is_granted('IS_AUTHENTICATED_FULLY') %}
    {% block body %}


        {#<body class=\"tg-home tg-login\">#}
        <!--[if lt IE 8]>
        <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
            {{ render(controller('AppBundle:Default:header')) }}

            <!--************************************
                Main Start
        *************************************-->
            <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"tg-content\" class=\"tg-content tg-dashboard\">
                            <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12 pull-left\">
                                <div class=\"tg-widgetdashboard\">
                                    <div class=\"tg-widgetprofile\">
                                        <figure class=\"tg-directpostimg\"> 
                                            {% if vich_uploader_asset(doctor, 'imageFile') %}
                                                <a href=\"#\">
                                                    <img src=\"{{ vich_uploader_asset(doctor, 'imageFile') }}\" alt=\"{{ doctor.image }}\" />
                                                </a>
                                            {% else %}
                                                <a href=\"#\">
                                                    <img src=\"{{ asset('assets/images/thumbnails/img-20.jpg') }}\" alt=\"image description\">
                                                </a>
                                            {% endif %}
                                            {% if app.user.verifier == 1 %}
                                                <figcaption>
                                                    <a class=\"tg-usericon tg-iconvarified\" href=\"#\">
                                                        <em class=\"tg-usericonholder\">
                                                            <i class=\"fa fa-shield\"></i>
                                                            <span>{{ 'verified'|trans }}</span>
                                                        </em>
                                                    </a>
                                                </figcaption>
                                            {% endif %}
                                        </figure>
                                        <div class=\"tg-directposthead\">
                                            <h3><a href=\"#\">Dr. {{ doctor.firstName }} {{ doctor.lastName }}</a></h3>
                                            <div class=\"tg-subjects\"></div>
                                            <ul class=\"tg-metadata\">
                                                <li><span class=\"tg-stars\"><span></span></span></li>
                                                <li><a href=\"#\"><i class=\"fa fa-thumbs-o-up\"></i> 99% (1009 votes)</a></li>
                                            </ul>
                                        </div>
                                        <a class=\"tg-btn tg-btn-lg\" href=\"{{ path('user_profil', {'id': app.user.id }) }}\">{{ 'Profile'|trans }}</a> </div>
                                    {% include('profilDoctorNav.html.twig') %}
                                </div>
                            </div>
                            <div class=\"col-lg-9 col-md-8 col-sm-8 col-xs-12 pull-right\">
                                <div class=\"tg-dashboardappointments\">
                                    <div class=\"tg-dashboardbox\">
                                        <div class=\"tg-dashboardboxtitle\">
                                            <h2>Calendrier</h2>
                                        </div>
                                        <div id=\"searchBar\">
                                            <div class=\"col-md-6\">
                                                {{ render(controller('DoctorsBundle:Locations:getComboLocationByDoctor' , { 'doctor': app.user.idTable})) }}
                                            </div>

                                            <div class=\"col-md-3\">
                                                {#<button type=\"button\" class=\"tg-btn btn-block\" data-toggle=\"modal\" data-target=\"#tg-appointmentlightbox\">{{ 'add new'|trans }}</button>#}
                                                <button id=\"settings_toggle\" type=\"button\" class=\"tg-btn btn-block\">{{'Calender Entries'|trans}}</button>
                                            </div>
                                            <div class=\"col-md-3\">
                                                <button type=\"button\" class=\"tg-btn btn-block\" style=\"background-color: coral\" data-toggle=\"modal\" data-target=\"#add_absence\">{{ 'Create Absence'|trans }}</button>
                                            </div>
                                        </div>
                                    </div>
                                    <br><br>
                                    <div id=\"addSeanceFram\"></div>
                                    <div id=\"settings\" style=\"display: none;\">
                                        <form id=\"appform\" action=\"{{ path('calendries_create_app') }}\" method=\"POST\">
                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-4\">
                                                    <label for=\"\">{{'Select Location'|trans}}</label>
                                                    <select name=\"loc\" id=\"loc\" class=\"form-control\">
                                                        <option value=\"\">{{'Select Location'|trans}}</option>
                                                        {% for item in locations %}
                                                            <option value=\"{{ item.id }}\">{{ item.name }}</option>
                                                        {% endfor %}
                                                    </select>
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>{{'Start Date'|trans}}</label>
                                                    <input id=\"from\" name=\"sdate\" type=\"date\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" min=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>{{'End Date'|trans}}</label>
                                                    <input id=\"to\" name=\"edate\" type=\"date\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" min=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                                                </div>
                                            </div>

                                            {#<script>
                                                \$(\"#from\").datepicker();
                                                \$(\"#to\").datepicker();
                                            </script>#}
                                            <div class=\"col-md-12\" style=\"margin-top: 10px\">
                                                <div class=\"col-md-offset-2 col-md-4\">
                                                    <label>{{'Start Time'|trans}}</label>
                                                    <input id=\"stime\" type=\"text\" name=\"stime\" placeholder=\"Enter Start Time\" class=\"form-control clockpicker\">
                                                </div>
                                                <div class=\"col-md-4\">
                                                    <label>{{'End Time'|trans}}</label>
                                                    <input id=\"etime\" class=\"form-control clockpicker\" name=\"etime\" placeholder=\"Enter End Time\" type=\"text\">
                                                </div></div>

                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-6\">
                                                    <label for=\"\">{{'Select Appointment Time'|trans}}</label>
                                                    <select id=\"atime\" name=\"atime\" class=\"form-control\">
                                                        <option value=\"\">{{'Select Appointment Time'|trans}}</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div>
                                                <div class=\"col-md-6\">
                                                    <label for=\"\">{{'Select Pause Time'|trans}}</label>
                                                    <select id=\"ptime\" name=\"ptime\" class=\"form-control\">
                                                        <option value=\"\">{{'Select Pause Time'|trans}}</option>
                                                        <option value=\"5\">5 min</option>
                                                        <option value=\"10\">10 min</option>
                                                        <option value=\"15\">15 min</option>
                                                        <option value=\"20\">20 min</option>
                                                        <option value=\"25\">25 min</option>
                                                        <option value=\"30\">30 min</option>
                                                        <option value=\"35\">35 min</option>
                                                        <option value=\"40\">40 min</option>
                                                        <option value=\"45\">45 min</option>
                                                        <option value=\"50\">50 min</option>
                                                        <option value=\"55\">55 min</option>
                                                        <option value=\"60\">60 min</option>
                                                    </select>
                                                </div></div>


                                            <div class=\"col-md-12\" style=\"margin-top: 10px\"><div class=\"col-md-3\">
                                                    <div style=\"margin-top: 25px\">
                                                        <input checked id=\"break\" name=\"break\" type=\"checkbox\"> {{'I need break'|trans}}
                                                    </div>
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>{{ 'Start of Break'|trans }}</label>
                                                    <input id=\"sbtime\" name=\"sbtime\" class=\"form-control clockpicker\" placeholder=\"Enter Start of break\" type=\"text\">
                                                </div>
                                                <div class=\"col-md-3\">
                                                    <label>{{ 'End of Break'|trans}}</label>
                                                    <input id=\"ebtime\" name=\"ebtime\" class=\"form-control clockpicker\" type=\"text\" placeholder=\"Enter End of break\">
                                                </div></div>


                                            <script type=\"text/javascript\">
                                                \$('.clockpicker').clockpicker({
                                                    placement: 'top',
                                                    align: 'left',
                                                    donetext: 'Done'
                                                });
                                            </script>
                                            <div class=\"col-md-12\" style=\"margin-top: 10px;margin-bottom: 10px\">
                                                <input type=\"submit\" value=\"Confirm Scheduling\" class=\"btn btn-info btn-block\">
                                            </div>
                                        </form>
                                        <script>
                                            \$('#break').change(function(){
                                                if(!document.getElementById('break').checked) {
                                                    \$('#sbtime').attr(\"disabled\",\"disabled\");
                                                    \$('#ebtime').attr(\"disabled\",\"disabled\");
                                                } else {
                                                    \$('#sbtime').removeAttr('disabled');
                                                    \$('#ebtime').removeAttr('disabled');
                                                }
                                            });
                                            \$('#appform').submit(function(e){
                                                var check = true;
                                                if(\$('#loc').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#from').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#to').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#stime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#etime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#atime').val() == \"\"){
                                                    check = false;
                                                }else if(\$('#ptime').val() == \"\"){
                                                    check = false;
                                                }if(document.getElementById('break').checked){
                                                    if(\$('#sbtime').val() == \"\"){
                                                        check = false;
                                                    }else if(\$('#ebtime').val() == \"\"){
                                                        check = false;
                                                    }
                                                }if(check){
                                                    var sdate = new Date(\$('#from').val());
                                                    var edate = new Date(\$('#to').val());
                                                    if(sdate > edate){
                                                        alert(\"Start date should be greater than end date\")
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    var check12 = \"01/01/2017 \"+\$('#stime').val()+\":00\";
                                                    var check34 = \"01/01/2017 \"+\$('#etime').val()+\":00\";
                                                    var stime = Date.parse(check12);
                                                    var etime = Date.parse(check34);
                                                    if(stime > etime){
                                                        alert(\"Start time should be greater than end time\");
                                                        e.preventDefault();
                                                        return false;
                                                    }
                                                    if(!confirm(\"Are you sure ? If there are appointments already, they will be overwritten.\")) return false;

                                                }else{
                                                    alert('Fill Everything in this form');
                                                    e.preventDefault();
                                                }
                                            });
                                        </script>
                                    </div>
                                    <script>
                                        \$('#settings_toggle').click(function(){
                                           \$('#settings').toggle();
                                        });
                                    </script>
                                    <div id=\"listeCalendrie\">
                                        {% if calendrie is null %}
                                            {{ render(controller('AppointmentsBundle:Calendries:getCalendriesByLocation', {'location': 0})) }}
                                        {% else %}
                                            {{ render(controller('AppointmentsBundle:Calendries:getCalendriesByLocation', {'location': calendrie.location})) }}
                                        {% endif %}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </main>
        <!--************************************
                Main End
        *************************************-->
        <!--************************************
\t\t\t\tLight Box Start
\t*************************************-->
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"addSeances\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <div id=\"addSeancesZone\">

                    </div>
                </div>
            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"tg-appointmentlightbox\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>{{ 'Add new job location'|trans }}</h2>
                    {{ render(controller('AppointmentsBundle:Calendries:new')) }}
                </div>

            </div>
        </div>
        <div class=\"modal tg-modal tg-appointmentlightbox fade\" id=\"add_absence\" tabindex=\"-1\" role=\"dialog\">
            <div class=\"modal-dialog tg-modaldialog\">
                <div class=\"modal-content tg-modalcontent\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\"></span></button>
                    <h2>{{ 'Create your absence'|trans }}</h2>
                    <form id=\"abs\" action=\"{{ path('calendries_create_absence') }}\" method=\"post\">
                        <div class=\"col-md-12\">
                            <label for=\"\">{{'Select Location'|trans}}</label>
                            <select name=\"loc\" id=\"location\" class=\"form-control\">
                                <option value=\"\">{{'Select Location'|trans}}</option>
                                {% for item in locations %}
                                    <option value=\"{{ item.id }}\">{{ item.name }}</option>
                                {% endfor %}
                            </select>

                        </div>

                            {#{{ render(controller('DoctorsBundle:Locations:getComboLocationByDoctor' , { 'doctor': app.user.idTable})) }}#}
                        <div class=\"col-md-6\">
                            <label for=\"\">{{'Select Start Date'|trans}}</label>
                            <input type=\"date\" name=\"date\" value=\"{{ \"now\"|date(\"Y-m-d\") }}\" min=\"{{ \"now\"|date(\"Y-m-d\") }}\" class=\"form-control\">
                        </div>
                        <div class=\"col-md-6\">
                            <label for=\"\">{{'Select Number of Days'|trans}}</label>
                            <input type=\"number\" name=\"day\" class=\"form-control\" value=\"1\" min=\"1\">
                            <input type=\"submit\" value=\"Confirm\" class=\"tg-btn pull-right\" style=\"margin-top: 10px;background-color: coral\">
                        </div>

                    </form>
                    <script>
                        \$('#abs').submit(function(e){
                            var val = \$('#location option:selected').val();
                            if(val == \"\"){
                                e.preventDefault();
                                alert('Select Your Calender Location');
                            }

                        })
                    </script>
                </div>

            </div>
        </div>
        <!--************************************
                    Light Box End
        *************************************-->
        <script>



            \$(document).ready(function () {
                \$(\"#appointmentsbundle_calendries_location\").change(function () {
                    \$('#dateSearch').val('');

                    var locationId = \$('#appointmentsbundle_calendries_location').val();
                    var URL = \"{{ path('calendries_getCalendriesByLocation', {'location' : 'sss'}) }}\";
                    URL = URL.replace(/sss/g, locationId);
                    \$.ajax({
                        type: \"GET\",
                        url: URL,
                        cache: false,
                        success: function (response) {
                            \$('#addSeanceFram').hide();
                            \$(\"#listeCalendrie\").html(response);
                            return true;
                        }
                    });
                });

            });
        </script>
        </div>
        <!--************************************
                Wrapper End
        *************************************-->
        {% include ('default/footer.html.twig') %}
    {% endblock %}
{% endif %}", "calendries/index.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\calendries\\index.html.twig");
    }
}

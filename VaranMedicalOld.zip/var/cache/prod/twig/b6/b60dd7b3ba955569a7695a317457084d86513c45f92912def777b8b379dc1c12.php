<?php

/* AppointmentsBundle:Appointments:displaybydate.html.twig */
class __TwigTemplate_63990dcf82bca5e379ce41e3ff4b2127bdd30d66079ba4206b41e30d98538075 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppointmentsBundle:Appointments:displaybydate.html.twig"));

        // line 1
        if ((twig_length_filter($this->env, ($context["appointment"] ?? $this->getContext($context, "appointment"))) != 0)) {
            // line 2
            echo "    <div id=\"divtoprint\">

        <style>
            @media print {
                .nodisplay{
                    display: none;
                }
            }
        </style>
    <h4>List Of Appointments</h4>
    <table>
        ";
            // line 13
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["appointment"] ?? $this->getContext($context, "appointment")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 14
                echo "            ";
                if ((twig_date_format_filter($this->env, "now", "Y-m-d") < twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y-m-d"))) {
                    // line 15
                    echo "                <tr ondblclick=\"\$('#appmodal').modal('show');getappointment(";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\">
                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                        <label style=\"font-size: 20px;\">";
                    // line 17
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "d M"), "html", null, true);
                    echo "</label><label style=\"font-size: 20px;\">";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y"), "html", null, true);
                    echo "</label> </td>
                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;background-color: #c1e9fe;\">
                        <label style=\"font-size: 18px\"><b>";
                    // line 19
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurDebut", array()), "H:i"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurFin", array()), "H:i"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
                    echo "</b>
                            <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat";
                    // line 21
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                                                    ";
                    // line 22
                    if (($this->getAttribute($context["item"], "etat", array()) == "confirme")) {
                        // line 23
                        echo "                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                        echo ")\" class=\"badge\" style=\"background: green\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } elseif (($this->getAttribute(                    // line 24
$context["item"], "etat", array()) == "non confirmer")) {
                        // line 25
                        echo "                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                        echo ")\" class=\"badge\" style=\"background: orangered\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } else {
                        // line 27
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                    ";
                    }
                    // line 29
                    echo "
                                                                </span>
                                                                                                    <a href=\"javascript:void(0)\" onclick=\"\$('#remindermodal').modal('show');\$('#reminderapp').val('";
                    // line 31
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "')\" class=\"badge\" style=\"background: black\">Send Reminder</a>

                                                                <a href=\"javascript:void(0)\" onclick=\"showmodelcutcopy('cut',";
                    // line 33
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\" class=\"badge\"><span class=\"fa fa-cut\"></span></a>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',";
                    // line 34
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>

                        </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>";
                    // line 38
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
                    echo "</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>Patient: ";
                    // line 39
                    echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getpatientbyUser", array("id" => $this->getAttribute($this->getAttribute($context["item"], "patient", array()), "idtable", array()))));
                    echo ", Reason: ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "reason", array()), "reason", array()), "html", null, true);
                    echo "
                        </label>
                        <div>

                        </div>
                    </td>
                </tr>
            ";
                } else {
                    // line 47
                    echo "                <tr ondblclick=\"\$('#appmodal').modal('show');getappointment(";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\">
                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                        <label style=\"font-size: 20px;\">";
                    // line 49
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "d M"), "html", null, true);
                    echo "</label><label style=\"font-size: 20px;\">";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "date", array()), "Y"), "html", null, true);
                    echo "</label> </td>
                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;\">
                        <label style=\"font-size: 18px\"><b>";
                    // line 51
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurDebut", array()), "H:i"), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "seance", array()), "heurFin", array()), "H:i"), "html", null, true);
                    echo ", ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "name", array()), "html", null, true);
                    echo "</b>
                            <span class=\"pull-right nodisplay\">
                                <span id=\"etat";
                    // line 53
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo "\">
                                    ";
                    // line 54
                    if (($this->getAttribute($context["item"], "etat", array()) == "confirme")) {
                        // line 55
                        echo "                                        <a href=\"javascript:void(0)\"  class=\"badge\" style=\"background: green\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                       ";
                    } elseif (($this->getAttribute(                    // line 56
$context["item"], "etat", array()) == "non confirmer")) {
                        // line 57
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: orangered\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                        ";
                    } else {
                        // line 59
                        echo "                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "etat", array()), "html", null, true);
                        echo "</a>
                                                                    ";
                    }
                    // line 61
                    echo "
                                                                </span>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',";
                    // line 63
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                    echo ")\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>
                        </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>";
                    // line 66
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "seance", array()), "calendrie", array()), "location", array()), "adresse", array()), "html", null, true);
                    echo "</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>Patient: ";
                    // line 67
                    echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:getpatientbyUser", array("id" => $this->getAttribute($this->getAttribute($context["item"], "patient", array()), "idtable", array()))));
                    echo ", Reason: ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "reason", array()), "reason", array()), "html", null, true);
                    echo "
                        </label>
                    </td>
                </tr>
            ";
                }
                // line 72
                echo "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 74
            echo "
    </table>
    </div>
    <script>
        function performaction(newid){
            if(confirm(\"Really want to \"+vtype+\" this appontment to new place ?\")){
                window.location = \"";
            // line 80
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_cutcopy");
            echo "?type=\"+vtype+\"&app=\"+cutcopyid+\"&sea=\"+newid;
            }
        }
        function showmodelcutcopy(type,id){
            vtype = type;
            cutcopyid = id;
            if(type == \"cut\"){
                \$('#cut_copy_head').html('Cut your appointment');
            }else{
                \$('#cut_copy_head').html('Copy your appointment');

            }
            \$('#cutt_copy').fadeIn();

        }
        function updatestatus(id){
            \$.ajax({
                url: '";
            // line 97
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendries_appoitment_update");
            echo "?id='+id,
                type: 'POST',
                success: function(result){
                    if(result === 'confirme'){
                        \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: green\">'+result+'</a>')
                    }else{
                        \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: orangered\">'+result+'</a>')
                    }
                }
            })
        }
    </script>
";
        } else {
            // line 110
            echo "    <p class=\"text-center\">You have no Appointments till now.</p>
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AppointmentsBundle:Appointments:displaybydate.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  254 => 110,  238 => 97,  218 => 80,  210 => 74,  203 => 72,  193 => 67,  189 => 66,  183 => 63,  179 => 61,  173 => 59,  167 => 57,  165 => 56,  160 => 55,  158 => 54,  154 => 53,  145 => 51,  138 => 49,  132 => 47,  119 => 39,  115 => 38,  108 => 34,  104 => 33,  99 => 31,  95 => 29,  89 => 27,  81 => 25,  79 => 24,  72 => 23,  70 => 22,  66 => 21,  57 => 19,  50 => 17,  44 => 15,  41 => 14,  37 => 13,  24 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if appointment|length != 0 %}
    <div id=\"divtoprint\">

        <style>
            @media print {
                .nodisplay{
                    display: none;
                }
            }
        </style>
    <h4>List Of Appointments</h4>
    <table>
        {% for item in appointment %}
            {% if \"now\"|date(\"Y-m-d\") < item.seance.calendrie.date|date('Y-m-d')  %}
                <tr ondblclick=\"\$('#appmodal').modal('show');getappointment({{ item.id }})\">
                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                        <label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('d M') }}</label><label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('Y') }}</label> </td>
                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;background-color: #c1e9fe;\">
                        <label style=\"font-size: 18px\"><b>{{ item.seance.heurDebut|date('H:i') }} - {{ item.seance.heurFin|date('H:i') }}, {{ item.seance.calendrie.location.name }}</b>
                            <span class=\"pull-right nodisplay\">
                                                                <span id=\"etat{{ item.id }}\">
                                                                    {% if item.etat == 'confirme' %}
                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus({{ item.id }})\" class=\"badge\" style=\"background: green\">{{ item.etat }}</a>
                                                                        {% elseif item.etat == 'non confirmer' %}
                                                                        <a href=\"javascript:void(0)\" onclick=\"updatestatus({{ item.id }})\" class=\"badge\" style=\"background: orangered\">{{ item.etat }}</a>
                                                                        {% else %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">{{ item.etat }}</a>
                                                                    {% endif %}

                                                                </span>
                                                                                                    <a href=\"javascript:void(0)\" onclick=\"\$('#remindermodal').modal('show');\$('#reminderapp').val('{{ item.id }}')\" class=\"badge\" style=\"background: black\">Send Reminder</a>

                                                                <a href=\"javascript:void(0)\" onclick=\"showmodelcutcopy('cut',{{ item.id }})\" class=\"badge\"><span class=\"fa fa-cut\"></span></a>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',{{ item.id }})\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>

                        </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>{{ item.seance.calendrie.location.adresse }}</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>Patient: {{ render(controller('AppointmentsBundle:Appointments:getpatientbyUser', {'id': item.patient.idtable})) }}, Reason: {{ item.reason.reason }}
                        </label>
                        <div>

                        </div>
                    </td>
                </tr>
            {% else %}
                <tr ondblclick=\"\$('#appmodal').modal('show');getappointment({{ item.id }})\">
                    <td style=\"width: 15%;vertical-align: middle;text-align: right;padding-right: 10px\">
                        <label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('d M') }}</label><label style=\"font-size: 20px;\">{{ item.seance.calendrie.date|date('Y') }}</label> </td>
                    <td style=\"padding: 10px;width: 85%;text-align: left;border-left: 10px solid #83c1f4;\">
                        <label style=\"font-size: 18px\"><b>{{ item.seance.heurDebut|date('H:i') }} - {{ item.seance.heurFin|date('H:i') }}, {{ item.seance.calendrie.location.name }}</b>
                            <span class=\"pull-right nodisplay\">
                                <span id=\"etat{{ item.id }}\">
                                    {% if item.etat == 'confirme' %}
                                        <a href=\"javascript:void(0)\"  class=\"badge\" style=\"background: green\">{{ item.etat }}</a>
                                                                       {% elseif item.etat == 'non confirmer' %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: orangered\">{{ item.etat }}</a>
                                                                        {% else %}
                                                                        <a href=\"javascript:void(0)\" class=\"badge\" style=\"background: yellowgreen\">{{ item.etat }}</a>
                                                                    {% endif %}

                                                                </span>
                                                                <a href=\"javascript:void(0)\" class=\"badge\" onclick=\"showmodelcutcopy('copy',{{ item.id }})\"><span  class=\"fa fa-copy\"></span></a>
                                                            </span>
                        </label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>{{ item.seance.calendrie.location.adresse }}</label><br class=\"hidden-xs hidden-sm hidden-md hidden-lg\">
                        <label>Patient: {{ render(controller('AppointmentsBundle:Appointments:getpatientbyUser', {'id': item.patient.idtable})) }}, Reason: {{ item.reason.reason }}
                        </label>
                    </td>
                </tr>
            {% endif %}

        {% endfor %}

    </table>
    </div>
    <script>
        function performaction(newid){
            if(confirm(\"Really want to \"+vtype+\" this appontment to new place ?\")){
                window.location = \"{{ path('calendries_appoitment_cutcopy') }}?type=\"+vtype+\"&app=\"+cutcopyid+\"&sea=\"+newid;
            }
        }
        function showmodelcutcopy(type,id){
            vtype = type;
            cutcopyid = id;
            if(type == \"cut\"){
                \$('#cut_copy_head').html('Cut your appointment');
            }else{
                \$('#cut_copy_head').html('Copy your appointment');

            }
            \$('#cutt_copy').fadeIn();

        }
        function updatestatus(id){
            \$.ajax({
                url: '{{ path('calendries_appoitment_update') }}?id='+id,
                type: 'POST',
                success: function(result){
                    if(result === 'confirme'){
                        \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: green\">'+result+'</a>')
                    }else{
                        \$('#etat'+id).html('<a  href=\"javascript:void(0)\" onclick=\"updatestatus('+id+')\" class=\"badge\" style=\"background: orangered\">'+result+'</a>')
                    }
                }
            })
        }
    </script>
{% else %}
    <p class=\"text-center\">You have no Appointments till now.</p>
{% endif %}", "AppointmentsBundle:Appointments:displaybydate.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AppointmentsBundle/Resources/views/Appointments/displaybydate.html.twig");
    }
}

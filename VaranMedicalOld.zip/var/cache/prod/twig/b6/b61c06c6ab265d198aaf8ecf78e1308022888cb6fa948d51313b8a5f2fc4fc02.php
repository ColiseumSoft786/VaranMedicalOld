<?php

/* appointments/new.html.twig */
class __TwigTemplate_6cd64abbf3e7762101b7eb538315860db26d94786a58b34872acbfee890067f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "appointments/new.html.twig"));

        // line 1
        echo "<div class=\"tg-signinsignup\">
    <div class=\"tg-title\" style=\"margin-left: 10%; margin-top: 10%\">
        <h2>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Register Now As"), "html", null, true);
        echo "</h2>
    </div>
    <br><br>
    <div class=\"tg-dashboardtabs\">
        <div class=\"tab-content tg-dashboardtabcontent\">
            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                <div class=\"tg-searchbulder\">
                    <div id=\"tg-subcategories\" class=\"tg-subcategories\">
                        <div id=\"doctorscategory\" class=\"tg-tabcontent tg-active\" style=\"width: 100%; margin-left: 50px\">
                            <form class=\"tg-formtheme tg-formsigninsignup\" id=\"formAddAppointment\" action=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("appointments_new", array("seance" => $this->getAttribute(($context["seance"] ?? $this->getContext($context, "seance")), "id", array()))), "html", null, true);
        echo "\" method=\"post\">
                                <fieldset>
                                    <div class=\"row tg-rowmargin\">
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <input type=\"hidden\" name=\"appointmentsbundle_appointments[patient]\" id=\"appointmentsbundle_appointments_patient\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "id", array()), "html", null, true);
        echo "\">
                                            <input type=\"hidden\" name=\"appointmentsbundle_appointments[seance]\" id=\"appointmentsbundle_appointments_seance\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["seance"] ?? $this->getContext($context, "seance")), "id", array()), "html", null, true);
        echo "\">
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <label for=\"\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("What is the reason for your visite"), "html", null, true);
        echo " ?</label>
                                                ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Reasons:getComboReasons"));
        echo "
                                            </div>
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <div class=\"radio\">
                                                    <label><input type=\"radio\" id=\"appointmentsbundle_appointments_seenBefor\" name=\"appointmentsbundle_appointments[seenBefor]\" value=\"0\">";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("I am a new patient"), "html", null, true);
        echo "</label>
                                                    <label><input type=\"radio\" id=\"appointmentsbundle_appointments_seenBefor\" name=\"appointmentsbundle_appointments[seenBefor]\" value=\"1\">";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("I have seen this doctor before"), "html", null, true);
        echo "</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <label for=\"\">";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Phone number where the doctor can contact you"), "html", null, true);
        echo "</label>
                                                ";
        // line 36
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "phone", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                                            </div>
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <label for=\"\">";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Notes for the doctors office"), "html", null, true);
        echo " (optional)</label>
                                                ";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "note", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                                                ";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "
                                            </div>
                                        </div>
                                        <div class=\"col-sm-4 col-xs-4 tg-columnpadding pull-right\">
                                            <button type=\"submit\" class=\"tg-btn\">";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Book Appointment"), "html", null, true);
        echo "</button>
                                        </div>
                                        <br><br>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "appointments/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 47,  102 => 43,  98 => 42,  94 => 41,  86 => 36,  82 => 35,  73 => 29,  69 => 28,  60 => 22,  56 => 21,  49 => 17,  45 => 16,  38 => 12,  26 => 3,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"tg-signinsignup\">
    <div class=\"tg-title\" style=\"margin-left: 10%; margin-top: 10%\">
        <h2>{{ 'Register Now As'|trans }}</h2>
    </div>
    <br><br>
    <div class=\"tg-dashboardtabs\">
        <div class=\"tab-content tg-dashboardtabcontent\">
            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"overview\">
                <div class=\"tg-searchbulder\">
                    <div id=\"tg-subcategories\" class=\"tg-subcategories\">
                        <div id=\"doctorscategory\" class=\"tg-tabcontent tg-active\" style=\"width: 100%; margin-left: 50px\">
                            <form class=\"tg-formtheme tg-formsigninsignup\" id=\"formAddAppointment\" action=\"{{ path('appointments_new', {'seance': seance.id})}}\" method=\"post\">
                                <fieldset>
                                    <div class=\"row tg-rowmargin\">
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <input type=\"hidden\" name=\"appointmentsbundle_appointments[patient]\" id=\"appointmentsbundle_appointments_patient\" value=\"{{ app.user.id }}\">
                                            <input type=\"hidden\" name=\"appointmentsbundle_appointments[seance]\" id=\"appointmentsbundle_appointments_seance\" value=\"{{ seance.id }}\">
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <label for=\"\">{{ 'What is the reason for your visite'|trans }} ?</label>
                                                {{ render(controller('AppointmentsBundle:Reasons:getComboReasons')) }}
                                            </div>
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <div class=\"radio\">
                                                    <label><input type=\"radio\" id=\"appointmentsbundle_appointments_seenBefor\" name=\"appointmentsbundle_appointments[seenBefor]\" value=\"0\">{{ 'I am a new patient'|trans }}</label>
                                                    <label><input type=\"radio\" id=\"appointmentsbundle_appointments_seenBefor\" name=\"appointmentsbundle_appointments[seenBefor]\" value=\"1\">{{ 'I have seen this doctor before'|trans }}</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <label for=\"\">{{ 'Phone number where the doctor can contact you'|trans }}</label>
                                                {{ form_widget(form.phone, {'attr':{'class':'form-control'}}) }}
                                            </div>
                                        </div>
                                        <div class=\"col-md-10 col-sm-12 col-xs-12 tg-columnpadding\">
                                            <div class=\"form-group tg-formgroup\">
                                                <label for=\"\">{{ 'Notes for the doctors office'|trans }} (optional)</label>
                                                {{ form_widget(form.note, {'attr':{'class':'form-control'}}) }}
                                                {{ form_widget(form._token) }}
                                            </div>
                                        </div>
                                        <div class=\"col-sm-4 col-xs-4 tg-columnpadding pull-right\">
                                            <button type=\"submit\" class=\"tg-btn\">{{ 'Book Appointment'|trans }}</button>
                                        </div>
                                        <br><br>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
", "appointments/new.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\appointments\\new.html.twig");
    }
}

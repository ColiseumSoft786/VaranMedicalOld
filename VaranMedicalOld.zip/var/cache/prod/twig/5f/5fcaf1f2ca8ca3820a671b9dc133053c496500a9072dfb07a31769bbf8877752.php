<?php

/* user/login2.html.twig */
class __TwigTemplate_f8d6eebae136dd33a62463b090ffc56c0b35a528c44f2c7138e9f0adaa47b52e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a3580160647934044a2a2d43eb74525ed73cc42443b74cfd936524bb6bb0f16 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a3580160647934044a2a2d43eb74525ed73cc42443b74cfd936524bb6bb0f16->enter($__internal_2a3580160647934044a2a2d43eb74525ed73cc42443b74cfd936524bb6bb0f16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login2.html.twig"));

        // line 1
        echo "<div class=\"tg-widget tg-widgetlogin\">
    <div class=\"tg-widgetcontent\">
        <div class=\"tg-widgettitle\">
            <h3>Connectez-vous à votre compte MedicalApp</h3>
        </div>
        <form action=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\" class=\"tg-themeform tg-formsignin\">
            ";
        // line 7
        if (($context["csrf_token"] ?? $this->getContext($context, "csrf_token"))) {
            // line 8
            echo "                <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
            ";
        }
        // line 10
        echo "            <fieldset>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 12
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"tg-kepploginpassword\">
                    <div class=\"tg-checkbox\">
                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                        <label for=\"keeplogin\">Garder ma session active</label>
                    </div>
                </div>
                <button type=\"submit\" class=\"tg-btn col-sm-12 col-xs-12\" id=\"_submit\" name=\"_submit\" style=\"background-color: #00adcf\"><b>Se connecter</b></button>
            </fieldset>
            <a href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_resetting_request");
        echo "\" class=\"\"><b>Mot de passe oublie ?</b></a>
            <br>
            <hr>
            <div class=\"tg-widgettitle\">
                <h3>Nouveau à MedicalApp ?</h3>
            </div>
            <button type=\"button\" class=\"tg-btn tg-btnnext col-sm-12 col-xs-12\" style=\"background-color: #00adcf\"><b>Créer un compte</b></button>

        </form>
    </div>

</div>

";
        
        $__internal_2a3580160647934044a2a2d43eb74525ed73cc42443b74cfd936524bb6bb0f16->leave($__internal_2a3580160647934044a2a2d43eb74525ed73cc42443b74cfd936524bb6bb0f16_prof);

    }

    public function getTemplateName()
    {
        return "user/login2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 25,  45 => 12,  41 => 10,  35 => 8,  33 => 7,  29 => 6,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"tg-widget tg-widgetlogin\">
    <div class=\"tg-widgetcontent\">
        <div class=\"tg-widgettitle\">
            <h3>Connectez-vous à votre compte MedicalApp</h3>
        </div>
        <form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\" class=\"tg-themeform tg-formsignin\">
            {% if csrf_token %}
                <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
            {% endif %}
            <fieldset>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"form-group tg-formgroup\">
                    <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\" />
                </div>
                <div class=\"tg-kepploginpassword\">
                    <div class=\"tg-checkbox\">
                        <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                        <label for=\"keeplogin\">Garder ma session active</label>
                    </div>
                </div>
                <button type=\"submit\" class=\"tg-btn col-sm-12 col-xs-12\" id=\"_submit\" name=\"_submit\" style=\"background-color: #00adcf\"><b>Se connecter</b></button>
            </fieldset>
            <a href=\"{{ path('fos_user_resetting_request') }}\" class=\"\"><b>Mot de passe oublie ?</b></a>
            <br>
            <hr>
            <div class=\"tg-widgettitle\">
                <h3>Nouveau à MedicalApp ?</h3>
            </div>
            <button type=\"button\" class=\"tg-btn tg-btnnext col-sm-12 col-xs-12\" style=\"background-color: #00adcf\"><b>Créer un compte</b></button>

        </form>
    </div>

</div>

", "user/login2.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\user\\login2.html.twig");
    }
}

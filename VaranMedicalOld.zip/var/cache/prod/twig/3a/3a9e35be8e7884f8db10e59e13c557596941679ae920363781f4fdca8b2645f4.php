<?php

/* appointments/index.html.twig */
class __TwigTemplate_0fd80fc6fea7509b6cd63ba46e3e59856c14479e235945c7d30aadd718162bae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "appointments/index.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("base.html.twig", "appointments/index.html.twig", 2)->display($context);
        // line 3
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    ";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Default:header"));
        echo "

    <!--************************************
        Main Start
*************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-twocolumns\" class=\"tg-twocolumns\">
                    <div class=\"col-md-8 col-sm-12 col-xs-12\">
                        <aside id=\"tg-sidebar\" class=\"tg-sidebar\">
                            <div class=\"tg-widget tg-widgetlogin\">
                                ";
        // line 37
        if (($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_PATIENT") || $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_DOCTOR"))) {
            // line 38
            echo "                                    ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppointmentsBundle:Appointments:new", array("seance" => $this->getAttribute(($context["seance"] ?? $this->getContext($context, "seance")), "id", array()))));
            echo "
                                ";
        } else {
            // line 40
            echo "                                    ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("UserBundle:User:login"));
            echo "
                                ";
        }
        // line 42
        echo "                            </div>
                        </aside>
                    </div>
                    <div class=\"col-md-4 col-sm-12 col-xs-12\">
                        <div id=\"tg-content\" class=\"tg-content\">
                            <div class=\"tg-profilewidget tg-recommendation\">
                                <span class=\"tg-profilewidgeticon\">
                                    <img src=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/icons/icon-26.png"), "html", null, true);
        echo "\" alt=\"image description\">
                                </span>
                                <div class=\"tg-percentage\">
                                    <span></span>
                                    <span>";
        // line 53
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "firstName", array())), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute(($context["doctor"] ?? $this->getContext($context, "doctor")), "lastName", array())), "html", null, true);
        echo "</span><br>
                                    <span style=\"font-size: 10pt; color: #3c3c3c;    \">";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("specialities"), "html", null, true);
        echo "</span>
                                </div>
                                <div class=\"tg-description\">
                                    <h6 style=\"text-align: left; color: #a2acbe\">";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("location"), "html", null, true);
        echo " :</h6>
                                    <p style=\"text-align: left\"> ";
        // line 58
        echo twig_escape_filter($this->env, $this->getAttribute(($context["location"] ?? $this->getContext($context, "location")), "adresse", array()), "html", null, true);
        echo ".</p>
                                    <br>
                                </div>
                                <div class=\"tg-description\">
                                    <h6 style=\"text-align: left; color: #a2acbe\">";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Important Notes"), "html", null, true);
        echo " :</h6>
                                    ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["comments"] ?? $this->getContext($context, "comments")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 64
            echo "                                        <p style=\"text-align: left\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "comment", array()), "html", null, true);
            echo ".</p>
                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "                                    <br>
                                </div>
                                <div class=\"tg-description\">
                                    <h6 style=\"text-align: left; color: #a2acbe\">";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Appointment"), "html", null, true);
        echo " :</h6>
                                    <p style=\"text-align: left\"> ";
        // line 70
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["seance"] ?? $this->getContext($context, "seance")), "calendrie", array()), "date", array()), "D, d M"), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["seance"] ?? $this->getContext($context, "seance")), "heurDebut", array()), "H.i"), "html", null, true);
        echo ".</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<!--************************************
        Main End
*************************************-->
<!--************************************
        Light Box Start
*************************************-->


<!--************************************
            Light Box End
*************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
</body>
";
        // line 97
        $this->loadTemplate("default/footer.html.twig", "appointments/index.html.twig", 97)->display($context);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "appointments/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  189 => 97,  157 => 70,  153 => 69,  148 => 66,  139 => 64,  135 => 63,  131 => 62,  124 => 58,  120 => 57,  114 => 54,  108 => 53,  101 => 49,  92 => 42,  86 => 40,  80 => 38,  78 => 37,  63 => 25,  40 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% include ('base.html.twig') %}
{% block body %}


<body class=\"tg-home tg-login\">
<!--[if lt IE 8]>
<p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!--************************************
        Preloader Start
*************************************
<div class=\"preloader-outer\">
    <div class=\"pin\"></div>
    <div class=\"pulse\"></div>
</div>
<!--************************************
        Preloader End
*************************************-->

<!--************************************
        Wrapper Start
*************************************-->
<div id=\"tg-wrapper\" class=\"tg-wrapper tg-haslayout\">
    {{ render(controller('AppBundle:Default:header')) }}

    <!--************************************
        Main Start
*************************************-->
    <main id=\"tg-main\" class=\"tg-main tg-haslayout\">
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"tg-twocolumns\" class=\"tg-twocolumns\">
                    <div class=\"col-md-8 col-sm-12 col-xs-12\">
                        <aside id=\"tg-sidebar\" class=\"tg-sidebar\">
                            <div class=\"tg-widget tg-widgetlogin\">
                                {% if is_granted('ROLE_PATIENT') or is_granted('ROLE_DOCTOR') %}
                                    {{ render(controller('AppointmentsBundle:Appointments:new', {'seance':seance.id})) }}
                                {% else %}
                                    {{ render(controller('UserBundle:User:login')) }}
                                {% endif %}
                            </div>
                        </aside>
                    </div>
                    <div class=\"col-md-4 col-sm-12 col-xs-12\">
                        <div id=\"tg-content\" class=\"tg-content\">
                            <div class=\"tg-profilewidget tg-recommendation\">
                                <span class=\"tg-profilewidgeticon\">
                                    <img src=\"{{ asset('assets/images/icons/icon-26.png') }}\" alt=\"image description\">
                                </span>
                                <div class=\"tg-percentage\">
                                    <span></span>
                                    <span>{{ doctor.firstName|capitalize }} {{ doctor.lastName|capitalize }}</span><br>
                                    <span style=\"font-size: 10pt; color: #3c3c3c;    \">{{ 'specialities'|trans }}</span>
                                </div>
                                <div class=\"tg-description\">
                                    <h6 style=\"text-align: left; color: #a2acbe\">{{ 'location'|trans }} :</h6>
                                    <p style=\"text-align: left\"> {{ location.adresse }}.</p>
                                    <br>
                                </div>
                                <div class=\"tg-description\">
                                    <h6 style=\"text-align: left; color: #a2acbe\">{{ 'Important Notes'|trans }} :</h6>
                                    {% for item in comments %}
                                        <p style=\"text-align: left\"> {{ item.comment }}.</p>
                                    {% endfor %}
                                    <br>
                                </div>
                                <div class=\"tg-description\">
                                    <h6 style=\"text-align: left; color: #a2acbe\">{{ 'Appointment'|trans }} :</h6>
                                    <p style=\"text-align: left\"> {{ seance.calendrie.date|date('D, d M') }} - {{ seance.heurDebut|date('H.i') }}.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<!--************************************
        Main End
*************************************-->
<!--************************************
        Light Box Start
*************************************-->


<!--************************************
            Light Box End
*************************************-->

</div>
<!--************************************
        Wrapper End
*************************************-->
</body>
{% include ('default/footer.html.twig') %}
{% endblock %}
", "appointments/index.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\appointments\\index.html.twig");
    }
}

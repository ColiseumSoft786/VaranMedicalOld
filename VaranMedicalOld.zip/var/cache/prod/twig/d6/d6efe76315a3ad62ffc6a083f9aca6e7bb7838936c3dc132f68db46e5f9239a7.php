<?php

/* locations/show.html.twig */
class __TwigTemplate_cade3c6d2035502246839b1ceb628d403ec08efeeff8011767403bbc8931d682 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5afcbe22ee7bdd966a511744cf4b3aa64874a361ad315f453e05c9f37f95ce4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5afcbe22ee7bdd966a511744cf4b3aa64874a361ad315f453e05c9f37f95ce4e->enter($__internal_5afcbe22ee7bdd966a511744cf4b3aa64874a361ad315f453e05c9f37f95ce4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "locations/show.html.twig"));

        // line 1
        echo "<div id=\"map\" style=\"height:500px;width:100%;\">

</div>

<script src=\"http://maps.googleapis.com/maps/api/js?key=AIzaSyAcgnHwvZsCydPTdHNn_mCaG8eCcPllzD4&callback=initMap\"></script>
<script>
    function initMap() {
        var uluru = {lat: ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["location"] ?? $this->getContext($context, "location")), "latitude", array()), "html", null, true);
        echo ", lng: ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["location"] ?? $this->getContext($context, "location")), "langitude", array()), "html", null, true);
        echo "};
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: uluru
        });
        var marker = new google.maps.Marker({
            position: uluru,
            map: map
        });
    }
</script>
";
        
        $__internal_5afcbe22ee7bdd966a511744cf4b3aa64874a361ad315f453e05c9f37f95ce4e->leave($__internal_5afcbe22ee7bdd966a511744cf4b3aa64874a361ad315f453e05c9f37f95ce4e_prof);

    }

    public function getTemplateName()
    {
        return "locations/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 8,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"map\" style=\"height:500px;width:100%;\">

</div>

<script src=\"http://maps.googleapis.com/maps/api/js?key=AIzaSyAcgnHwvZsCydPTdHNn_mCaG8eCcPllzD4&callback=initMap\"></script>
<script>
    function initMap() {
        var uluru = {lat: {{ location.latitude }}, lng: {{ location.langitude}}};
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: uluru
        });
        var marker = new google.maps.Marker({
            position: uluru,
            map: map
        });
    }
</script>
", "locations/show.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\locations\\show.html.twig");
    }
}

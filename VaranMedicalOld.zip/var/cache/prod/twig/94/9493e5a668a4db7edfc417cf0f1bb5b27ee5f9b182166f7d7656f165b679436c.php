<?php

/* AdminBundle:Holiday:addph.html.twig */
class __TwigTemplate_0c1e336d2dc7e9fb741c27c1aee50790757bb1feb8b704393eb252e9284d23f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Holiday:addph.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Holiday:addph.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Admin: Weekends";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
    <section class=\"content-header\">
        <h1>
            Add a weekend Day
        </h1>
        <ol class=\"breadcrumb\">
            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>
            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Public Holiday</a></li>
            <li class=\"active\">New</li>
        </ol>
    </section>

    <section class=\"content\">


        <!-- Main row -->
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"box box-info\">
                    <div class=\"box-header with-border\">
                        <label class=\"label label-info\">Note: This Date will be blocked from all the calenders.</label>
                        <div class=\"box-tools pull-right\">
                            <button type=\"button\" class=\"btn btn-box-tool\" data-widget=\"collapse\"><i class=\"fa fa-minus\"></i>
                            </button>
                            ";
        // line 31
        echo "                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class=\"box-body\">
                        <div class=\"col-sm-offset-4 col-sm-4\">
                            <form id=\"dayform\" action=\"\" method=\"post\">
                                <div class=\"form-group\" style=\"margin-bottom: 10px\">
                                    <label>Select Day</label>
                                    <input type=\"text\" name=\"date\" placeholder=\"Select Date\" class=\"form-control\" id=\"date\">
                                </div>
                                <div class=\"form-group\" style=\"margin-bottom: 10px\">
                                    <label>Select Reason</label>
                                    <input type=\"text\" name=\"reason\" placeholder=\"Enter Reason\" class=\"form-control\" id=\"reason\">
                                </div>
                                <input  type=\"submit\" class=\"btn btn-info btn-block\">
                            </form>
                            <script>
                                \$('#date').datepicker({
                                    autoclose: true
                                });
                                \$('#dayform').submit(function(e){
                                   if(\$('#date').val() == \"\"){
                                       e.preventDefault();
                                   }if(\$('#reason').val() == \"\"){
                                       e.preventDefault();
                                   }
                                });
                            </script>

                        </div>


                    </div>
                    <!-- /.box-body -->

                    <!-- /.box-footer -->
                </div>
            </div>

        </div>
    </section>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Holiday:addph.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 31,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::admin.html.twig\" %}

{% block title %}Admin: Weekends{% endblock %}

{% block body %}

    <section class=\"content-header\">
        <h1>
            Add a weekend Day
        </h1>
        <ol class=\"breadcrumb\">
            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Home</a></li>
            <li><a href=\"#\"><i class=\"fa fa-dashboard\"></i> Public Holiday</a></li>
            <li class=\"active\">New</li>
        </ol>
    </section>

    <section class=\"content\">


        <!-- Main row -->
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"box box-info\">
                    <div class=\"box-header with-border\">
                        <label class=\"label label-info\">Note: This Date will be blocked from all the calenders.</label>
                        <div class=\"box-tools pull-right\">
                            <button type=\"button\" class=\"btn btn-box-tool\" data-widget=\"collapse\"><i class=\"fa fa-minus\"></i>
                            </button>
                            {#<button type=\"button\" class=\"btn btn-box-tool\" data-widget=\"remove\"><i class=\"fa fa-times\"></i></button>#}
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class=\"box-body\">
                        <div class=\"col-sm-offset-4 col-sm-4\">
                            <form id=\"dayform\" action=\"\" method=\"post\">
                                <div class=\"form-group\" style=\"margin-bottom: 10px\">
                                    <label>Select Day</label>
                                    <input type=\"text\" name=\"date\" placeholder=\"Select Date\" class=\"form-control\" id=\"date\">
                                </div>
                                <div class=\"form-group\" style=\"margin-bottom: 10px\">
                                    <label>Select Reason</label>
                                    <input type=\"text\" name=\"reason\" placeholder=\"Enter Reason\" class=\"form-control\" id=\"reason\">
                                </div>
                                <input  type=\"submit\" class=\"btn btn-info btn-block\">
                            </form>
                            <script>
                                \$('#date').datepicker({
                                    autoclose: true
                                });
                                \$('#dayform').submit(function(e){
                                   if(\$('#date').val() == \"\"){
                                       e.preventDefault();
                                   }if(\$('#reason').val() == \"\"){
                                       e.preventDefault();
                                   }
                                });
                            </script>

                        </div>


                    </div>
                    <!-- /.box-body -->

                    <!-- /.box-footer -->
                </div>
            </div>

        </div>
    </section>



{% endblock %}
", "AdminBundle:Holiday:addph.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\src\\AdminBundle/Resources/views/Holiday/addph.html.twig");
    }
}

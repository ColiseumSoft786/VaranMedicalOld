<?php

/* default/footer.html.twig */
class __TwigTemplate_ee979526406a624af068b60c6348dbd995528550021283ec485bcec94230df8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_331c41341a0bb4c1eecfc85d89d88d59be88c914580a95ea192dc5d89a154973 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_331c41341a0bb4c1eecfc85d89d88d59be88c914580a95ea192dc5d89a154973->enter($__internal_331c41341a0bb4c1eecfc85d89d88d59be88c914580a95ea192dc5d89a154973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/footer.html.twig"));

        // line 1
        echo "<!--************************************
\t\t\t\tFooter Start
\t\t*************************************-->
<footer id=\"tg-footer\" class=\"tg-footer tg-haslayout\">
    <div class=\"tg-subscribe\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"tg-fcols\">
                    <div class=\"col-sm-3\">

                    </div>
                    <div class=\"col-sm-9\">

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=\"tg-quicklinks\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"tg-fcols\">
                    <div class=\"tg-fcol\">
                        <strong class=\"tg-logo\">
                            <a href=\"index.html\"><img src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/logo.png"), "html", null, true);
        echo "\" alt=\"image description\"></a>
                        </strong>
                        <ul class=\"tg-contactinfo\">
                            <li><a href=\"#\"><i class=\"fa fa-location-arrow\"></i><address> aelit , AC1255 Manchester, UK</address></a></li>
                            <li><a href=\"#\"><i class=\"fa fa-phone\"></i><span>+33 06 50 25 25 25</span></a></li>
                            <li><a href=\"#\"><i class=\"fa fa-envelope-o\"></i><span>contact@e-zeedoc.com</span></a></li>
                            <li><a href=\"#\"><i class=\"fa fa-fax\"></i><span>+33 06 45 45 45 45</span></a></li>
                        </ul>
                        <ul class=\"tg-socialsharewithtext\">
                            <li class=\"tg-facebook\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-facebook-f\"></i>
                                        <span>";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("share on facebook"), "html", null, true);
        echo "</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-twitter\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-twitter\"></i>
                                        <span>";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("share on twitter"), "html", null, true);
        echo "</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-linkedin\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-linkedin\"></i>
                                        <span>";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("share on linkdin"), "html", null, true);
        echo "</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-googleplus\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-google-plus\"></i>
                                        <span>";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("share on google"), "html", null, true);
        echo "</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-rss\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-rss\"></i>
                                        <span>";
        // line 70
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("share on RSS"), "html", null, true);
        echo "</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-youtube\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-youtube-play\"></i>
                                        <span>";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("share on YouTube"), "html", null, true);
        echo "</span>
                                    </em>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class=\"tg-fcol tg-specialities\">
                        <div class=\"tg-title\">
                            <h3>";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Top Specialities"), "html", null, true);
        echo "</h3>
                        </div>
                        <ul>
                            <li><a href=\"#\">Arnos Grove</a></li>
                            <li><a href=\"#\">Dalston</a></li>
                            <li><a href=\"#\">Balham</a></li>
                            <li><a href=\"#\">Denmark Hill</a></li>
                            <li><a href=\"#\">Barkingside</a></li>
                            <li><a href=\"#\">Derry Downs</a></li>
                            <li><a href=\"#\">Barnes Cray</a></li>
                        </ul>
                        <ul>
                            <li><a href=\"#\">East Bedfont</a></li>
                            <li><a href=\"#\">Camden Town</a></li>
                            <li><a href=\"#\">Eden Park</a></li>
                            <li><a href=\"#\">Canonbury</a></li>
                            <li><a href=\"#\">";
        // line 102
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("View All"), "html", null, true);
        echo "</a></li>
                        </ul>
                    </div>
                    <div class=\"tg-fcol tg-latestlistings\">
                        <div class=\"tg-title\">
                            <h3>";
        // line 107
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Latest Listings"), "html", null, true);
        echo "</h3>
                        </div>
                        <ul>
                            <li>
                                <figure class=\"tg-authordp\">
                                    <img src=\"";
        // line 112
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/directpost/img-08.jpg"), "html", null, true);
        echo "\" alt=\"image description\">
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. David Pujol</a></h3>
                                    <div class=\"tg-subjects\">MDS - Pédiatre &amp; Dentiste</div>
                                </div>
                            </li>
                            <li>
                                <figure class=\"tg-authordp\">
                                    <img src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/directpost/img-09.jpg"), "html", null, true);
        echo "\" alt=\"image description\">
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. David Pujol</a></h3>
                                    <div class=\"tg-subjects\">MDS - Pédiatre &amp; Dentiste</div>
                                </div>
                            </li>
                            <li>
                                <figure class=\"tg-authordp\">
                                    <img src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/images/directpost/img-10.jpg"), "html", null, true);
        echo "\" alt=\"image description\">
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. David Pujol</a></h3>
                                    <div class=\"tg-subjects\">MDS - Pédiatre &amp; Dentiste</div>
                                </div>
                            </li>
                        </ul>
                        <a class=\"tg-btnviewmore\" href=\"javascript:void(0);\">";
        // line 138
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("View All"), "html", null, true);
        echo " <i class=\"fa fa-angle-double-right\"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=\"tg-footerbar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12 col-xs-12\">
                    <nav id=\"tg-footernav\" class=\"tg-footernav\">
                        <ul>
                            <li class=\"tg-active\"><a href=\"\">";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Home"), "html", null, true);
        echo "</a></li>
                            <li><a href=\"\">";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("About"), "html", null, true);
        echo "</a></li>
                            <li><a href=\"\">";
        // line 152
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("How It Works"), "html", null, true);
        echo "?</a></li>
                            <li><a href=\"\">";
        // line 153
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Categories"), "html", null, true);
        echo "</a></li>
                        </ul>
                    </nav>
                    <span class=\"tg-copyright\">2017 All Rights Reserved &copy; <a href=\"#\">Frontonis</a></span>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--************************************
        Footer End
*************************************-->";
        
        $__internal_331c41341a0bb4c1eecfc85d89d88d59be88c914580a95ea192dc5d89a154973->leave($__internal_331c41341a0bb4c1eecfc85d89d88d59be88c914580a95ea192dc5d89a154973_prof);

    }

    public function getTemplateName()
    {
        return "default/footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 153,  223 => 152,  219 => 151,  215 => 150,  200 => 138,  189 => 130,  177 => 121,  165 => 112,  157 => 107,  149 => 102,  130 => 86,  119 => 78,  108 => 70,  97 => 62,  86 => 54,  75 => 46,  64 => 38,  48 => 25,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!--************************************
\t\t\t\tFooter Start
\t\t*************************************-->
<footer id=\"tg-footer\" class=\"tg-footer tg-haslayout\">
    <div class=\"tg-subscribe\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"tg-fcols\">
                    <div class=\"col-sm-3\">

                    </div>
                    <div class=\"col-sm-9\">

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=\"tg-quicklinks\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"tg-fcols\">
                    <div class=\"tg-fcol\">
                        <strong class=\"tg-logo\">
                            <a href=\"index.html\"><img src=\"{{ asset('assets/images/logo.png') }}\" alt=\"image description\"></a>
                        </strong>
                        <ul class=\"tg-contactinfo\">
                            <li><a href=\"#\"><i class=\"fa fa-location-arrow\"></i><address> aelit , AC1255 Manchester, UK</address></a></li>
                            <li><a href=\"#\"><i class=\"fa fa-phone\"></i><span>+33 06 50 25 25 25</span></a></li>
                            <li><a href=\"#\"><i class=\"fa fa-envelope-o\"></i><span>contact@e-zeedoc.com</span></a></li>
                            <li><a href=\"#\"><i class=\"fa fa-fax\"></i><span>+33 06 45 45 45 45</span></a></li>
                        </ul>
                        <ul class=\"tg-socialsharewithtext\">
                            <li class=\"tg-facebook\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-facebook-f\"></i>
                                        <span>{{ 'share on facebook'|trans }}</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-twitter\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-twitter\"></i>
                                        <span>{{ 'share on twitter'|trans }}</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-linkedin\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-linkedin\"></i>
                                        <span>{{ 'share on linkdin'|trans }}</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-googleplus\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-google-plus\"></i>
                                        <span>{{ 'share on google'|trans }}</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-rss\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-rss\"></i>
                                        <span>{{ 'share on RSS'|trans }}</span>
                                    </em>
                                </a>
                            </li>
                            <li class=\"tg-youtube\">
                                <a class=\"tg-roundicontext\" href=\"#\">
                                    <em class=\"tg-usericonholder\">
                                        <i class=\"fa fa-youtube-play\"></i>
                                        <span>{{ 'share on YouTube'|trans }}</span>
                                    </em>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class=\"tg-fcol tg-specialities\">
                        <div class=\"tg-title\">
                            <h3>{{ 'Top Specialities'|trans }}</h3>
                        </div>
                        <ul>
                            <li><a href=\"#\">Arnos Grove</a></li>
                            <li><a href=\"#\">Dalston</a></li>
                            <li><a href=\"#\">Balham</a></li>
                            <li><a href=\"#\">Denmark Hill</a></li>
                            <li><a href=\"#\">Barkingside</a></li>
                            <li><a href=\"#\">Derry Downs</a></li>
                            <li><a href=\"#\">Barnes Cray</a></li>
                        </ul>
                        <ul>
                            <li><a href=\"#\">East Bedfont</a></li>
                            <li><a href=\"#\">Camden Town</a></li>
                            <li><a href=\"#\">Eden Park</a></li>
                            <li><a href=\"#\">Canonbury</a></li>
                            <li><a href=\"#\">{{ 'View All'|trans }}</a></li>
                        </ul>
                    </div>
                    <div class=\"tg-fcol tg-latestlistings\">
                        <div class=\"tg-title\">
                            <h3>{{ 'Latest Listings'|trans }}</h3>
                        </div>
                        <ul>
                            <li>
                                <figure class=\"tg-authordp\">
                                    <img src=\"{{ asset('assets/images/directpost/img-08.jpg') }}\" alt=\"image description\">
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. David Pujol</a></h3>
                                    <div class=\"tg-subjects\">MDS - Pédiatre &amp; Dentiste</div>
                                </div>
                            </li>
                            <li>
                                <figure class=\"tg-authordp\">
                                    <img src=\"{{ asset('assets/images/directpost/img-09.jpg') }}\" alt=\"image description\">
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. David Pujol</a></h3>
                                    <div class=\"tg-subjects\">MDS - Pédiatre &amp; Dentiste</div>
                                </div>
                            </li>
                            <li>
                                <figure class=\"tg-authordp\">
                                    <img src=\"{{ asset('assets/images/directpost/img-10.jpg') }}\" alt=\"image description\">
                                </figure>
                                <div class=\"tg-directposthead\">
                                    <h3><a href=\"#\">Dr. David Pujol</a></h3>
                                    <div class=\"tg-subjects\">MDS - Pédiatre &amp; Dentiste</div>
                                </div>
                            </li>
                        </ul>
                        <a class=\"tg-btnviewmore\" href=\"javascript:void(0);\">{{ 'View All'|trans }} <i class=\"fa fa-angle-double-right\"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=\"tg-footerbar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12 col-xs-12\">
                    <nav id=\"tg-footernav\" class=\"tg-footernav\">
                        <ul>
                            <li class=\"tg-active\"><a href=\"\">{{ 'Home'|trans }}</a></li>
                            <li><a href=\"\">{{ 'About'|trans }}</a></li>
                            <li><a href=\"\">{{ 'How It Works'|trans }}?</a></li>
                            <li><a href=\"\">{{ 'Categories'|trans }}</a></li>
                        </ul>
                    </nav>
                    <span class=\"tg-copyright\">2017 All Rights Reserved &copy; <a href=\"#\">Frontonis</a></span>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--************************************
        Footer End
*************************************-->", "default/footer.html.twig", "C:\\xampp\\htdocs\\VaranMedicalOld\\app\\Resources\\views\\default\\footer.html.twig");
    }
}
